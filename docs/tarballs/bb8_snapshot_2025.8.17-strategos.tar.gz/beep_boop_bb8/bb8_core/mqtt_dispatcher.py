from __future__ import annotations

"""
mqtt_dispatcher.py

Connects to the MQTT broker, subscribes to command topics, dispatches commands to the BLE bridge/controller, and publishes status and discovery information for Home Assistant.
"""
import json
import logging
import socket
from functools import partial
from ipaddress import ip_address
from typing import Any, Optional, Tuple

import paho.mqtt.client as mqtt

from .addon_config import CONFIG, CONFIG_SOURCE, init_config
from .common import CMD_TOPICS, STATE_TOPICS
from .logging_setup import logger

# Re-export publish_discovery for test compatibility
try:
    from .bb8_presence_scanner import publish_discovery
except ImportError:
    publish_discovery = None

log = logging.getLogger(__name__)
_LOOPBACKS = {"localhost", "127.0.0.1"}
_RESUB_ON_CONNECT_ATTACHED = False
_DISCOVERY_PUBLISHED = False

REASONS = {
    0: "success",
    1: "unacceptable_protocol_version",
    2: "identifier_rejected",
    3: "server_unavailable",
    4: "bad_username_or_password",
    5: "not_authorized",
}

# Dispatcher runtime state
_DISPATCHER_STARTED: bool = False
# (host, port, topic, client_id, user_present)
_START_KEY: Optional[Tuple[str, int, str, str, bool]] = None
CLIENT: Optional[Any] = None
_PENDING_SUBS: list = []
_BOUND_TOPICS: set = set()


# ---- Optional: LED discovery (gated by config) ------------------------------
# Verify if dispatcher already has a generic discovery publisher,
# adapt the function body to call it (most systems expose a client.publish wrapper).
def publish_led_discovery(publish_fn) -> None:
    """
    Publish HA discovery for RGB LED if enabled. `publish_fn(topic, payload, retain)`
    should publish to MQTT. Retain flag follows CONFIG['discovery_retain'].
    """
    if not CONFIG.get("dispatcher_discovery_enabled", False):
        return
    retain = bool(CONFIG.get("discovery_retain", False))
    ha_prefix = CONFIG.get("ha_discovery_topic", "homeassistant")
    obj_id = "bb8_led"
    cfg_topic = f"{ha_prefix}/light/{obj_id}/config"
    cfg = {
        "name": "BB8 LED",
        "uniq_id": obj_id,
        "schema": "json",
        "cmd_t": CMD_TOPICS["led"],
        "stat_t": STATE_TOPICS["led"],
        "rgb": True,
        "qos": int(CONFIG.get("qos", 1)),
        "dev": {"ids": ["bb8"], "name": "BB-8", "mf": "Sphero"},
    }
    publish_fn(cfg_topic, json.dumps(cfg), retain)
    logger.info("Published LED discovery: %s", cfg_topic)


# -----------------------------------------------------------------------------
# Stable discovery for HA (gated)
# -----------------------------------------------------------------------------
def _norm_mac(s: Optional[str]) -> str:
    if not s:
        return "unknown"
    return s.replace(":", "").lower()


def _device_block() -> dict[str, Any]:
    did = f"bb8-{_norm_mac(CONFIG.get('bb8_mac'))}"
    return {
        "ids": [did],
        "name": "BB-8",
        "mf": "Sphero",
    }


def publish_bb8_discovery(publish_fn) -> None:
    ha_prefix = CONFIG.get("ha_discovery_topic", "homeassistant")
    avail_t = CONFIG.get(
        "availability_topic_scanner",
        f"{CONFIG.get('MQTT_BASE', 'bb8')}/availability/scanner",
    )
    pa = CONFIG.get("availability_payload_online", "online")
    po = CONFIG.get("availability_payload_offline", "offline")
    qos = int(CONFIG.get("qos", 1))
    dev = _device_block()

    def cfg(topic, payload):
        publish_fn(topic, json.dumps(payload), True)
        log.info("Published discovery: %s", topic)

    # Unique IDs (stable, not name-derived)
    uid = {
        "presence": "bb8_presence",
        "rssi": "bb8_rssi",
        "power": "bb8_power",
        "heading": "bb8_heading",
        "speed": "bb8_speed",
        "drive": "bb8_drive",
        "sleep": "bb8_sleep",
        "led": "bb8_led",
    }

    # Presence (binary_sensor)
    cfg(
        f"{ha_prefix}/binary_sensor/{uid['presence']}/config",
        {
            "name": "BB-8 Presence",
            "uniq_id": uid["presence"],
            "stat_t": f"{CONFIG['MQTT_BASE']}/presence/state",
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )

    # RSSI (sensor)
    cfg(
        f"{ha_prefix}/sensor/{uid['rssi']}/config",
        {
            "name": "BB-8 RSSI",
            "uniq_id": uid["rssi"],
            "stat_t": f"{CONFIG['MQTT_BASE']}/rssi/state",
            "unit_of_meas": "dBm",
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )

    # Power (switch)
    cfg(
        f"{ha_prefix}/switch/{uid['power']}/config",
        {
            "name": "BB-8 Power",
            "uniq_id": uid["power"],
            "cmd_t": CMD_TOPICS["power"][0],
            "stat_t": STATE_TOPICS["power"],
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )

    # Heading (number)
    cfg(
        f"{ha_prefix}/number/{uid['heading']}/config",
        {
            "name": "BB-8 Heading",
            "uniq_id": uid["heading"],
            "cmd_t": CMD_TOPICS["heading"][0],
            "stat_t": STATE_TOPICS["heading"],
            "min": 0,
            "max": 359,
            "step": 1,
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )

    # Speed (number)
    cfg(
        f"{ha_prefix}/number/{uid['speed']}/config",
        {
            "name": "BB-8 Speed",
            "uniq_id": uid["speed"],
            "cmd_t": CMD_TOPICS["speed"][0],
            "stat_t": STATE_TOPICS["speed"],
            "min": 0,
            "max": 255,
            "step": 1,
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )

    # Drive (button)
    cfg(
        f"{ha_prefix}/button/{uid['drive']}/config",
        {
            "name": "Drive",
            "uniq_id": uid["drive"],
            "cmd_t": CMD_TOPICS["drive"][0],
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )

    # Sleep (button)
    cfg(
        f"{ha_prefix}/button/{uid['sleep']}/config",
        {
            "name": "Sleep",
            "uniq_id": uid["sleep"],
            "cmd_t": CMD_TOPICS["sleep"][0],
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )

    # LED (light, json schema)
    cfg(
        f"{ha_prefix}/light/{uid['led']}/config",
        {
            "name": "LED",
            "uniq_id": uid["led"],
            "schema": "json",
            "cmd_t": CMD_TOPICS["led"][0],
            "stat_t": STATE_TOPICS["led"],
            "rgb": True,
            "avty_t": avail_t,
            "pl_avail": pa,
            "pl_not_avail": po,
            "qos": qos,
            "dev": dev,
        },
    )


def _maybe_publish_bb8_discovery() -> None:
    global _DISCOVERY_PUBLISHED
    if _DISCOVERY_PUBLISHED:
        return
    if not CONFIG.get("dispatcher_discovery_enabled", False):
        return
    if CLIENT is None:
        return

    def _pub(topic: str, payload: str, retain: bool) -> None:
        cli = CLIENT
        if cli is None:
            log.warning("discovery publish skipped (no MQTT client) topic=%s", topic)
            return
        try:
            cli.publish(
                topic,
                payload=payload,
                qos=int(CONFIG.get("qos", 1)),
                retain=retain,
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("discovery publish failed topic=%s err=%s", topic, exc)

    publish_bb8_discovery(_pub)
    _DISCOVERY_PUBLISHED = True
    log.info("Published discovery: all canonical entities (retained)")


# -----------------------------------------------------------------------------
# Dispatcher singleton guard
# -----------------------------------------------------------------------------
def is_dispatcher_started() -> bool:
    """True if the MQTT dispatcher has been started in this process."""
    return _DISPATCHER_STARTED


def ensure_dispatcher_started(*args: Any, **kwargs: Any) -> bool:
    """
    Idempotently start the MQTT dispatcher. Returns True if running after call.
    Accepts arbitrary args/kwargs to pass through to start_mqtt_dispatcher().
    Honors config precedence: explicit kwargs > loaded config > fallback.
    """
    global _DISPATCHER_STARTED
    if _DISPATCHER_STARTED:
        return True
    try:
        # Always refresh config before resolving values
        init_config()
        # Resolve from kwargs first (explicit override), else CONFIG
        host = (
            kwargs.get("mqtt_host")
            or CONFIG.get("MQTT_HOST")
            or CONFIG.get("mqtt_broker")
            or "127.0.0.1"
        )
        port = (
            kwargs.get("mqtt_port")
            or CONFIG.get("MQTT_PORT")
            or CONFIG.get("mqtt_port")
            or 1883
        )
        topic = (
            kwargs.get("mqtt_topic")
            or CONFIG.get("MQTT_BASE")
            or CONFIG.get("mqtt_topic_prefix")
            or "bb8"
        )
        username = (
            kwargs.get("username")
            or CONFIG.get("MQTT_USERNAME")
            or CONFIG.get("mqtt_username")
        )
        password = (
            kwargs.get("password")
            or CONFIG.get("MQTT_PASSWORD")
            or CONFIG.get("mqtt_password")
        )
        client_id = (
            kwargs.get("client_id") or CONFIG.get("mqtt_client_id") or "bb8-addon"
        )
        user_flag = bool(username)
        logger.info(
            "Dispatcher config (resolved): host=%s port=%s user=%s topic=%s client_id=%s source=%s",
            host,
            port,
            user_flag,
            topic,
            client_id,
            CONFIG_SOURCE,
        )
        # If host is loopback but CONFIG specifies a non-loopback host, coerce it.
        cfg_host = CONFIG.get("MQTT_HOST") or CONFIG.get("mqtt_broker")
        if host in _LOOPBACKS and cfg_host and str(cfg_host) not in _LOOPBACKS:
            log.warning(
                "Coercing loopback MQTT host '%s' to configured host '%s' (source=%s).",
                host,
                cfg_host,
                CONFIG_SOURCE,
            )
            host = str(cfg_host)

        # Normalize port if someone passed a str
        try:
            port = int(port)
        except Exception:  # noqa: BLE001
            log.warning("Invalid mqtt_port=%r; falling back to 1883", port)
            port = 1883

        # Start dispatcher with explicit params
        start_mqtt_dispatcher(
            mqtt_host=host,
            mqtt_port=int(port),
            mqtt_topic=topic,
            client_id=client_id,
            username=username,
            password=password,
        )
        _DISPATCHER_STARTED = True
        # Publish discovery once, if enabled
        _maybe_publish_bb8_discovery()
        logger.info("MQTT dispatcher started.")
        return True
    except Exception as exc:
        log.error("Failed to start MQTT dispatcher: %s", exc)
        return False


# Placeholder for BLE bridge import
try:
    from .ble_bridge import BLEBridge
except ImportError:
    BLEBridge = None


def _is_loopback(h: str) -> bool:
    try:
        if h in _LOOPBACKS:
            return True
        return ip_address(h).is_loopback  # handles ::1 etc.
    except Exception:
        return False


def _canonicalize_params(
    host: Optional[str],
    port: Optional[int],
    topic: Optional[str],
    client_id: Optional[str],
    username: Optional[str],
    password: Optional[str],
) -> Tuple[str, int, str, str, Optional[str], Optional[str], str]:
    """
    Resolve final MQTT params with precedence:
      explicit kwargs > CONFIG > fallback.
    If a caller passes loopback while CONFIG has non-loopback, override to CONFIG.
    Returns (host, port, topic, client_id, username, password, source_tag)
    """
    init_config()  # ensure CONFIG is fresh
    cfg_host = CONFIG.get("MQTT_HOST") or CONFIG.get("mqtt_broker") or "127.0.0.1"
    cfg_port = int(CONFIG.get("MQTT_PORT") or CONFIG.get("mqtt_port") or 1883)
    cfg_topic = CONFIG.get("MQTT_BASE") or CONFIG.get("mqtt_topic_prefix") or "bb8"
    cfg_cid = CONFIG.get("mqtt_client_id") or "bb8_presence_scanner"
    cfg_user = CONFIG.get("MQTT_USERNAME") or CONFIG.get("mqtt_username")
    cfg_pass = CONFIG.get("MQTT_PASSWORD") or CONFIG.get("mqtt_password")

    use_host = host if host is not None else cfg_host
    use_port = int(port if port is not None else cfg_port)
    use_topic = topic if topic is not None else cfg_topic
    use_cid = client_id if client_id is not None else cfg_cid
    use_user = username
    use_pass = password
    src = "kwargs"

    # Fill creds from CONFIG if not explicitly passed
    if use_user is None and cfg_user is not None:
        use_user, src = cfg_user, "config"
    if use_pass is None and cfg_pass is not None:
        use_pass, src = cfg_pass, "config"

    # If caller passed loopback but CONFIG has a non-loopback host, override.
    if _is_loopback(use_host) and not _is_loopback(cfg_host):
        use_host, src = cfg_host, "override_from_config"

    return use_host, use_port, use_topic, use_cid, use_user, use_pass, src


def _compute_key(
    host: Any, port: Any, topic: Any, client_id: Any, username: Any
) -> Tuple[str, int, str, str, bool]:
    return (str(host), int(port), str(topic), str(client_id), bool(username))


def _guarded_start_mqtt_dispatcher(
    *,
    mqtt_host: Optional[str] = None,
    mqtt_port: Optional[int] = None,
    mqtt_topic: Optional[str] = None,
    client_id: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    **kwargs: Any,
):
    host, port, topic, cid, user, pwd, src = _canonicalize_params(
        mqtt_host, mqtt_port, mqtt_topic, client_id, username, password
    )

    key = _compute_key(host, port, topic, cid, user)
    global _DISPATCHER_STARTED, _START_KEY, CLIENT
    if is_dispatcher_started():
        if key != _START_KEY:
            log.warning(
                "dispatcher already started with %s, ignoring new start %s",
                _START_KEY,
                key,
            )
            return False
        return True

    # Use availability topic for clarity in logs
    avail_t = CONFIG.get(
        "availability_topic_scanner",
        f"{CONFIG.get('MQTT_BASE', 'bb8')}/availability/scanner",
    )
    log.info(
        "Dispatcher config (resolved): host=%s port=%s user=%s topic=%s client_id=%s availability_topic=%s source=%s",
        host,
        port,
        bool(user),
        topic,
        cid,
        avail_t,
        src,
    )

    res = _orig_start_mqtt_dispatcher(  # type: ignore[misc]
        mqtt_host=host,
        mqtt_port=port,
        mqtt_topic=topic,
        client_id=cid,
        username=user,
        password=pwd,
        **kwargs,
    )
    _DISPATCHER_STARTED = True
    _START_KEY = key
    CLIENT = None
    try:
        if isinstance(res, tuple) and res and res[0] is not None:
            CLIENT = res[0]
        elif hasattr(res, "client"):
            CLIENT = getattr(res, "client")
        elif hasattr(res, "publish"):  # paho client directly
            CLIENT = res
    except Exception as exc:  # noqa: BLE001
        log.debug("could not extract client from starter return: %s", exc)
    _apply_pending_subscriptions()
    _attach_on_connect_resubscribe()
    # Publish discovery once, if enabled
    _maybe_publish_bb8_discovery()
    return res


def _attach_on_connect_resubscribe() -> None:
    def _on_connect(
        client, userdata, flags, rc, properties=None
    ):  # paho v5 sig compatible
        log.info(
            "mqtt_on_connect rc=%s; re-binding subscriptions (%d topics)",
            rc,
            len(_BOUND_TOPICS) + len(_PENDING_SUBS),
        )
        _apply_pending_subscriptions()
        # Publish discovery at-connect to avoid races where client wasn't ready earlier
        _maybe_publish_bb8_discovery()

    # ...existing code...


def start_mqtt_dispatcher(
    mqtt_host: Optional[str] = None,
    mqtt_port: Optional[int] = None,
    mqtt_topic: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    controller: Any = None,
    client_id: Optional[str] = None,
    keepalive: Optional[int] = None,
    qos: Optional[int] = None,
    retain: Optional[bool] = None,
    status_topic: Optional[str] = None,
    tls: Optional[bool] = None,
    mqtt_user: Optional[str] = None,
    mqtt_password: Optional[str] = None,
) -> mqtt.Client:
    """
    Single entry-point used by bridge_controller via the compat shim.
    Explicit arg names (mqtt_host/mqtt_port/mqtt_topic) remove ambiguity.

    - Publishes LWT: status_topic=offline (retain)
    - On connect: status_topic=online (retain), hands the client to controller
    - Reason-logged connect/disconnect
    - Optional TLS (default False)
    """
    # Dynamic config lookups
    mqtt_host = mqtt_host or CONFIG.get("MQTT_HOST", "localhost")
    if mqtt_host is None:
        mqtt_host = "localhost"
    mqtt_port = mqtt_port or int(CONFIG.get("MQTT_PORT", 1883))
    mqtt_topic = mqtt_topic or f"{CONFIG.get('MQTT_BASE', 'bb8')}/command/#"
    username = username or CONFIG.get("MQTT_USERNAME", "mqtt_bb8")
    password = password or CONFIG.get("MQTT_PASSWORD", None)
    client_id = client_id or CONFIG.get("MQTT_CLIENT_ID", "bb8-addon")
    keepalive = keepalive or 60
    qos = qos if qos is not None else 1
    retain = retain if retain is not None else True
    status_topic = status_topic or f"{CONFIG.get('MQTT_BASE', 'bb8')}/status"
    tls = tls if tls is not None else CONFIG.get("MQTT_TLS", False)

    resolved = None
    try:
        resolved = socket.gethostbyname(mqtt_host)
    except Exception:
        resolved = "unresolved"

    logger.info(
        {
            "event": "mqtt_connect_attempt",
            "host": mqtt_host,
            "port": mqtt_port,
            "resolved": resolved,
            "client_id": client_id,
            "user": bool(username),
            "tls": tls,
            "topic": mqtt_topic,
            "status_topic": status_topic,
        }
    )

    # Paho v2 API (compatible with our version); v311 is fine for HA
    client = mqtt.Client(
        client_id=client_id, protocol=mqtt.MQTTv311, clean_session=True
    )

    # Auth
    if username is not None:
        client.username_pw_set(username=username, password=(password or ""))

    # TLS (optional)
    if tls:
        client.tls_set()  # customize CA/cert paths if needed
        # client.tls_insecure_set(True)  # only if you accept self-signed risk

    # LWT/availability
    client.will_set(status_topic, payload="offline", qos=qos, retain=True)

    # Reconnect backoff (let paho handle retries)
    client.reconnect_delay_set(min_delay=1, max_delay=30)

    # ---- Callbacks ----

    def _on_connect(client, userdata, flags, rc, properties=None):
        reason = REASONS.get(rc, f"unknown_{rc}")
        if rc == 0:
            logger.info({"event": "mqtt_connected", "rc": rc, "reason": reason})
            # mark online
            client.publish(status_topic, payload="online", qos=qos, retain=False)

            # Only publish discovery if enabled in config
            if CONFIG.get("DISPATCHER_DISCOVERY_ENABLED", False):
                try:
                    import os

                    from .bb8_presence_scanner import publish_discovery

                    dev_id = (
                        (getattr(controller, "target_mac", None) or "bb8")
                        .replace(":", "")
                        .lower()
                    )
                    dbus_path = getattr(controller, "dbus_path", None) or CONFIG.get(
                        "BB8_DBUS_PATH", "/org/bluez/hci0"
                    )
                    name = os.environ.get("BB8_NAME", "BB-8")
                    publish_discovery(client, dev_id, dbus_path, name=name)
                except Exception as e:
                    logger.warning(
                        {"event": "discovery_dispatcher_disabled", "reason": repr(e)}
                    )
            # Hand the client to the BB-8 controller (subscribe/publish wiring)
            # Expected to implement: attach_mqtt(client, topic, qos, retain)
            if hasattr(controller, "attach_mqtt"):
                try:
                    controller.attach_mqtt(client, mqtt_topic, qos=qos, retain=retain)
                except Exception as e:
                    logger.error(
                        {"event": "controller_attach_mqtt_error", "error": repr(e)}
                    )
        else:
            logger.error({"event": "mqtt_connect_failed", "rc": rc, "reason": reason})

    def _on_disconnect(client, userdata, rc, properties=None):
        # rc==0 = clean; >0 = unexpected
        logger.warning({"event": "mqtt_disconnected", "rc": rc})

    client.on_connect = _on_connect
    client.on_disconnect = _on_disconnect

    # Async connect + network loop
    client.connect_async(mqtt_host, mqtt_port, keepalive)
    client.loop_start()

    return client

    # Discovery is published by facade.attach_mqtt(). Avoid duplicates here.


def turn_on_bb8():
    logger.info("[BB-8] Scanning for device...")
    # Lazy import to localize BLE/Sphero dependencies
    from spherov2.adapter.bleak_adapter import BleakAdapter
    from spherov2.scanner import find_toys
    from spherov2.sphero_edu import SpheroEduAPI
    from spherov2.toy.bb8 import BB8
    from spherov2.types import Color

    devices = find_toys()
    for toy in devices:
        if isinstance(toy, BB8):
            logger.info(f"[BB-8] Connecting to {toy.address} ...")
            bb8 = BB8(toy.address, adapter_cls=BleakAdapter)
            with SpheroEduAPI(bb8) as edu:
                edu.set_main_led(Color(255, 100, 0))
                edu.roll(0, 30, 2)  # heading=0, speed=30, duration=2s
                edu.set_main_led(Color(0, 0, 0))
            logger.info("[BB-8] ON command sent.")
            return True
    logger.warning("[BB-8] No BB-8 found.")
    return False


def turn_off_bb8():
    logger.info("[BB-8] Scanning for device to sleep...")
    # Lazy import to localize BLE/Sphero dependencies
    from spherov2.adapter.bleak_adapter import BleakAdapter
    from spherov2.commands.core import IntervalOptions
    from spherov2.scanner import find_toys
    from spherov2.toy.bb8 import BB8

    devices = find_toys()
    for toy in devices:
        if isinstance(toy, BB8):
            bb8 = BB8(toy.address, adapter_cls=BleakAdapter)
            # Ensure correct enum type for sleep
            bb8.sleep(IntervalOptions(IntervalOptions.NONE), 0, 0, 0)  # type: ignore
            logger.info("[BB-8] OFF (sleep) command sent.")
            return True
    logger.warning("[BB-8] No BB-8 found for sleep.")
    return False


def get_client() -> Optional[Any]:
    """Return the active MQTT client if available."""
    return CLIENT


def _make_cb(handler):
    def _cb(client, userdata, message):
        payload = message.payload or b""
        try:
            text = payload.decode("utf-8")
        except Exception:
            text = ""
        try:
            handler(text)
        except Exception as exc:
            log.warning("command dispatch failed for %s: %s", message.topic, exc)

    return _cb


def _bind_subscription(topic, handler):
    if CLIENT is None:
        return False
    if topic in _BOUND_TOPICS:
        return True
    try:
        CLIENT.message_callback_add(topic, _make_cb(handler))
        CLIENT.subscribe(topic, qos=1)
        _BOUND_TOPICS.add(topic)
        log.info("mqtt_sub topic=%s qos=1", topic)
        return True
    except Exception as exc:
        log.warning("failed to subscribe %s: %s", topic, exc)
        return False


def _apply_pending_subscriptions():
    if CLIENT is None:
        return
    for topic, handler in list(_PENDING_SUBS):
        if _bind_subscription(topic, handler):
            try:
                _PENDING_SUBS.remove((topic, handler))
            except ValueError:
                pass


def register_subscription(topic, handler):
    if not _bind_subscription(topic, handler):
        _PENDING_SUBS.append((topic, handler))


def main():
    # Dynamic config lookups
    mqtt_host = CONFIG.get("MQTT_HOST", "localhost")
    mqtt_port = int(CONFIG.get("MQTT_PORT", 1883))
    mqtt_topic = f"{CONFIG.get('MQTT_BASE', 'bb8')}/command/#"
    username = CONFIG.get("MQTT_USERNAME", "mqtt_bb8")
    password = CONFIG.get("MQTT_PASSWORD", None)
    status_topic = f"{CONFIG.get('MQTT_BASE', 'bb8')}/status"

    start_mqtt_dispatcher(
        mqtt_host=mqtt_host,
        mqtt_port=mqtt_port,
        mqtt_topic=mqtt_topic,
        username=username,
        password=password,
        status_topic=status_topic,
    )


# Explicit export set (helps linters/import tools)
__all__ = [
    "is_dispatcher_started",
    "ensure_dispatcher_started",
    "start_mqtt_dispatcher",
    "get_client",
    "register_subscription",
    "turn_on_bb8",
    "turn_off_bb8",
    "main",
]
