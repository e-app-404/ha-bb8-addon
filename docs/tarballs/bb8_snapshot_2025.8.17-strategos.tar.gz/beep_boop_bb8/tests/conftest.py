from __future__ import annotations

import asyncio

import pytest


# Provide a stable event loop for tests that touch asyncio/BLE helpers.
# With asyncio_mode=auto this is usually not necessary, but it guards environments where plugin policies differ.
@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    try:
        yield loop
    finally:
        loop.run_until_complete(asyncio.sleep(0))
        loop.close()
