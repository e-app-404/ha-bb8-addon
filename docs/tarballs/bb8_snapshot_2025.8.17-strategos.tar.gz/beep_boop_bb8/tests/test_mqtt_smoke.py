import json
from typing import Any, List, Tuple

import paho.mqtt.client as mqtt

from bb8_core.bb8_presence_scanner import publish_discovery
from bb8_core.mqtt_dispatcher import start_mqtt_dispatcher


class FakeMQTT(mqtt.Client):
    published: List[Tuple[Any, ...]]  # Type annotation for static checkers

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.published = []
        self.subscribed = []

    def publish(self, topic, payload=None, qos=0, retain=False, properties=None):
        self.published.append((topic, payload, qos, retain, properties))
        return mqtt.MQTTMessageInfo(0)

    def subscribe(self, topic, qos=0, options=None, properties=None):
        self.subscribed.append((topic, qos, options, properties))
        # Return a dummy tuple matching the expected return type
        return (mqtt.MQTT_ERR_SUCCESS, 1)

    def trigger(self, topic, payload):
        for sub in self.subscribed:
            if sub[0] == topic:
                sub[1](topic, payload)


class FakeLog:
    def __init__(self):
        self.entries = []

    def info(self, msg):
        self.entries.append(("info", msg))

    def error(self, msg):
        self.entries.append(("error", msg))


class FakeToy:
    pass


def test_discovery_and_dispatcher_smoke():
    mqtt = FakeMQTT()
    log = FakeLog()
    device_id = "testbb8"
    name = "Test BB-8"
    # Publish discovery
    publish_discovery(mqtt, device_id, name)
    assert any("discovery: published" in e[1] for e in log.entries)
    # Start dispatcher
    # Use start_mqtt_dispatcher with minimal valid arguments for smoke test
    start_mqtt_dispatcher(
        mqtt_host="localhost",
        mqtt_port=1883,
        mqtt_topic="bb8/command/#",
        username=None,
        password=None,
        controller=None,
    )
    # disp.start() removed: no dispatcher object in use
    # Simulate LED set
    mqtt.trigger(f"bb8/{device_id}/cmd/led/set", json.dumps({"r": 1, "g": 2, "b": 3}))
    # Simulate sleep
    mqtt.trigger(f"bb8/{device_id}/cmd/sleep", json.dumps({"after_ms": 0}))
    # Simulate drive
    mqtt.trigger(
        f"bb8/{device_id}/cmd/drive",
        json.dumps({"heading_deg": 90, "speed": 100, "duration_ms": 10}),
    )
    # Validate state echo
    assert any(f"bb8/{device_id}/state/led" in t for t, *_ in mqtt.published)
    assert any(f"bb8/{device_id}/event/slept" in t for t, *_ in mqtt.published)
    assert any(f"bb8/{device_id}/state/motion" in t for t, *_ in mqtt.published)
