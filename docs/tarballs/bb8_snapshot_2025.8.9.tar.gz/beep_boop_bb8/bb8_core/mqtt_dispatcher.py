# MQTT Dispatcher: Core MQTT event handling for Home Assistant add-on
# Finalized for Home Assistant runtime (2025-08-04)

import json
import time
from typing import Optional
import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish
import os
from spherov2.scanner import find_toys
from spherov2.toy.bb8 import BB8
from spherov2.adapter.bleak_adapter import BleakAdapter
from bb8_core.ble_bridge import bb8_power_on_sequence, bb8_power_off_sequence
from spherov2.sphero_edu import SpheroEduAPI
from spherov2.types import Color
from spherov2.commands.core import IntervalOptions
from bb8_core.logging_setup import logger
from bb8_core.ble_gateway import BleGateway

# Placeholder for BLE bridge import
try:
    from bb8_core.ble_bridge import BLEBridge
except ImportError:
    BLEBridge = None


def start_mqtt_dispatcher(
    mqtt_host: str,
    mqtt_port: int,
    mqtt_topic: str,
    mqtt_user: Optional[str] = None,
    mqtt_password: Optional[str] = None,
    status_topic: Optional[str] = None,
    gateway: Optional[BleGateway] = None,  # New gateway parameter
) -> None:
    """Blocking MQTT dispatcher for BB-8 BLE bridge with robust connect/retry and LWT/discovery."""
    import socket
    # Fix: Pass gateway to BLEBridge constructor
    logger.debug({"event": "dispatcher_init", "BLEBridge": str(BLEBridge), "gateway": str(gateway)})
    bridge = BLEBridge(gateway) if BLEBridge and gateway else None
    logger.debug({"event": "dispatcher_bridge_instance", "bridge": str(bridge)})
    client = mqtt.Client(client_id="bb8-addon", clean_session=True)
    # LWT for Home Assistant availability
    mqtt_prefix = os.environ.get("MQTT_TOPIC_PREFIX", "bb8")
    client.will_set(f"{mqtt_prefix}/status", payload="offline", qos=1, retain=True)
    if mqtt_user and mqtt_password:
        client.username_pw_set(mqtt_user, mqtt_password)
    # Optional: Enable TLS if needed
    # client.tls_set()

    def on_connect(client, userdata, flags, rc):
        logger.debug({"event": "on_connect_called", "rc": rc, "flags": flags, "userdata": str(userdata)})
        if rc == 0:
            logger.info(f"Connected to MQTT broker at {mqtt_host}:{mqtt_port}")
            logger.debug({"event": "subscribe_topics", "topics": [mqtt_topic, "bb8/command/power"]})
            client.subscribe(mqtt_topic)
            client.subscribe("bb8/command/power")
            logger.info(f"Subscribed to topic: {mqtt_topic} and bb8/command/power")
            if status_topic:
                logger.debug({"event": "publish_status_triggered", "status_topic": status_topic, "bridge": str(bridge)})
                publish_status(client, status_topic, bridge)
            logger.debug({"event": "publish_online_status", "topic": f"{mqtt_prefix}/status"})
            client.publish(f"{mqtt_prefix}/status", "online", qos=1, retain=True)
            try:
                logger.debug({"event": "publish_mqtt_discovery_start"})
                publish_mqtt_discovery(client)
                logger.debug({"event": "publish_mqtt_discovery_success"})
            except Exception as e:
                logger.warning(f"Discovery emit failed: {e}")
        else:
            logger.error(f"Failed to connect to MQTT broker: {rc}")

    def on_message(client, userdata, msg):
        try:
            logger.debug({"event": "on_message_called", "msg": str(msg), "userdata": str(userdata)})
            topic = msg.topic
            logger.debug({"event": "on_message_topic", "topic": topic})
            try:
                payload = msg.payload.decode('utf-8').strip()
                logger.debug({"event": "on_message_payload_decoded", "payload": payload, "type": str(type(payload))})
            except Exception as e:
                logger.error({"event": "on_message_payload_decode_error", "error": str(e), "raw_payload": str(msg.payload)})
                return
            logger.info({"event": "mqtt_message_received", "topic": topic, "payload": payload})
            # Power command handler for Home Assistant switch
            if topic == "bb8/command/power":
                logger.debug({"event": "mqtt_power_command", "payload": payload})
                if payload == "ON":
                    logger.debug({"event": "mqtt_power_on_handler", "function": str(bb8_power_on_sequence), "bridge": str(bridge)})
                    try:
                        if bridge and bridge.core:
                            logger.debug({"event": "mqtt_power_on_sequence_start", "core": str(bridge.core)})
                            bb8_power_on_sequence(bridge.core)
                            logger.debug({"event": "mqtt_power_on_sequence_completed"})
                        else:
                            logger.warning({"event": "mqtt_power_on_sequence_skipped", "reason": "bridge or core missing"})
                    except Exception as e:
                        logger.error({"event": "mqtt_power_on_sequence_error", "error": str(e)}, exc_info=True)
                elif payload == "OFF":
                    logger.debug({"event": "mqtt_power_off_handler", "function": str(bb8_power_off_sequence)})
                    try:
                        logger.debug({"event": "mqtt_power_off_sequence_start"})
                        bb8_power_off_sequence()
                        logger.debug({"event": "mqtt_power_off_sequence_completed"})
                    except Exception as e:
                        logger.error({"event": "mqtt_power_off_sequence_error", "error": str(e)}, exc_info=True)
                else:
                    logger.warning({"event": "mqtt_power_command_unknown", "payload": payload})
                return
            try:
                logger.debug({"event": "on_message_json_load_start", "payload": payload})
                payload_json = json.loads(payload)
                logger.debug({"event": "on_message_json_load_success", "payload_json": payload_json})
                command = payload_json.get("command")
                logger.debug({"event": "on_message_command_extracted", "command": command})
                if not command:
                    logger.error({"event": "mqtt_command_missing", "payload": payload})
                    return
                if bridge and bridge.controller:
                    logger.debug({"event": "on_message_dispatch_controller", "controller": str(bridge.controller)})
                    if hasattr(bridge.controller, 'roll') and command == 'roll':
                        logger.debug({"event": "on_message_dispatch_roll", "args": payload_json})
                        result = bridge.controller.roll(**payload_json)
                    elif hasattr(bridge.controller, 'stop') and command == 'stop':
                        logger.debug({"event": "on_message_dispatch_stop"})
                        result = bridge.controller.stop()
                    elif hasattr(bridge.controller, 'set_led') and command == 'set_led':
                        logger.debug({"event": "on_message_dispatch_set_led", "args": payload_json})
                        result = bridge.controller.set_led(
                            payload_json.get("r", 0),
                            payload_json.get("g", 0),
                            payload_json.get("b", 0),
                            payload_json.get("persist", None),
                        )
                    else:
                        logger.error({"event": "mqtt_command_unknown", "command": command})
                        result = {"success": False, "error": f"Unknown command: {command}"}
                    logger.info({"event": "mqtt_command_dispatched", "command": command, "result": result})
                else:
                    logger.warning({"event": "mqtt_bridge_unavailable", "command": command})
            except json.JSONDecodeError as e:
                logger.error({"event": "mqtt_json_decode_error", "error": str(e), "payload": payload})
            except Exception as e:
                logger.error({"event": "mqtt_message_handle_error", "error": str(e), "payload": payload})
        except Exception as e:
            logger.error({"event": "mqtt_on_message_unhandled_exception", "error": str(e)}, exc_info=True)

    def on_disconnect(client, userdata, rc):
        logger.warning(f"MQTT disconnected (rc={rc}). Attempting reconnect in 5s...")
        time.sleep(5)
        try:
            client.reconnect()
        except Exception as e:
            logger.error(f"Reconnect failed: {e}")

    def publish_status(client, topic, bridge):
        try:
            status = bridge.diagnostics() if bridge else {"status": "no_bridge"}
            client.publish(topic, json.dumps(status))
            logger.info(f"Published status to {topic}")
        except Exception as e:
            logger.error(f"Failed to publish status: {e}")

    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect

    # Robust connect/retry loop with host fallback
    hosts_to_try = [mqtt_host, "core-mosquitto", "localhost"]
    connected = False
    while not connected:
        for host in hosts_to_try:
            try:
                resolved_host = socket.gethostbyname(host)
                logger.info(f"Attempting MQTT connect to {host}:{mqtt_port} (resolved: {resolved_host})")
                client.connect(host, mqtt_port, keepalive=60)
                connected = True
                break
            except Exception as e:
                logger.error(f"MQTT connect failed for {host}:{mqtt_port}: {e}")
        if not connected:
            logger.warning("All MQTT broker hosts failed. Retrying in 10 seconds...")
            time.sleep(10)
    client.loop_forever()


def publish_mqtt_discovery(client=None):
    BB8_MAC = os.environ.get("BB8_MAC", "B8:17:C2:A8:ED:45")
    MQTT_HOST = os.environ.get("MQTT_HOST", "localhost")
    MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
    MQTT_USER = os.environ.get("MQTT_USER")
    MQTT_PASSWORD = os.environ.get("MQTT_PASSWORD")
    mqtt_prefix = os.environ.get("MQTT_TOPIC_PREFIX", "bb8")
    device_id = f"bb8_{BB8_MAC.replace(':','').lower()}"
    def _emit(topic, payload):
        logger.debug({"event": "discovery_emit_start", "topic": topic, "payload": payload, "client": str(client)})
        logger.info({"event": "mqtt_discovery_publish", "topic": topic, "payload": payload})
        if client:
            logger.debug({"event": "discovery_emit_client_publish", "topic": topic})
            client.publish(topic, payload=payload, qos=1, retain=True)
        else:
            logger.debug({"event": "discovery_emit_single_publish", "topic": topic, "MQTT_HOST": MQTT_HOST, "MQTT_PORT": MQTT_PORT})
            publish.single(topic, payload, hostname=MQTT_HOST, port=MQTT_PORT,
                           auth={"username": MQTT_USER, "password": MQTT_PASSWORD} if MQTT_USER and MQTT_PASSWORD else None,
                           retain=True)
    # Presence sensor
    cfg_presence = {
        "name": "BB-8 Presence",
        "unique_id": f"{device_id}_presence",
        "device_class": "presence",
        "state_topic": f"{mqtt_prefix}/presence",
        "availability_topic": f"{mqtt_prefix}/status",
        "payload_on": "present",
        "payload_off": "absent",
        "device": {
            "identifiers": [device_id],
            "manufacturer": "Sphero",
            "model": "BB-8",
            "name": "BB-8"
        }
    }
    # RSSI sensor
    cfg_rssi = {
        "name": "BB-8 RSSI",
        "unique_id": f"{device_id}_rssi",
        "state_topic": f"{mqtt_prefix}/rssi",
        "availability_topic": f"{mqtt_prefix}/status",
        "unit_of_measurement": "dBm",
        "state_class": "measurement",
        "device_class": "signal_strength",
        "device": cfg_presence["device"]
    }
    # Power switch
    cfg_power = {
        "name": "BB-8 Power",
        "unique_id": f"{device_id}_power",
        "command_topic": f"{mqtt_prefix}/command/power",
        "state_topic": f"{mqtt_prefix}/state/power",
        "payload_on": "ON",
        "payload_off": "OFF",
        "availability_topic": f"{mqtt_prefix}/status",
        "device": cfg_presence["device"]
    }
    _emit(f"homeassistant/binary_sensor/{device_id}_presence/config", json.dumps(cfg_presence))
    _emit(f"homeassistant/sensor/{device_id}_rssi/config", json.dumps(cfg_rssi))
    _emit(f"homeassistant/switch/{device_id}_power/config", json.dumps(cfg_power))


def turn_on_bb8():
    logger.info("[BB-8] Scanning for device...")
    devices = find_toys()
    for toy in devices:
        if isinstance(toy, BB8):
            logger.info(f"[BB-8] Connecting to {toy.address} ...")
            bb8 = BB8(toy.address, adapter_cls=BleakAdapter)
            with SpheroEduAPI(bb8) as edu:
                edu.set_main_led(Color(255, 100, 0))
                edu.roll(0, 30, 2)  # heading=0, speed=30, duration=2s
                edu.set_main_led(Color(0, 0, 0))
            logger.info("[BB-8] ON command sent.")
            return True
    logger.warning("[BB-8] No BB-8 found.")
    return False


def turn_off_bb8():
    logger.info("[BB-8] Scanning for device to sleep...")
    devices = find_toys()
    for toy in devices:
        if isinstance(toy, BB8):
            bb8 = BB8(toy.address, adapter_cls=BleakAdapter)
            # Ensure correct enum type for sleep
            bb8.sleep(IntervalOptions(IntervalOptions.NONE), 0, 0, 0)  # type: ignore
            logger.info("[BB-8] OFF (sleep) command sent.")
            return True
    logger.warning("[BB-8] No BB-8 found for sleep.")
    return False


def main():
    # Obtain gateway from config/env or instantiate default
    ble_adapter = os.environ.get("BLE_ADAPTER", "hci0")
    gateway = BleGateway(mode="bleak", adapter=ble_adapter)
    mqtt_host = os.environ.get("MQTT_HOST", "localhost")
    mqtt_port = int(os.environ.get("MQTT_PORT", "1883"))
    mqtt_topic = os.environ.get("MQTT_TOPIC", "bb8/command/#")
    mqtt_user = os.environ.get("MQTT_USER")
    mqtt_password = os.environ.get("MQTT_PASSWORD")
    status_topic = os.environ.get("STATUS_TOPIC", "bb8/status")

    start_mqtt_dispatcher(
        mqtt_host=mqtt_host,
        mqtt_port=mqtt_port,
        mqtt_topic=mqtt_topic,
        mqtt_user=mqtt_user,
        mqtt_password=mqtt_password,
        status_topic=status_topic,
        gateway=gateway,  # Pass gateway explicitly
    )


# Call this at container startup

