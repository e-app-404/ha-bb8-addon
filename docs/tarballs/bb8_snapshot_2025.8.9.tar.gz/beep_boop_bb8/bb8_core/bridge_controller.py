from __future__ import annotations

from typing import Optional, Tuple, Dict, Any
import os
import inspect
from .ble_gateway import BleGateway
from .ble_bridge import BLEBridge
from .auto_detect import resolve_bb8_mac
from .logging_setup import logger
from .mqtt_dispatcher import start_mqtt_dispatcher

def get_mqtt_config():
    import yaml
    import os
    config_path = "/data/options.json"
    fallback_path = "/config/config.yaml"
    # Try Supervisor options.json first
    try:
        with open(config_path) as f:
            opts = yaml.safe_load(f)
        mqtt_broker = os.environ.get("MQTT_BROKER") or opts.get("mqtt_broker") or "core-mosquitto"
        mqtt_username = os.environ.get("MQTT_USERNAME") or opts.get("mqtt_username") or None
        mqtt_password = os.environ.get("MQTT_PASSWORD") or opts.get("mqtt_password") or None
        mqtt_topic_prefix = os.environ.get("MQTT_TOPIC_PREFIX") or opts.get("mqtt_topic_prefix") or "bb8"
        ble_adapter = os.environ.get("BLE_ADAPTER") or opts.get("ble_adapter") or "hci0"
    except Exception:
        # Fallback to config.yaml if options.json is missing or broken
        try:
            with open(fallback_path) as f:
                config = yaml.safe_load(f)
            opts = config.get("options", config)
            mqtt_broker = opts.get("mqtt_broker", "core-mosquitto")
            mqtt_username = opts.get("mqtt_username", None)
            mqtt_password = opts.get("mqtt_password", None)
            mqtt_topic_prefix = opts.get("mqtt_topic_prefix", "bb8")
            ble_adapter = opts.get("ble_adapter", "hci0")
        except Exception:
            mqtt_broker = "core-mosquitto"
            mqtt_username = None
            mqtt_password = None
            mqtt_topic_prefix = "bb8"
            ble_adapter = "hci0"
    return mqtt_broker, mqtt_username, mqtt_password, mqtt_topic_prefix, ble_adapter

def start_bridge_controller(
    bb8_mac: Optional[str],
    scan_seconds: int,
    rescan_on_fail: bool,
    cache_ttl_hours: int,
    **kwargs,
):
    from bb8_core.auto_detect import resolve_bb8_mac
    from bb8_core.ble_gateway import BleGateway
    from bb8_core.ble_bridge import BLEBridge
    from bb8_core.logging_setup import logger
    logger.info({"event": "bridge_controller_start",
                 "bb8_mac_cli": bb8_mac,
                 "scan_seconds": scan_seconds,
                 "rescan_on_fail": rescan_on_fail,
                 "cache_ttl_hours": cache_ttl_hours})
    logger.debug({"event": "bridge_controller_start_debug", "kwargs": kwargs})
    gw = BleGateway(mode="bleak", adapter=kwargs.get("ble_adapter"))
    logger.info({"event": "ble_gateway_init", "mode": gw.mode})
    logger.debug({"event": "ble_gateway_instance", "gw": str(gw), "adapter": kwargs.get("ble_adapter")})
    target_mac = (bb8_mac or "").strip() or None
    logger.debug({"event": "target_mac_initial", "target_mac": target_mac})
    if not target_mac:
        logger.info({"event": "bb8_mac_resolve_start",
                     "strategy": "auto_detect",
                     "scan_seconds": scan_seconds,
                     "cache_ttl_hours": cache_ttl_hours})
        try:
            logger.debug({"event": "resolve_bb8_mac_call", "scan_seconds": scan_seconds, "cache_ttl_hours": cache_ttl_hours, "rescan_on_fail": rescan_on_fail, "adapter": kwargs.get("ble_adapter")})
            target_mac = resolve_bb8_mac(
                scan_seconds=scan_seconds,
                cache_ttl_hours=cache_ttl_hours,
                rescan_on_fail=rescan_on_fail,
                adapter=kwargs.get("ble_adapter"),
            )
            logger.info({"event": "bb8_mac_resolve_success", "bb8_mac": target_mac})
            logger.debug({"event": "bb8_mac_resolve_success_debug", "target_mac": target_mac})
        except Exception as e:
            logger.error({"event": "bb8_mac_resolve_error", "error": repr(e)})
            raise
    else:
        logger.info({"event": "bb8_mac_resolve_bypass", "reason": "cli_or_env_provided", "bb8_mac": target_mac})
        logger.debug({"event": "bb8_mac_resolve_bypass_debug", "target_mac": target_mac})
    bridge = BLEBridge(gateway=gw, target_mac=target_mac, **kwargs)
    logger.info({"event": "bridge_controller_blebridge_instance", "bridge": str(bridge)})
    logger.debug({"event": "bridge_controller_blebridge_instance_debug", "bridge": str(bridge), "gateway": str(gw), "target_mac": target_mac, "kwargs": kwargs})
    # Resolve MQTT parameters with safe defaults and log if defaulted
    def _coalesce_mqtt() -> Tuple[str, int, str, Optional[str], Optional[str]]:
        host = kwargs.get("mqtt_host") or os.environ.get("MQTT_BROKER") or "localhost"
        port_raw = kwargs.get("mqtt_port") or os.environ.get("MQTT_PORT") or "1883"
        try:
            port = int(port_raw)  # type: ignore[arg-type]
        except Exception:
            port = 1883
        topic = kwargs.get("mqtt_topic") or os.environ.get("MQTT_TOPIC_PREFIX") or "bb8/command"
        user = kwargs.get("mqtt_user") or os.environ.get("MQTT_USERNAME")
        pwd = kwargs.get("mqtt_password") or os.environ.get("MQTT_PASSWORD")
        return host, port, topic, user, pwd

    mqtt_host, mqtt_port, mqtt_topic, mqtt_user, mqtt_password = _coalesce_mqtt()
    logger.info({
        "event": "bridge_controller_mqtt_dispatcher_start",
        "host": mqtt_host, "port": mqtt_port, "topic": mqtt_topic,
        "user": bool(mqtt_user), "password_supplied": bool(mqtt_password)
    })
    logger.debug({"event": "bridge_controller_mqtt_dispatcher_start_debug", "mqtt_host": mqtt_host, "mqtt_port": mqtt_port, "mqtt_topic": mqtt_topic, "mqtt_user": mqtt_user, "mqtt_password": bool(mqtt_password)})

    # Start dispatcher with a compatibility shim that prunes kwargs to match the actual signature.
    def _start_dispatcher_compat(func, supplied: Dict[str, Any]) -> Any:
        logger.debug({"event": "_start_dispatcher_compat_start", "func": str(func), "supplied": supplied})
        sig = inspect.signature(func)
        # common aliasing: topic vs topic_prefix, controller vs bridge
        aliases = {
            "topic": "topic",
            "topic_prefix": "topic",
            "controller": "controller",
            "bridge": "controller",
            "username": "user",
            "user": "user",
            "passwd": "password",
            "password": "password",
        }
        # Canonical full set we want to offer
        offered = {
            "host": supplied["host"],
            "port": supplied["port"],
            "topic": supplied["topic"],
            "user": supplied["user"],
            "password": supplied["password"],
            "status_topic": "bb8/status",
            "controller": supplied["controller"],
            "client_id": supplied.get("client_id"),
            "keepalive": supplied.get("keepalive", 60),
            "qos": supplied.get("qos", 1),
            "retain": supplied.get("retain", True),
        }
        logger.debug({"event": "_start_dispatcher_compat_offered", "offered": offered})
        # Build kwargs that match the function parameters, applying aliases
        pruned: Dict[str, Any] = {}
        for name in sig.parameters.keys():
            if name in offered:
                pruned[name] = offered[name]
            else:
                # alias lookup
                for k, v in aliases.items():
                    if name == k and v in offered:
                        pruned[name] = offered[v]
                        break
        logger.debug({"event": "_start_dispatcher_compat_pruned", "pruned": pruned})
        return func(**pruned)

    _start_dispatcher_compat(
        start_mqtt_dispatcher,
        {
            "host": mqtt_host,
            "port": mqtt_port,
            "topic": mqtt_topic,
            "user": mqtt_user,
            "password": mqtt_password,
            "controller": bridge,
            # Optional tuning knobs if your dispatcher supports them:
            "client_id": "bb8-addon",
            "keepalive": 60,
            "qos": 1,
            "retain": True,
        },
    )
