# ops/evidence

This folder contains scripts and utilities for collecting, capturing, and validating evidence related to the BB-8 addon and its runtime. Use these tools to gather logs, traces, and other artifacts for audit and troubleshooting purposes.