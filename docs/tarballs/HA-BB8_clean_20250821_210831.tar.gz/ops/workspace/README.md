# ops/workspace

This folder contains scripts for workspace management, consolidation, deployment, and maintenance. Use these tools to set up, rehydrate, prune, and maintain the workspace and runtime environments.