#!/usr/bin/env bash
grep -r '"source":"facade"' bb8_core *.json* || true
