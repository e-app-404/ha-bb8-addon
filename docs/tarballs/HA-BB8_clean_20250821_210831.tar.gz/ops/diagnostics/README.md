# ops/diagnostics

This folder contains scripts for diagnosing issues in the workspace, addon, and runtime environments. Use these tools to troubleshoot connectivity, environment variables, MQTT broker status, BLE bridge health, and other runtime diagnostics.