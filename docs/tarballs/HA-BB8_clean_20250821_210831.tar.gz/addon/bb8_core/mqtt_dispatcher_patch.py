import json
import logging
import os
import time

from paho.mqtt import client as mqtt

from bb8_core.bridge_controller import attach_flat_command_handlers

logger = logging.getLogger("bb8_addon")

# Dispatcher entry


def start_mqtt_dispatcher(
    host,
    port,
    topic="bb8",
    controller=None,
    user=None,
    password=None,
    retain=True,
    keepalive=60,
):
    base = os.environ.get("MQTT_BASE", topic or "bb8")
    client_id = "bb8-addon"
    client = mqtt.Client(
        client_id=client_id,
        protocol=mqtt.MQTTv5,
        userdata={"controller": controller},
    )
    if user:
        client.username_pw_set(user, password or "")

    def _on_connect(client, userdata, flags, reason_code, properties):
        try:
            rc_val = int(getattr(reason_code, "value", reason_code))
        except Exception:
            rc_val = int(reason_code) if isinstance(reason_code, (int,)) else 0
        try:
            client.publish(
                f"{base}/_diag",
                json.dumps({"event": "on_connect", "rc": rc_val}),
                qos=0,
                retain=False,
            )
        except Exception:
            pass
        logger.info({"event": "on_connect", "base": base, "rc": rc_val})
        try:
            client.subscribe(f"{base}/_ping", qos=0)
        except Exception:
            pass
        ctrl = None
        if isinstance(userdata, dict):
            ctrl = userdata.get("controller")
        elif hasattr(userdata, "controller"):
            ctrl = userdata.controller
        else:
            ctrl = userdata
        if ctrl is None:
            logger.warning({
                "event": "flat_handlers_attach_skip",
                "reason": "no_controller",
            })
            try:
                client.publish(
                    f"{base}/_diag",
                    json.dumps({
                        "event": "flat_handlers_attach_skip",
                        "reason": "no_controller",
                    }),
                    qos=0,
                    retain=False,
                )
            except Exception:
                pass
            return
        try:
            attach_flat_command_handlers(client, base, ctrl)
            client.publish(
                f"{base}/_diag",
                json.dumps({"event": "flat_handlers_attached", "base": base}),
                qos=0,
                retain=False,
            )
            logger.info({"event": "flat_handlers_attached", "base": base})
        except Exception as e:
            logger.warning({
                "event": "flat_handlers_attach_error",
                "err": repr(e),
            })
            try:
                client.publish(
                    f"{base}/_diag",
                    json.dumps({
                        "event": "flat_handlers_attach_error",
                        "err": repr(e),
                    }),
                    qos=0,
                    retain=False,
                )
            except Exception:
                pass

    def _on_message(client, userdata, msg):
        if msg.topic.endswith("/_ping"):
            try:
                client.publish(
                    f"{base}/_pong",
                    json.dumps({"ts": int(time.time())}),
                    qos=0,
                    retain=False,
                )
            except Exception:
                pass

    client.on_connect = _on_connect
    client.on_message = _on_message
    client.connect(host, int(port), keepalive=keepalive)
    client.loop_start()
    return client
