import os
import unittest
from unittest.mock import patch, MagicMock

class TestDiscoveryPublisher(unittest.TestCase):
    @patch("bb8_core.bb8_presence_scanner.publish_discovery")
    @patch("bb8_core.mqtt_dispatcher.publish_discovery")
    def test_scanner_only_discovery_when_bridge_telemetry_enabled(self, mock_dispatcher_discovery, mock_scanner_discovery):
        # Set environment/config to enable bridge telemetry
        os.environ["ENABLE_BRIDGE_TELEMETRY"] = "1"
        # Simulate main entry or dispatcher startup
        from bb8_core.mqtt_dispatcher import start_mqtt_dispatcher
        # Provide minimal args to avoid real MQTT connection
        start_mqtt_dispatcher(controller=MagicMock())
        # Assert dispatcher discovery was NOT called
        mock_dispatcher_discovery.assert_not_called()
        # Assert scanner discovery WAS called (at least once)
        self.assertTrue(mock_scanner_discovery.called)

if __name__ == "__main__":
    unittest.main()
