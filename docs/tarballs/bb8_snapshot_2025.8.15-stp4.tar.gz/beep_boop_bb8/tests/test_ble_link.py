import threading
import time
from bb8_core.ble_link import BLELink

def test_ble_link_thread_lifecycle():
    # Use dummy callbacks
    def on_connected(val): pass
    def on_rssi(val): pass
    link = BLELink("00:11:22:33:44:55", on_connected, on_rssi)
    link.start()
    # Wait briefly for thread to start
    time.sleep(0.1)
    assert link._thread is not None
    assert link._thread.is_alive()
    link.stop()
    time.sleep(0.1)
    assert not link._thread.is_alive()
