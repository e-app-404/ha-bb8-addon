from __future__ import annotations
from typing import TYPE_CHECKING
import asyncio
from typing import Optional, Callable
from .types import (
    BoolCallback,
    OptIntCallback,
)
if TYPE_CHECKING:
    from .bridge_controller import BridgeController as _BridgeControllerHint
from bleak import BleakClient, BleakScanner

class BLELink:
    def __init__(self, mac: str, on_connected: Callable[[bool], None], on_rssi: Callable[[Optional[int]], None]):
        self.mac, self.on_connected, self.on_rssi = mac, on_connected, on_rssi
        self._stop = False
        self._loop = None
        self._thread = None

    def start(self):
        import logging, threading
        log = logging.getLogger(__name__)
        if self._thread: return
        def _runner():
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            log.info({"event": "ble_link_started", "mac": self.mac})
            asyncio.run_coroutine_threadsafe(self._run(), self._loop)
            self._loop.run_forever()
        self._thread = threading.Thread(target=_runner, name="ble-loop", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop = True
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=3)

    async def _run(self):
        import logging
        log = logging.getLogger(__name__)
        backoff = [1,2,5,5,5]; i = 0
        first_rssi = True
        while not self._stop:
            try:
                dev = await BleakScanner.find_device_by_address(self.mac, timeout=5.0)
                rssi = getattr(dev, "rssi", None) if dev else None
                log.info({"event": "ble_link_scan_result", "mac": self.mac, "rssi": rssi, "dev": str(dev)})
                self.on_rssi(rssi)
                if first_rssi:
                    log.info({"event": "ble_link_first_rssi", "mac": self.mac, "rssi": rssi})
                    first_rssi = False
                if not dev:
                    log.info({"event": "ble_link_no_device", "mac": self.mac})
                    await asyncio.sleep(backoff[min(i,4)]); i+=1; continue
                async with BleakClient(self.mac) as cl:
                    self.on_connected(True); i = 0
                    log.info({"event": "ble_link_connected", "mac": self.mac})
                    _ = cl.is_connected
                    while cl.is_connected and not self._stop:
                        dev = await BleakScanner.find_device_by_address(self.mac, timeout=3.0)
                        rssi = getattr(dev, "rssi", None) if dev else None
                        log.info({"event": "ble_link_poll_rssi", "mac": self.mac, "rssi": rssi, "dev": str(dev)})
                        self.on_rssi(rssi)
                        await asyncio.sleep(5)
            except Exception as e:
                log.warning({"event": "ble_link_error", "mac": self.mac, "error": repr(e)})
            finally:
                self.on_connected(False)
                log.info({"event": "ble_link_disconnected", "mac": self.mac})
                await asyncio.sleep(backoff[min(i,4)]); i+=1

