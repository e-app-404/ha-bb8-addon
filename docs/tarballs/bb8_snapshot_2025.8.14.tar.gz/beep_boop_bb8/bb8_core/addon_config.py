from __future__ import annotations
import os, json, yaml, logging
from typing import Dict, Tuple

LOG = logging.getLogger(__name__)

def _load_options_json() -> Dict:
    try:
        with open("/data/options.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _load_yaml_cfg() -> Dict:
    for p in ("/addons/local/beep_boop_bb8/config.yaml", "/app/config.yaml"):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            continue
    return {}

def _pick(key: str, env: Dict, opt: Dict, yml: Dict, default):
    if key in env and env[key] not in ("", None):
        return env[key], "env"
    if key in opt and opt[key] not in ("", None):
        return opt[key], "options"
    if key in yml and yml[key] not in ("", None):
        return yml[key], "yaml"
    return default, "default"

def load_config() -> Tuple[Dict, Dict]:
    """Return (cfg, src) where src maps key -> 'env'|'options'|'yaml'|'default'."""
    env = dict(os.environ)
    opt = _load_options_json()
    yml = _load_yaml_cfg()

    cfg, src = {}, {}
    def setk(k, default):
        v, s = _pick(k, env, opt, yml, default)
        cfg[k], src[k] = v, s
    # Keys we care about
    setk("BB8_NAME", "BB-8")
    setk("BB8_MAC", "")
    setk("MQTT_HOST", "localhost")
    setk("MQTT_PORT", 1883)
    setk("MQTT_USERNAME", "")
    setk("MQTT_PASSWORD", None)
    setk("MQTT_BASE", "bb8")
    setk("ENABLE_BRIDGE_TELEMETRY", "0")
    setk("TELEMETRY_INTERVAL_S", 20)
    setk("ADDON_VERSION", "unknown")
    return cfg, src

def log_config(cfg: Dict, src: Dict, logger: logging.Logger):
    lines = [
        "[DEBUG] Effective configuration (value ⟂ source):",
        f"  BB8_NAME='{cfg['BB8_NAME']}' ⟂ {src['BB8_NAME']}",
        f"  BB8_MAC='{cfg['BB8_MAC']}' ⟂ {src['BB8_MAC']}",
        f"  MQTT_HOST='{cfg['MQTT_HOST']}' ⟂ {src['MQTT_HOST']}",
        f"  MQTT_PORT={cfg['MQTT_PORT']} ⟂ {src['MQTT_PORT']}",
        f"  MQTT_USER='{cfg['MQTT_USERNAME']}' ⟂ {src['MQTT_USERNAME']}",
        f"  MQTT_PASSWORD={'***' if cfg['MQTT_PASSWORD'] else None} ⟂ {src['MQTT_PASSWORD']}",
        f"  MQTT_BASE='{cfg['MQTT_BASE']}' ⟂ {src['MQTT_BASE']}",
        f"  ENABLE_BRIDGE_TELEMETRY={cfg['ENABLE_BRIDGE_TELEMETRY']} ⟂ {src['ENABLE_BRIDGE_TELEMETRY']}",
        f"  TELEMETRY_INTERVAL_S={cfg['TELEMETRY_INTERVAL_S']} ⟂ {src['TELEMETRY_INTERVAL_S']}",
        f"  Add-on version: {cfg['ADDON_VERSION']} ⟂ {src['ADDON_VERSION']}",
    ]
    logger.debug("\n" + "\n".join(lines))
