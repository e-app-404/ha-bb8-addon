# Patchlog: controller.py@roll_interface_alignment

## Summary

- Added: roll_mode and reverse_flag parameters to BB8Like Protocol and BB8Controller.roll for spherov2 compatibility
- Reason: Aligns BB8 control interface with spherov2's command structure for forward compatibility
- Risk Score: Low (additive, preserves backward compatibility)
- Governance Tags: [interface, compatibility, spherov2, forward-compat]

## Diff

```diff
# src/ha_sphero_bb8/controller.py
-class BB8Like(Protocol):
-    def roll(self, heading: int, speed: int): ...
+class BB8Like(Protocol):
+    def roll(self, speed: int, heading: int, roll_mode=None, reverse_flag=None, timeout: float = None, boost: bool = False): ...
    def stop(self): ...
    def set_main_led(self, r: int, g: int, b: int): ...
    def get_battery_voltage(self) -> float: ...
    def get_battery_percentage(self) -> int: ...

-    def roll(self, speed: int, heading: int, timeout: Optional[float] = None, boost: bool = False) -> Dict[str, Any]:
+    def roll(self, speed: int, heading: int, roll_mode=None, reverse_flag=None, timeout: Optional[float] = None, boost: bool = False) -> Dict[str, Any]:
         """
         Enhanced roll command with device core capabilities and spherov2 compatibility.
         Args:
             speed: Motor speed (0-255)
             heading: Direction in degrees (0-359)
+            roll_mode: Sphero roll mode (optional, for spherov2 compatibility)
+            reverse_flag: Sphero reverse flag (optional, for spherov2 compatibility)
             timeout: Optional timeout in seconds
             boost: Enable boost mode
         Returns:
             Command result with diagnostics
         """
         if not self.device_connected:
             return self._create_error_result("roll", "Device not connected")

         self.command_count += 1
         self.last_command = "roll"

         try:
             if self.motor_control:
                 # Use enhanced motor control
-                result = self.motor_control.enhanced_roll(speed, heading, timeout, boost)
+                result = self.motor_control.enhanced_roll(speed, heading, timeout, boost)
                 return self._format_command_result(result)
             else:
                 # Fall back to basic device control
-                if hasattr(self.device, 'roll'):
-                    device_result = self.device.roll(speed, heading, timeout)
+                if hasattr(self.device, 'roll'):
+                    device_result = self.device.roll(speed, heading, roll_mode, reverse_flag, timeout)
                     return {
                         "success": True,
                         "command": "roll",
                         "result": device_result,
                         "enhanced": False
                     }
                 else:
                     return self._create_error_result("roll", "No roll capability available")

         except Exception as e:
             self.error_count += 1
             self.logger.error(f"Roll command failed: {e}")
             return self._create_error_result("roll", str(e))
```

## Kybernetes Comments

This patch ensures the BB8 controller interface is forward-compatible with spherov2's command structure by adding roll_mode and reverse_flag parameters. This is a low-risk, additive change that does not break existing usage.
