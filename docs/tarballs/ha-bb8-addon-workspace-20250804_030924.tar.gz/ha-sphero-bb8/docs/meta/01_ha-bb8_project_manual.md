# ha-sphero-bb8: Strategic Narrative, System Overview, and Project Guidance

⸻

1. Project Mission & Strategic Goal

What We’re Building:
A robust, real-world bridge between Home Assistant and the Sphero BB-8 robot. Our purpose is to enable BB-8 to participate in smart home automations—not as a novelty, but as a truly integrated actor: responding to presence, events, and schedules with movement, lights, or sound, all controlled by Home Assistant (HA) via MQTT.
The “why”: We want smart home automations to extend into the tangible world—BB-8 moves, blinks, or makes noise as part of your living environment, triggered by real events.

What “Success” Means:
	•	Evidence-driven MVP: Not just code that “should” work, but hardware actions with logs, photos, and videos as proof.
	•	Every success is empirical: Passing a test means the physical BB-8 did something, and we can show it happened.

Why This Matters:
	•	For users: Seamless, extensible smart home magic—including a robot friend.
	•	For devs/ops: Clear boundaries, robust logs, and minimum ambiguity; easy to maintain, extend, or troubleshoot.
	•	For the project: A pattern for real-world “hardware-in-the-loop” integration, focused on outcomes—not just features.

⸻

2. System Overview: Roles, Boundaries, & Key Flows

Actors & Responsibilities:
	•	Home Assistant (HA): The brains. Orchestrates automations, triggers, and routines.
	•	MQTT Broker (Mosquitto): The message bus. Delivers commands and receives feedback.
	•	BB-8 Bridge (this project): The translator. Listens to MQTT, sends BLE commands to BB-8, reports back.
	•	BB-8 Robot: The actor. Performs actions; reports basic state/feedback.
	•	User: Triggers automations via presence, app, routines, or sensors.

System Boundaries & Modes:
	•	Peripheral/Bridge Mode:
	•	Home Assistant is the only “master.”
	•	BB-8 Bridge is a passive relay; it never makes automation decisions.
	•	BB-8 never pairs directly to HA; only via the bridge tool.

High-Level Sequence:
	1.	Trigger: User event detected in HA (arrives home, alarm, schedule).
	2.	MQTT Command: HA emits MQTT message to the right topic (e.g., bb8/command/led).
	3.	Bridge Receives: Bridge tool parses MQTT and relays command to BB-8 via BLE.
	4.	Act: BB-8 executes the action (move, blink, sound).
	5.	Status/Feedback: Bridge receives confirmation/status, posts it to MQTT.
	6.	HA Updates: HA sees the update, triggers further actions if needed.

⸻

3. Technical Architecture Narrative

Visual Sequence Diagram:

sequenceDiagram
    participant HA as Home Assistant
    participant MQTT as Mosquitto Broker
    participant Bridge as BB-8 MQTT Bridge
    participant BB8 as BB-8 Robot

    HA->>MQTT: Publish bb8/command/led ({"r":0,"g":255,"b":0})
    MQTT->>Bridge: Receives command
    Bridge->>BB8: BLE write (set color)
    BB8-->>Bridge: (Ack/status)
    Bridge->>MQTT: Publish bb8/status (online, battery, ack)
    MQTT->>HA: Update BB-8 entity state

Stepwise Walkthrough:
	•	Home Assistant UI/automation triggers an MQTT message (e.g., turn BB-8’s lights green when someone comes home).
	•	MQTT Broker delivers the command on topic bb8/command/led.
	•	Bridge listens to this topic, parses JSON, translates it to BLE commands.
	•	BLE Adapter (Bleak, etc.) talks to BB-8 robot, which executes action.
	•	Robot’s status or acknowledgment (if available) goes back up via BLE → Bridge → MQTT → HA for live status and further automations.

Component Roles (Where to Look for What):
	•	src/ha_sphero_bb8/mqtt_handler.py: Manages MQTT connection, subscription, and publishing.
	•	src/ha_sphero_bb8/mqtt_dispatcher.py: Maps MQTT topics to BB-8 commands.
	•	src/ha_sphero_bb8/controller.py: Device logic and abstraction; “what does roll mean?”
	•	src/ha_sphero_bb8/device_core/adapters/: BLE adapters (Bleak, simulation).
	•	src/ha_sphero_bb8/run_mqtt.py: Main entrypoint for running the bridge tool.

⸻

4. MVP Horizon and Project Phasing

MVP Definition (“What’s Done”)
	•	Physical BB-8 responds to MQTT commands from Home Assistant
	•	Every command and feedback loop is evidenced: logs, screenshots, or video (no “just believe me”).
	•	No simulation-only passes. Real device, real action.
	•	Known protocol/adapter mismatches are documented as issues, not blockers.

What’s Not Included (Yet)
	•	Sim-only flows or test scripts that don’t hit real hardware
	•	Full Home Assistant UI widgets, auto-discovery, or extended sensor features (can be future work)

Phased Roadmap
	•	Phase 1: Hardware-in-the-loop MVP (prove full round-trip from HA to BB-8 and back)
	•	Phase 2: Adapter/protocol refactor for clarity and ease of extension
	•	Phase 3: Richer automations, full HA entity integration, possibly support for additional robots/devices

⸻

5. Development Breakdown & Activities

Jobs To Be Done (JTBD) Table

JTBD ID	Description	Owner	Status	Acceptance Criteria
JTBD-01	BLE Connect & LED Proof	Pythagoras	Complete	Log + video/photo of device lighting up, MAC-stamped
JTBD-02	MQTT → BB-8 Command Path	Pythagoras	In Progress	MQTT command triggers real BB-8 action, with logs/artifacts
JTBD-03	Feedback Status Reporting	TBD	Pending	BB-8 feedback/status visible in HA, logged, artifacted
JTBD-04	Protocol/Adapter Alignment	TBD	Pending	No signature mismatches or unhandled errors in live flow
JTBD-05	Full Home Assistant Demo	TBD	Pending	End-user triggers BB-8 via HA UI, action and status logged

Owner = Pythagoras/Lead unless otherwise reassigned; status tracked in audit logs.

Dependencies
	•	Home Assistant (latest stable), Mosquitto MQTT broker
	•	MacBook/Pi/Linux box with BLE and Python 3.9+
	•	Sphero BB-8, charged and awake
	•	Correctly configured MQTT topics and credentials

Constraints
	•	Only one “master” (HA); bridge never initiates actions
	•	BLE connection is exclusive—no direct pairing between BB-8 and HA
	•	Project only passes when empirical (hardware) proof is available

Opportunities
	•	Easily extendable to other Sphero devices via adapter refactor
	•	HA automations can get richer as bridge becomes more robust
	•	Diagnostic/artifact-driven debugging supports rapid scaling and troubleshooting

⸻

6. Evidence, Audit, and Governance

How We Know It Works:
	•	Artifacts: All logs (with MAC, timestamp, topic), screenshots, videos go in artifacts/
	•	Artifact naming: JTBD-<ID>_<type>_<timestamp>_<mac>.ext
	•	Audit table: Every JTBD mapped to evidence for compliance and closure

Empirical Focus:
Every “pass” or “completion” requires proof. No theoretical “works on my machine.”

Escalation Protocol:
	•	Blocked? Archive all logs, escalate with 1-line root cause guess.
	•	Protocol/adapter mismatch? Log as “known issue,” but do not block MVP unless core command fails.

⸻

7. Lessons, Rationale, and Living Guidance

What We’ve Learned:
	•	Always test from the highest integration boundary—start with HA, not “just the bridge.”
	•	Local “vendor” libraries (e.g., spherov2) must be loaded predictably; “editable install” mode is your friend.
	•	Avoid chasing theoretical completeness—focus on real hardware success.
	•	Logging, artifacts, and evidence are more valuable than green checks in CI.

Best Practices:
	•	Always reset/restart bridge after BLE disconnects
	•	Decouple smart logic (in HA) from device control (in the bridge)
	•	Escalate and log every protocol or adapter drift for future devs

Hand-Off Guidance:
	•	See artifact directory for last known good logs and evidence
	•	Read the latest audit trail and protocol manifest before major changes
	•	When in doubt, prioritize “show, not tell”: prove with hardware and logs

⸻

8. Appendices

MQTT Topic Reference

Topic	Payload Example	Action
bb8/command/led	{“r”:255, “g”:140, “b”:0}	Set BB-8 LED color
bb8/command/move	{“speed”:100, “heading”:0}	Move BB-8 forward
bb8/command/stop	{}	Stop BB-8
bb8/command/sound	{“sound”:“bleep”}	Play sound (if supported)
bb8/command/diagnostics	{}	Request status/battery

Directory/File Reference
	•	src/ha_sphero_bb8/ — main source code
	•	artifacts/ — logs, screenshots, videos
	•	meta/ — governance, manifests, audit logs
	•	requirements.txt, pyproject.toml — dependencies

Example Configuration

export MQTT_USER="mqtt_bb8"
export MQTT_PW="mqtt_bb8"
python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker 192.168.0.129 --port 1883 --username $MQTT_USER --password $MQTT_PW

Artifact Naming Conventions

JTBD-02_log_20250621_259ED00E30262568.txt
JTBD-01_video_20250620_259ED00E30262568.mp4

⸻

This document serves as a living reference for the ha-sphero-bb8 project, guiding both current and future contributors through the strategic vision, technical architecture, and operational practices that define our work. It is designed to evolve with the project, ensuring clarity, focus, and empirical success in integrating Sphero BB-8 with Home Assistant.

⸻

End of Narrative Documentation
