# Strategic Briefing: Sphero BB-8 Integration – "Peripheral/Bridge" Mode (JTBD-02b+)

## Executive Summary

* **Project focus has shifted:** The Sphero BB-8 orchestration tool will no longer attempt to act as the “primary” controller or MQTT broker master.
* **Home Assistant is now the canonical "master"** for device orchestration, event triggering, and automation logic.
* The Macbook-based orchestration tool will operate strictly as a **peripheral/bridge**—listening and responding to MQTT commands from HA and reporting sensor/status back, without direct device ownership outside HA’s control.

### Strategic Pivot & Governance Clarification (Strategos)

 • **Project Focus**: The only success metric for the current phase is empirical hardware validation. Every command, state, and log must be provable by direct interaction with a physical BB-8.
 • **Audit Philosophy**: Protocol mismatches, “not implemented” errors, or unhandled handler cases are not blockers—they are explicitly logged as strategic learning for future improvement.
 • **Governance**: All acceptance, artifacts, and logs are to be auditable, timestamped, and MAC-tagged for full traceability.
 • **Next Steps**: Immediate priorities are **(1) working round-trip control** and **(2) evidence collection**. Refactoring, coverage, and feature extension is future work, not required for MVP acceptance.

⸻

## Rationale & Learnings

* **Root cause of previous blockers:** BB-8 BLE connection instability was traced to device “ownership” conflicts between Home Assistant (HA) and direct BLE/MQTT orchestration tools.
* **Design decision:** For long-term stability, security, and usability, BB-8 must be “owned” by the platform best equipped for high-availability and automation—**HA via Mosquitto**.

⸻

## Technical Implications

* **The orchestration tool is now a secondary agent:**

  * It will *never* claim exclusive control of the BB-8.
  * It only connects to BB-8 when explicitly triggered by HA, respecting HA’s device locks and broker assignments.
  * All events, triggers, and responses are initiated/mediated by HA.

* **New “Peripheral/Bridge” Mode:**

  * Designed for minimal footprint and full auditability.
  * Publishes device state, battery, and sensor info as read-only topics.
  * Listens for “trigger” commands and only acts when given explicit, time-limited permission.

⸻

## Deliverables

* **New architecture diagram** in Mermaid syntax (delivered to Engineering/PMO).
* **Refreshed README and architecture documentation** to reflect “peripheral/bridge” constraints and operational boundaries.
* **All CLI/README guidance now emphasizes “peripheral/bridge” usage**—no instructions for device “master” mode or direct hardware arbitration.

⸻

## Risks & Mitigations

* **Risk:** HA downtime or broker misconfiguration still disrupts the BB-8 control path.
* **Mitigation:** Robust diagnostics, fallback to simulation for demo/testing, and clear audit logs for all connection attempts and failures.
* **Operator guidance:** All logs and troubleshooting are now targeted toward HA integration scenarios, with explicit warnings when “ownership” conflict is detected.

⸻

## Next Steps

* **Empirical validation:** Demonstrate successful BB-8 actuation from an HA-driven MQTT event, with full log/audit trail.
* **Documentation:** Complete the new README, architecture doc, and onboarding quickstart for “peripheral/bridge” mode.
* **Report back** to PMO/Strategos for phase closure and planning of full HA-integrated use cases.
