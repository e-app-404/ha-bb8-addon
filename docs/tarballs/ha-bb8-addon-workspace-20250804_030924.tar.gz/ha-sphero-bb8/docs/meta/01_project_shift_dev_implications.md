# Project Shfit Impact

How this shift in project steering affects the development pipeline is a crucial question and reflects a mature, executive-level perspective on how technical strategy must adapt to evolving business/operational goals. Here’s a structured answer tailored for your new direction—pivoting from a stand-alone app/orchestration tool to a Home Assistant Add-on (BB-8 as a “peripheral” in a Home Assistant ecosystem, with HA as the master):

## 1. How Does This Change the Tech Stack?

From:
 • Standalone Python CLI app with heavy direct MQTT and BLE/BLEAK logic on your MacBook.
 • User (you) as primary operator, app as orchestrator.

To:
 • Home Assistant Add-on (or Integration/Custom Component): The primary orchestration logic moves inside the Home Assistant runtime (Docker or HassOS).
 • MQTT is likely brokered via Mosquitto inside HA, not directly exposed to the MacBook except for diagnostics.
 • BLE/BLEAK logic must run within the Home Assistant add-on container, using the host’s Bluetooth stack.
 • All configuration, triggers, and automations are written in Home Assistant YAML or via UI.

Additional Home Assistant concepts enter the stack:
 • Add-on: Dockerized service managed by HA Supervisor, runs alongside HA core.
 • Custom Integration: If you want HA to directly discover/control BB-8 as a device/entity.
 • MQTT Discovery: For HA to dynamically recognize devices/entities you expose.

⸻

## 2. What Work Remains Relevant? What Needs Changing?

You Can Keep:
 • All the BB-8 hardware abstraction code: adapters for BLE, Sphero SDK, simulation logic. This can become a library/module in your add-on.
 • The robust MQTT command translation and handler code, with minor refactoring.
 • The empirical logging/diagnostics approaches: these are even more valuable inside a HA container, where debugging is harder.
 • Your BLE error handling, retries, and connection management.

What You Need to Change or Purge:
 • CLI/Terminal orchestration logic: All user interaction must move to the HA Add-on config panel, or via MQTT.
 • File-based audit logs may need to be relocated or output to HA log streams.
 • Direct MacBook/MacOS-specific logic should be removed. BLE must run inside the add-on container.
 • Any code assuming “interactive shell prompts” or retry-from-terminal flows must be refactored—automation, not manual control, is now the target.

What Needs to be Added:
 • Add-on entrypoint (Dockerfile, config.yaml): Containerizes and runs your service as an HA add-on.
 • Configuration schema for the add-on: So users can specify BB-8 MAC, BLE parameters, MQTT topics, etc. via the HA UI.
 • MQTT auto-discovery logic (optional): So BB-8 entities (sensors, switches, triggers) appear in HA automatically.
 • Service calls or HA automation endpoints: For triggering BB-8 actions from automations/scripts in HA.

⸻

## 3. Development Roadmap Shift

Short-Term Roadmap (Transition)

 1. Modularize: Move all device, BLE, and MQTT logic into a package suitable for Docker.
 2. Create Add-on Scaffolding: Write a minimal Dockerfile and config.yaml for HA add-on format.
 3. Refactor Entrypoints: Replace CLI/main logic with a service entrypoint compatible with add-on lifecycle (start/stop/restart).
 4. Move Configuration to HA: Remove argparse/CLI, accept config via HA add-on options or env vars.
 5. Test BLE in Container: Ensure add-on can access BLE hardware on HA host (may require privileged: true or D-Bus mounting).
 6. Integrate with HA Automations: Expose MQTT or REST endpoints for HA triggers.

Mid-Term Roadmap
 • Add MQTT Discovery and native HA entity registration for full integration.
 • Support HA event publishing (BB-8 triggers automations).
 • Polish logs, diagnostics, and error reporting to match HA conventions.
 • Release as a custom add-on, test with other HA users.

⸻

## 4. What to Purge, What to Merge

 • Purge: Interactive CLI UX, OS-specific diagnostics not relevant to Linux/Docker, local terminal workflow.
 • Merge: All robust, proven device interaction, BLE abstraction, MQTT handling, error logging, and diagnostics.

⸻

## 5. Timeline & Resourcing Impact

 • Initial add-on proof-of-concept can often be built in 2-5 days if existing code is modular.
 • Full integration (HA discovery, UI config, etc.) is 1-2 weeks depending on polish and testing.
 • Main risk: BLE inside Docker requires host access; test on your actual HA hardware early.

⸻

## 6. Strategic/Executive Advice

 • All future work should target Home Assistant as the only operator.
 • Your “standalone” tool becomes a test harness or developer script only.
 • Invest in configuration, reliability, and HA UX rather than CLI polish.
 • Prioritize BLE connection robustness and empirical diagnostics, as HA users expect plug-and-play reliability.

⸻

## Summary Table:

| Area           | Keep          | Refactor                | Purge                |
|----------------|---------------|-------------------------|----------------------|
| BLE Logic      | ✅            | Dockerize               | OS X specifics       |
| MQTT Handler   | ✅            | HA add-on entry         | CLI flags/UI         |
| Logging        | ✅            | To HA logs              | Terminal UX          |
| Config         | ❌            | HA UI/Env var           | argparse             |
| Orchestration  | ❌            | HA automations          | Standalone scripts   |
| Testing        | ✅ (sim)      | Add-on tests            | CLI-only tests       |

⸻

If you want:
 • Add-on boilerplate (Dockerfile, config.yaml, run script)
 • Example Home Assistant configuration for automations/entities
 • Templates for README/tech documentation in add-on format

Just say the word—Pythagoras can provide these immediately.
