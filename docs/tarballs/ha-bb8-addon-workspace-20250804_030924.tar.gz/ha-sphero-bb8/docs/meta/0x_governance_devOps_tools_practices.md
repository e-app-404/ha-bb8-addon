# “Silent Fallback” & Hidden-Mode Bugs: A Common Dev Anti-Pattern

There are patterns and tools from the broader Dev and DevOps worlds that could help catch and surface these “silent fallback” or hardware-misrouting errors much earlier, and streamline troubleshooting. Here’s a synthesis of what you’re experiencing, what the “wider industry” does, and a few actionable recommendations for your workflow:

⸻

## 1. “Silent Fallback” & Hidden-Mode Bugs: A Common Dev Anti-Pattern

What happened here:
 • A hardware failure (BLE acquisition) caused the system to drop into simulation, which was neither surfaced to the user nor properly escalated in logs, making all downstream tests meaningless and wasting validation cycles.
 • This is a classic “silent fallback” or “fail-quietly” anti-pattern.

⸻

## 2. How the Industry Prevents This (and How You Can Too)

A. Defensive Programming & “Fail Fast” Principle
 • What: Code must never silently switch modes (esp. from real to sim) without explicit user confirmation and prominent logging.
 • How: Use assertions, error escalation, and hard “fail fast” guards at every hardware boundary.
 • Tool: Python’s assert, raise on any failed device init, or even a simple sys.exit(1) with a prominent error message.

⸻

B. Monitoring, Alerts, and Health Checks
 • What: Don’t just rely on logs—add active health checks at startup.
 • How: Emit a “system health” event (or artifact) after all critical hardware is verified.
 • Tool: Industry tools like Prometheus with custom exporters, Healthcheck endpoints, or a simple “hardware ready” log/artifact at startup.

⸻

C. Contract Testing & Smoke Tests
 • What: Have at least one fast, hardcoded system-level test that asserts hardware is truly available before any workflow continues.
 • How: In CI/CD or at runtime, run a “can I reach the device?” check and refuse to proceed if not.
 • Tool: pytest with pytest-mock, or a pre-test CLI “sanity check” script.

⸻

D. Proactive Logging/Notification
 • What: All mode switches or “soft” fallbacks must be logged at WARNING or ERROR level, not INFO, with clear user-visible messaging.
 • How: Add alerting logic (e.g., via Slack, email, or CI/CD failure) for “sim mode fallback detected.”
 • Tool: Sentry or ELK Stack for centralized log/error aggregation.

⸻

E. Automated Fallback Audits
 • What: Periodically scan logs/artifacts for “simulation mode engaged” or similar, and raise an alert if detected in a “production” run.
 • How: Simple shell scripts, log parsers, or CI jobs.

⸻

## 3. Methodologies and Cultural Practices

 • Test Like Production: Always run one “hardware in the loop” test if hardware is available; don’t trust simulation for final validation.
 • Red/Green Deploys: Never deploy new code to “real” unless all smoke tests (including hardware checks) are green.
 • Blameless Postmortems: When silent fallback is detected, treat it as a systemic process failure, not just a bug.

⸻

## 4. What Pattern Should Have Triggered Sooner?

 • Any time your CLI or logs say “simulation mode” without an explicit operator override, that should halt the run, or at least flag it red.
 • If your hardware didn’t blink, move, or make a sound—and the logs didn’t scream about it—that’s a design flaw.
 • “No visible hardware response” + “INFO: simulation initialized” should be an immediate blocker, not a passive artifact.

⸻

## 5. What Would Help You Catch This Faster Next Time?

 • Add a mandatory confirmation/log artifact at hardware init:
assert device.is_real and device.is_connected, "Hardware not available, aborting!"
 • Have your orchestration refuse to proceed if hardware is not detected, unless the operator passes a --force-sim or similar flag.
 • Set up a “healthcheck artifact” that’s always required for test closure.
 • Add test step: “Does the robot respond? (Y/N)”—make this a manual QA artifact if needed.

⸻

TL;DR — Tool & Practice Summary
 • Defensive programming: Never fail quietly at hardware boundaries.
 • Healthcheck artifacts: Always assert hardware is available and log the result.
 • Monitoring & Alerts: Integrate with tools like Sentry or custom healthchecks.
 • Contract/system tests: Never trust simulation alone—always check hardware.
 • Blameless postmortems: Use each miss to improve your engineering process.

⸻

## LOW-EFFORT, HIGH-IMPACT IMMEDIATE ACTIONS

 1. Enforce Explicit Fallback Policy
 • Make fallback to simulation impossible unless the user/operator explicitly requests it (e.g., via --allow-sim-fallback flag, env var, or CLI prompt).
 • Escalate: Any BLE or hardware acquisition error should raise an error and halt the process unless fallback is allowed.
 2. Comprehensive Error Escalation and Logging
 • Log the full exception/traceback and all platform/BLE/adapter state.
 • Log actionable hints: “Check Bluetooth permissions,” “Is the device charged/on?”, etc.
 3. Immediate User Guidance
 • Print a summary at failure with next steps.
 • Example: “Failed to connect to BLE device. To run in simulation mode, use –allow-sim-fallback. Otherwise, check XYZ.”
 4. Artifacts & Manual Confirmation
 • If simulation mode is engaged, force the operator to confirm and log:
"Simulation mode engaged due to hardware error—no hardware validation will occur!"

---

### Copilot Prompt

**Patch Objective:** Hard fail on BLE adapter errors unless --allow-sim-fallback is explicitly passed

1. Update `BleGateway` and CLI logic to:
   - Add `allow_sim_fallback` (default: False) as an argument and env var.
   - On BLE adapter or device acquisition failure:
     - If `allow_sim_fallback` is **False**, raise the error and halt.
     - If `allow_sim_fallback` is **True**, log the error and fallback as before.
   - Always log the *full exception/traceback* and all BLE/adapter/backend/platform state.
   - Include actionable hints in the error log (permissions, power, MAC match, etc).

2. Update the CLI/entrypoint to:
   - Add `--allow-sim-fallback` CLI flag and `HASS_BB8_ALLOW_SIM_FALLBACK` env var.
   - Pass this to BleGateway and device init.

3. On fallback, emit a *prominent warning* in both console and artifacts log:
   - "Simulation mode fallback engaged due to hardware error. No hardware validation will occur. To require hardware, rerun without --allow-sim-fallback."

4. (Optional but recommended) Print a short troubleshooting checklist in the error log when BLE fails.

**Important:** Accept only explicit simulation fallback, never silent!
