# 🟦 BB-8 Hardware Integration MVP Manifest (JTBD Table, 2025-06-19, v1.1 — Governance-Enhanced)

## 1. Overview: “From Home Assistant to BB-8 and Back”

At minimum, the project must empirically orchestrate a round-trip between:

  [Home Assistant] → [`MQTT`] → [Python App/Adapter Layer] → [`BLE` Adapter] → [BB-8 Hardware]

…and the full feedback path:

  [BB-8 Hardware] → [`BLE` Adapter] → [Python App] → [`MQTT`] → [Home Assistant]

**NOTE:** Command flow *and* device feedback (ACK/status/data) are required for every core JTBD—absence of feedback means the flow is incomplete.

---

### 2. Protocol and Adapter Roles

#### A. Home Assistant (HA)

- Communicates using MQTT for device control, status, and feedback.
- Sends commands (as `MQTT messages`) and subscribes for state (as `MQTT topics`).
- Must display BB-8 as a live entity, named as `bb8_<serial|mac>` for audit clarity.

#### B. MQTT (Mosquitto Broker)

- Acts as the central message bus.
- Python integration “subscribes” to command topics (e.g., `bb8/move`), and “publishes” state/diagnostics (e.g., `bb8/status`).
- All feedback/status/ack topics must be defined and evidenced in tests (e.g., `bb8/status`, `bb8/ack`).

#### C. Python Application (ha_sphero_bb8)

**Key responsibilities:**

- **MQTT Handler/Dispatcher:** Receives MQTT commands and routes them to Python-side handlers.
- **Adapters:** Maps Python-side commands to BLE and parses responses.
- **Device Protocol/Interface (BB8Like):** Defines the contract for a BB-8-like device, ensuring any implementation (sim, real) behaves identically.
- **Feedback:** Surfaces all hardware/BLE responses (ACK/data) back to MQTT for Home Assistant.

#### Typical End-to-End Chain (with feedback)

 1. MQTT command received (e.g., move, rotate, LED).
 2. MQTT Handler parses topic/payload, dispatches to the right command handler.
 3. Command handler calls correct method on a BB-8 Adapter.
 4. BB-8 Adapter talks to BLE (spherov2, via BleakAdapter).
 5. BLE Adapter sends the command to the physical BB-8 over Bluetooth.
 6. BB-8 acts (moves, lights up, etc.), sends confirmation/data (ACK/status/diagnostic).
 7. Adapter captures response, passes it up to Python app.
 8. Handler/Dispatcher publishes feedback/status to MQTT.
 9. Home Assistant receives and updates UI/state.

---

### 3. Code Structure Mapping

Major Components in `ha-sphero-bb8`:

- `mqtt_handler.py` / `mqtt_dispatcher.py`:
  - Subscribe to command topics; dispatch incoming messages; publish status/diagnostics to feedback topics.
- `controller.py` / `bb8_protocol.py`:
  - Defines BB8Like protocol: abstract interface for all BB-8 operations (move, stop, LED, diag, etc.).
  - Real adapters/simulators must implement this.
- `device_core/adapters/bleak_adapter.py`:
  - Concrete BLE adapter using bleak (Python BLE library). Handles connect, send command, receive data, disconnect.
- `_vendor/spherov2` (local copy):
  - Sphero BLE protocol stack. Instantiate toy and adapter here.
- `bb8_control.py` and command modules:
  - High-level functions for movement, lights, diagnostics—called by dispatcher. Glue between handler and adapter.

---

### 4. End-to-End Flowchart (Command and Feedback)

```mermaid
flowchart LR
    classDef ha fill:#90caf9,stroke:#1976d2,stroke-width:2px
    classDef mqtt fill:#64b5f6,stroke:#1565c0,stroke-width:2px
    classDef pyapp fill:#42a5f5,stroke:#1565c0,stroke-width:2px
    classDef adapter fill:#1e88e5,stroke:#0d47a1,stroke-width:2px
    classDef ble fill:#1976d2,stroke:#0d47a1,stroke-width:2px
    classDef vendor fill:#1565c0,stroke:#0d47a1,stroke-width:2px
    classDef hardware fill:#0d47a1,color:#fff,stroke:#1976d2,stroke-width:3px

    HA["Home Assistant\n(UI/Automation)"]
    MQTT["MQTT Broker\n(Mosquitto)"]
    PythonApp["Python App\nha_sphero_bb8"]
    BB8Like["BB8Like Protocol\n(controller.py)"]
    BLEAdapter["BleakAdapter\n(bleak_adapter.py)"]
    VendorLib["spherov2\n(_vendor/spherov2)"]
    BB8["BB-8 Robot\n(Hardware)"]

    HAFeedback["Home Assistant\n(Status Update)"]
    MQTTFeedback["MQTT Feedback Topic"]
    PythonAppFeedback["Python App\n(Diag/Status)"]
    BB8LikeFeedback["BB8Like Protocol"]
    BLEAdapterFeedback["BleakAdapter\n(Parse Data)"]
    VendorLibFeedback["spherov2\n(Receive/Parse)"]
    BB8Feedback["BB-8\n(ACK/Data)"]

    class HA,HAFeedback ha
    class MQTT,MQTTFeedback mqtt
    class PythonApp,PythonAppFeedback pyapp
    class BB8Like,BB8LikeFeedback adapter
    class BLEAdapter,BLEAdapterFeedback ble
    class VendorLib,VendorLibFeedback vendor
    class BB8,BB8Feedback hardware

    HA -->|MQTT cmd| MQTT
    MQTT -->|subscribe| PythonApp
    PythonApp -->|dispatch| BB8Like
    BB8Like -->|call| BLEAdapter
    BLEAdapter -->|packet| VendorLib
    VendorLib -->|GATT| BB8

    BB8Feedback -.->|notify| VendorLibFeedback
    VendorLibFeedback -.->|parse| BLEAdapterFeedback
    BLEAdapterFeedback -.->|callback| BB8LikeFeedback
    BB8LikeFeedback -.->|return| PythonAppFeedback
    PythonAppFeedback -.->|publish| MQTTFeedback
    MQTTFeedback -.->|update| HAFeedback

    subgraph Legend [Legend]
      direction TB
      Cmd["--> : Command Flow (Down)"]
      Fbk["-.-> : Feedback Flow (Up)"]
    end

    subgraph MQTTLayer [MQTT Layer]
        MQTT
        MQTTFeedback
    end
    subgraph PythonLayer [Python Layer]
        PythonApp
        BB8Like
        BLEAdapter
        VendorLib
        PythonAppFeedback
        BB8LikeFeedback
        BLEAdapterFeedback
        VendorLibFeedback
    end
```

### 🏊 Swimlanes/Groups Overview

Group (Swimlane) Health Score Traffic Light Open JTBDs Comments/Status Summary
Strategos 2 🟥 3 Type annotation, var-annotated, and Optional errors
Strategos 1 🟥 2 Feature/integration tests missing, error tests only
Strategos 2 🟨 2 Vendor/3rd-party stubs/imports unresolved
Strategos 4 🟩 1 Hygiene/flattening complete, only docstring/README updates
Strategos 3 🟨 2 README, patchlog, docstring coverage needs expansion
Strategos 1 🟥 1 Test harness blocked, v1 acceptance blocked

Scoring Scale: 1 = major blocker; 3 = moderate risk; 5 = healthy/low risk

⸻

### 📋 Jobs to be Done (JTBDs) — with ID, Output Contract, Escalation, and Artifact Mapping

Instructions:

- Each JTBD is a standalone deliverable—evidence required, not “it should work.”
- Both command (top-down) and feedback (bottom-up) flows are mandatory. Missing feedback/ACK = INCOMPLETE.
- For each, submit all runtime artifacts: log, screenshot, video; timestamp; device MAC/serial.
- If blocked, attach log/artifact and a 1-line root cause guess, and escalate immediately (do not proceed to next JTBD without escalation).
- At end: submit mapping checklist JTBD ID → artifacts for audit.
- Environment details: OS, Python, BB-8 hardware, HA version, MQTT integration method, and BB-8 entity name must be documented at start of work.

⸻

| JTBD ID | Description                                                 | Assigned To | Group          | Output Validation                                                          | Acceptance Criteria                                                   | RACI                    |
| ------- | ----------------------------------------------------------- | ----------- | -------------- | -------------------------------------------------------------------------- | --------------------------------------------------------------------- | ----------------------- |
| JTBD-01 | Establish BLE connection to a physical BB-8 device          | Pythagoras  | Hardware       | BLE scan/connect logs; BB-8 lights/activates; video/photo                  | BB-8 connects, hardware proof (log/video/LED blink, device MAC shown) | Pythagoras/Strategos    |
| JTBD-02 | Send “move” command to BB-8 and confirm motion              | Pythagoras  | Hardware       | BB-8 moves on command; CLI/log matches; video                              | BB-8 moves as commanded; proof in video/log                           | Pythagoras/Strategos    |
| JTBD-03 | Send “rotate” command to BB-8 and confirm response          | Pythagoras  | Hardware       | BB-8 rotates; confirmation log; video                                      | BB-8 rotates, notifies system; hardware/log proof                     | Pythagoras/Strategos    |
| JTBD-04 | Send LED/light/color command; BB-8 lights up                | Pythagoras  | Hardware       | BB-8 lights flash/change; log/video                                        | Visual proof, log output                                              | Pythagoras/Strategos    |
| JTBD-05 | Request and receive diagnostics/status from BB-8            | Pythagoras  | Hardware       | Diagnostics data/log output; MQTT feedback shown                           | Diagnostics returned, parsed, and visible in log or MQTT              | Pythagoras/Strategos    |
| JTBD-06 | Confirm all commands receive BB-8 acknowledgment (ACK/data) | Pythagoras  | Hardware       | Log or MQTT output with ACK/data after command                             | ACK/status event for every command; no silent fails                   | Pythagoras/Strategos    |
| JTBD-07 | Cleanly disconnect from BB-8 hardware                       | Pythagoras  | Hardware       | Log/disconnect event; BB-8 powers down/LED off; photo/video                | Log and device state confirm disconnect                               | Pythagoras/Strategos    |
| JTBD-08 | BB-8 appears in Home Assistant UI as live device/template   | Pythagoras  | HA Integration | HA dashboard screenshot/log with BB-8 entity                               | BB-8 is visible, live in HA UI, correct entity name                   | Pythagoras/Strategos/HA |
| JTBD-09 | Status/events from BB-8 reflected live in Home Assistant    | Pythagoras  | HA Integration | BB-8 state changes reflected in HA instantly; screen recording/screenshots | Roundtrip of data seen in HA UI/log                                   | Pythagoras/Strategos/HA |

⸻

🎯 Ordinal PIE Priority (Highest First):

(P = Strategos assigned, I/E = Pythagoras evaluated)

⸻

Output Validation & Audit

- Each JTBD must have runtime proof: log, screenshot, or video, cross-referenced to command/time/device MAC.
- Checklist: submit JTBD ID → artifact mapping for audit.
- Missing feedback (bottom-up) evidence = INCOMPLETE.
- Responsible: Pythagoras (hardware/pydev)
- Accountable: Strategos
- Consulted: HA (integration/platform blockers)
- Informed: Stakeholders, testers

⸻

Escalation/Early Warning Protocol

- If any JTBD is blocked (hardware, environment, library, etc), escalate immediately after one failed retry.
- Artifact for a blocked task must still include last log and a 1-line root cause guess.
- Do not proceed to next JTBD without escalation for an unresolved blocker.

⸻

Instructions for Pythagoras

- Treat each JTBD as a self-contained deliverable, with proof required for both command and feedback.
- Use the existing codebase/structure, but test live with a physical BB-8 (no demo-only).
- Attach all artifacts (video, log, screenshot, etc.) and update mapping checklist.
- Document all environment/platform details at start of run.
- If any task is blocked, escalate immediately with artifact and root cause.
- Do not mark COMPLETE without all runtime evidence.

⸻

## DELIVERABLES

### JBTD-01

**Context:**

- BLE scan and connect to BB-8 (bb8_259ED00E30262568)
- Activate LED as proof of connection (UUID and command bytes logged)
- Artifact log and video placed in artifacts/ with naming convention
- Escalate immediately with artifact/log if any step is blocked

Steps to reproduce:

#### **Copilot Instructions – JTBD-01 Artifact Protocol Integration**

**Context:**
This repository is under strict empirical governance.
**Goal:** Systematically automate, log, and artifact the BLE connection and activation of BB-8 (MAC: `259ED00E30262568`) per JTBD-01, using audit-grade scripts and evidence.

<!-- JTBD-01 Instructions for Copilot begin here -->

#### **Instructions for Copilot**

**You are required to:**

##### 1. **Create and Save an Audit Script**

- **File:** Create a new script named `jtbd01_ble_connect.py` at project root or in `tests/` as appropriate.
- **Purpose:**
  - Scan for BB-8 via BLE (`bleak`), using MAC: `259ED00E30262568`
  - Connect to device, send LED activation command
  - Log every step (scan, connect, activate, error) with ISO timestamp, MAC, and BLE UUID/command bytes used

##### 2. **Artifact Logging**

- **Log File:**

  - Write all output to `artifacts/JTBD-01_log_<timestamp>_259ED00E30262568.txt`
  - Example: `artifacts/JTBD-01_log_20250620_259ED00E30262568.txt`
- **Log content must include:**

  - Timestamp for every line
  - BB-8 MAC in every log statement
  - Actual UUID and bytes sent for LED activation

##### 3. **BLE LED Activation Command**

- **UUID:** Use `00010002-574f-4f20-5370-6865726f2121` (or correct for this hardware—**note actual value used in log**)
- **Command Bytes:** Use test values (e.g., green: `[0x00, 0xFF, 0x00, 0xFF]`).

  - **If this does not activate the LED, note what bytes/UUID actually worked in log.**

##### 4. **Artifact Protocol**

- **After successful LED activation:**

  - Prompt human operator to capture a video of BB-8 lighting up
  - Place video in `artifacts/` as:

    - `JTBD-01_video_<timestamp>_259ED00E30262568.mp4`
- **If error/blocker:**

  - Ensure log captures error and suggest root cause (e.g., “Device not found: BLE off”, etc.)

##### 5. **Code Style**

- **Follow PEP8** (use autoformat if possible)
- **Add a header with script purpose, expected usage, and log/artifact paths**

##### 6. **Post-Execution**

- **No script or test is considered COMPLETE unless:**

  - Log is generated and placed in `artifacts/`
  - Video file is placed in `artifacts/`
  - Log includes actual UUID/command bytes and MAC

#### **Sample Log Output**

```plaintext
2025-06-20T13:21:05 | [JTBD-01][259ED00E30262568] BLE scan started
2025-06-20T13:21:15 | [JTBD-01][259ED00E30262568] BB-8 FOUND @ 259ED00E30262568
2025-06-20T13:21:18 | [JTBD-01][259ED00E30262568] Connected, activating LED (UUID=00010002-574f-4f20-5370-6865726f2121, BYTES=00ff00ff)
2025-06-20T13:21:18 | [JTBD-01][259ED00E30262568] LED command sent, check BB-8 for light
2025-06-20T13:21:30 | [JTBD-01][259ED00E30262568] SUCCESS. Prompt operator to capture video for audit.
```

#### **Code Skeleton**

(Expand/complete in codebase as needed)

```python
# jtbd01_ble_connect.py
# Purpose: Scan, connect, and activate LED on BB-8 for empirical audit. Log all steps.

# ... see main script provided above in this thread ...
```

#### **Strict Requirements**

- Do not mark JTBD-01 as complete unless **both**:

  - BLE connection + LED activation is logged
  - Video artifact is placed in artifacts/
- If script fails, log the last error and escalate as a blocker.

**Copilot: Begin work with this protocol.
If ambiguity or blocker, halt and escalate per artifact protocol.
Audit, closure, and velocity are mandatory.**

**End of Copilot Instructions.**

<!-- JTBD-01 Instructions for Copilot end here -->

##### What Copilot Delivered

- New File:
jtbd01_ble_connect.py (project root)
- Directory:
artifacts/ (created if missing)
- Script Features:
- BLE Scan/Connect: Uses bleak to find BB-8 with MAC: 259ED00E-3026-2568-C410-4590C9A9297C
- LED Activation: Sends test command to UUID 00010002-574f-4f20-5370-6865726f2121 with bytes 00ff00ff
- Audit Logging:
- Every event (scan, connect, command) logged in ISO timestamp format
- Log includes MAC, UUID, bytes sent
- Log file path: artifacts/JTBD-01_log_`timestamp`_`MAC`.txt
- Success: Prompts human operator to capture a video and place in artifacts/
- Error Handling:
- All errors logged
- Exits with nonzero status on failure (suitable for automation integration)
- PEP8 Compliance: Formatting, docstring header, and usage instructions are present

##### **Service Enumeration Complete – BB-8 Connected, GATT Profile Mapped**

### JTBD-02—PHASE 1: MQTT INTEGRATION TECHNICAL REVIEW

1. MQTT Entry Points and State (Scanned)

1.1. Core MQTT Source Files (active):

- src/ha_sphero_bb8/mqtt_handler.py
- src/ha_sphero_bb8/mqtt_dispatcher.py
- src/ha_sphero_bb8/run_mqtt.py

1.2. Legacy/Test/Experimental MQTT:

- legacy/test_integration_mqtt.py
- legacy/mqtt_send_test.py

1.3. Meta/Logs/Patches:

- meta/phase1_mqtt_and_vendor_alignment.yaml
- logs/patch_20250617_202726_mqtt_handlers.diff
- logs/patch_20250617_mqtt_handler_api.diff

2. Configuration Files (Scanned)

- requirements.txt, pyproject.toml (dependencies, could include paho-mqtt, hbmqtt, or similar)
- Multiple YAMLs in /meta/ likely define governance, manifest, and possibly Home Assistant/MQTT topics.

3. Test Stubs

- legacy/test_integration_mqtt.py (likely an integration test script)
- tests/test_features.py (general test coverage, check for MQTT-related tests)
- /meta/test_manifest.yaml (manifest of test cases)

⸻

#### PRELIMINARY GOVERNANCE ASSESSMENT

**Constraints**:

- All MQTT triggers must produce hardware-visible results, not simulation only.
- Audit log/artifact for each MQTT-triggered action.
- MAC stamping and timestamp on all logs.
- Use only the restored/approved src/ code path, not legacy if possible.

**Blockers/Key Decisions**:

- Confirm which MQTT handler/dispatcher is “live” for current MVP—run_mqtt.py in src/ is likely, but confirm config.
- Verify if topic names, broker URL, and BB-8 MAC/entity are current.
- Ensure requirements.txt includes the correct MQTT client lib, version-matched to code.
- Validate Home Assistant or test-publisher side (not just Python MQTT script).
- Ensure no legacy/experimental paths are active for MVP (use only auditable, reviewed code).

⸻

#### NEXT STEPS: RESTORATION PLAN DRAFT

1. Identify Scripts to Run

- System-level test should use:
- src/ha_sphero_bb8/run_mqtt.py (main MQTT listener/driver)
- (As needed: test publisher or Home Assistant service call)

2. Configs to Patch/Check

- In code/config:
- MQTT broker URL, port, user/pass, topic(s)
- BB-8 MAC/entity ID
- Home Assistant automation or test-publisher config for event injection
- Requirements: paho-mqtt or similar in requirements.txt
- Meta/manifest YAMLs:
- Topic naming, audit paths, governance criteria (for artifact closure)

3. Governance & Blockers

- Audit must capture inbound MQTT event, hardware action, and all exceptions.
- Any ambiguity in which script/config to use must be resolved before execution.
- No silent/“simulated only” command paths allowed.

⸻

#### ARTIFACT TEST (EMPIRICAL PLAN)

 1. Run src/ha_sphero_bb8/run_mqtt.py (after verifying broker, topic, BB-8 MAC, and that only one BB-8 is powered on/awake).
 2. Send test MQTT event (via mosquitto_pub or Home Assistant).
 3. Expected outcome:

- BB-8 performs the command (e.g., LED on, move, etc.)
- Script logs inbound MQTT event, device command, timestamp, MAC.
- Log written to artifacts/ with full context.
- Operator (if possible) captures video/photo for audit.

 4. If failure:

- Log all outputs and exceptions.
- Archive artifact and escalate with blocker/diagnosis.

⸻

#### ANALYSIS – ARTIFACT TABLE & SUMMARY

1. **Audit Mapping Table (Markdown, Example)**

JTBD ID Step Artifact Type Filename/Link Description
JTBD-02 MQTT-in Log JTBD-02_log__.txt MQTT event received, BB-8 reacts
JTBD-02 MQTT-in Video/Photo JTBD-02_video__.mp4 BB-8 response (hardware proof)

2. **Summary**

- MQTT integration code, config, and test stubs are present and auditable.
- System-level test flow and artifact requirements are clear and governed.
- Next: Confirm exact scripts/configs for execution, patch as needed, and conduct audit-grade test run.
- If needed, I will enumerate exact config values and function entrypoints by parsing `run_mqtt.py` and the two handlers.

#### EMPIRICAL—IN-DEPTH PARSE OF MQTT INTEGRATION MODULES

1. `run_mqtt.py` (Entrypoint) – Key Insights

- Purpose: Main CLI entry for running the Sphero BB-8 MQTT event loop.
- Responsibilities:
- CLI parsing: adapter selection (bleak or sim), broker details, verbosity, etc.
- Imports: mqtt_handler, mqtt_dispatcher, BleGateway, project constants.
- Orchestrates initialization of BB-8 device and MQTT handler.
- Sets up logging, signal handling for clean shutdown.
- Uses MQTT_CONTROL_TOPIC (from constants) for primary event flow.
- Launches a main loop: subscribes to topics, handles incoming MQTT events.

2. `mqtt_handler.py` (MQTT Handler) – Key Insights

- Purpose: Manages MQTT broker connection, subscribes to topics, dispatches inbound messages to command handlers (real and sim modes).
- Entrypoints:
- MQTTHandler class: central broker handler, manages connection, on_connect, on_message, etc.
- Robust try/except on handlers (for logging and stability).
- Config:
- MqttConfig dataclass: holds broker host, port, username, password, client ID, keepalive, discovery prefix, base topics.
- Defaults to localhost:1883, but accepts overrides.
- Topics:
- Uses constants for BASE_TOPIC, COMMAND_TOPIC, etc.
- Home Assistant auto-discovery and device info support.
- MQTT Library:
- Uses `paho.mqtt.client`.
- Controller Integration:
- Receives BB-8 controller instance (real or sim).
- Passes inbound MQTT messages to dispatcher with controller instance.

3. `mqtt_dispatcher.py` (Topic Routing) – Key Insights

- Purpose: Centralizes logic for mapping MQTT topics to controller commands.
- Key Function: dispatch_from_topic(topic, payload, controller)
- Supported Topics:
- bb8/command/move → controller.roll(speed, heading)
- bb8/command/stop → controller.stop()
- bb8/command/rotate → controller.rotate(angle)
- bb8/command/led → controller.set_led(r, g, b)
- bb8/command/diagnostics → controller.get_diagnostics_for_mqtt()
- bb8/command/test → controller.simulate()
- Else → Error
- Payload Handling:
- Each command expects a dict payload, with defaults if keys are missing.
- Return:
- Always returns a dict indicating topic, handled status, and result/error.

#### IMPACT ON RESTORATION/TEST PLAN

- Current Design is MODULAR, TESTABLE, and aligns with audit/protocol governance.
- All MQTT topics are well-defined, and hardware commands are strictly controlled via controller API.
- Testing can target run_mqtt.py (system test), or individual topics via dispatcher for unit/integration.
- No ambiguity about which code path to patch/run: Only src/ is needed.
- All configs are centrally defined via MqttConfig and constants.

⸻

#### RECOMMENDED PATCH/TEST ADJUSTMENTS

- Ensure broker/port/topic in MqttConfig matches your current Home Assistant or test environment.
- Verify BB-8 MAC/entity in controller init, especially if using multiple devices.
- For test artifacts:
- Target each command (move, stop, led, etc.) by sending a test MQTT message and observing BB-8 response + logging.
- All logs should appear in artifacts/ with MAC and timestamp as before.
- If issues arise, patch only in src/ha_sphero_bb8/mqtt_handler.py or src/ha_sphero_bb8/mqtt_dispatcher.py—not in legacy.

⸻

#### Summary

- No show-stopper design risks or broken code paths detected.
- Code is cleanly layered for patch, audit, and test. Proceed with confidence to config, execution, and artifacted validation.

⸻

#### EMPIRICAL—JTBD-02 RESTORATION & TEST EXECUTION PLAN

(for BB-8 MQTT→BLE system test, audit-grade)

##### JTBD-02: Restoration Plan, Config Patching, Artifact Test & Mapping

##### 1. Scripts to Run

- Primary Entrypoint:
- `src/ha_sphero_bb8/run_mqtt.py`
- CLI options allow adapter/broker override as needed.
- Test Event Injection:
- From any MQTT client (`mosquitto_pub`, Home Assistant, or a test Python publisher).

⸻

##### 2. Configs to Patch/Check

- In src/ha_sphero_bb8/mqtt_handler.py and constants.py (or via CLI/env):
- host / port (MQTT broker; defaults to `localhost:1883`)
- username / password (if broker is secured)
- client_id (default: `ha-sphero-bb8`)
- base_topic, e.g., `bb8/command/led`
- BB-8 MAC address in controller instantiation (if needed)
- In Home Assistant/test publisher:
- Topic: `bb8/command/led`, `bb8/command/move`, etc.
- Payload: JSON (`{"r":0, "g":255, "b":0}` for LED; `{"speed":50,"heading":90}` for move)

⸻

##### 3. Governance & Blocker Review

- Constraints:
- Every MQTT event must yield hardware action (no simulation-only closure).
- All actions are logged with MAC, topic, payload, timestamp.
- Operator should physically confirm action (artifact: video/photo).
- No legacy scripts or direct BLE bypass; use only src/.
- Blockers:
- If BB-8 does not respond, log all output and escalate with exact step/artifact.
- If config mismatch or broker error, patch and re-test.

⸻

##### 4. Artifacted Test Protocol

**A. Start MQTT Handler**

```cli
python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker <BROKER_HOST> --port <PORT>
```

(Add username/password if needed)

**B. Send Test MQTT Event**

- Using CLI:

```cli
mosquitto_pub -h <BROKER_HOST> -t "bb8/command/led" -m '{"r":0,"g":255,"b":0}'
```

- Or from Home Assistant MQTT service call:
- Service: `mqtt.publish`
- Topic: `bb8/command/led`
- Payload: `{"r":0,"g":255,"b":0}`

**C. Validate Results**

- BB-8 should visibly activate (LED change, move, etc.)
- Log entry created:
- Timestamp, MAC, topic, payload, result, error (if any)
- Capture a video/photo (optional but preferred)

**D. Artifact Collection**

- Log file (e.g., `JTBD-02_log_<ts>*<MAC>.txt`) appears in artifacts/
- Video/photo: `JTBD-02_video*<ts>_<MAC>.mp4` (if created)

⸻

##### 5. Artifact Mapping Table

JTBD ID Step Artifact Type Filename/Link Description
`JTBD-02` MQTT-in Log `JTBD-02_log__.txt` MQTT event, BB-8 reacts
`JTBD-02` MQTT-in Video/Photo `JTBD-02_video__.mp4` (Optional) Proof of action

⸻

##### 6. Empirical Closure & Summary

- Test “pass” when:
- MQTT event produces BB-8 hardware action (not simulation).
- Log/artifact present with correct MAC/topic.
- (Optional) Operator confirms with video/photo.
- If test fails:
- Archive all logs.
- Document blocker and escalate (e.g., connection, broker auth, action not triggered).

⸻

##### Next Action

- Patch configs as needed.
- Start `run_mqtt.py`.
- Inject a test MQTT command.
- Observe/log artifacts.
- If result is ambiguous, escalate with all logs and state.

⸻

##### ✅ Review & Approval

- Planning and technical parse are both solid.
- All current entrypoints, configs, and test harnesses are correct and audit-ready.
- Emphasis on disabling simulation-only flows and “legacy”/untested scripts is on target.
- Governance constraints and artifact protocol are fully met.
- Every MQTT event must be traceable from log → hardware → feedback artifact.
- MAC, topic, payload, and time must be evident in each log/artifact.

##### 🟦 Additional Notes / Precision

- Environment Variables:
  If your environment uses any MQTT credentials or non-default host/port, document them for the artifact log and test run.
- Test Publisher:
  Please prefer Home Assistant for the “realistic” event test, but CLI via mosquitto_pub is also accepted for rapid iteration.
  Note any deviations in your artifact summary.
- Feedback Confirmation:
  If BB-8 does not visibly react, double-check the logs for errors or dropped messages.
  If in doubt, re-test with an LED command (as this is the most visually obvious).
- Known Issues:
  If you hit any protocol mismatches (e.g., new MQTT topics not handled), patch only in the governed source (src/ha_sphero_bb8/).

###### 📑 Expectations for Artifact/Closure

- Submit log file (named as per artifact protocol).
- (Optional, strongly encouraged) Video/photo artifact for physical BB-8 action.
- Markdown and/or CSV mapping for this JTBD and all others—keep this up to date.
- If any step fails or is ambiguous, escalate immediately with all evidence.

---

### RECOMMENDED NEXT STEPS (EMPIRICAL, NO-REGRET PATH):

 1. Continue current “6-topic” approach for MVP only for the explicit purpose of closing audit/tech validation (JTBD-02, etc.).

 2. Explicitly document in your governance/artifact logs:
“This structure is a technical prototype. The production architecture will consolidate commands to a single topic (bb8/control or similar), with command demuxing at the handler level, for reasons of extensibility, data lineage, and integration UX.”

 3. For all future work:

- Move to a single-topic, command-in-payload structure:
- Topic: bb8/control
- Payload: {"command": "move", "speed": 100, ...}
- Dispatcher/handler maps commands from payload, not topic string.
- This also brings you in line with Home Assistant, REST, event-driven and data engineering best practices.

⸻

#### For MVP & JTBD-02

- Proceed with the current multi-topic structure to avoid breaking audit closure or rewriting tests/configs mid-stream.
- Patch helper text and test as per code (as discussed above).
- Log/annotate all artifacts with your architectural decision (why multi-topic is not long-term).

⸻

#### For the Team / Future Devs

- Add a README or governance note:
“WARNING: Multi-topic command approach is legacy/prototype. Production path is single topic with demuxed payload.”

---

## Strategic Response: Executive Re-Scoping to JTBD-02b (“LED Path”)

⸻

### Summary of Your Proposal
 • Pause further broad/multi-command validation for JTBD-02.
 • Spin out a focused JTBD-02b: “Empirical validation of end-to-end LED command, from MQTT to BB-8 hardware reaction.”
 • Rationale:
 • LED command gives immediate, visual, unambiguous evidence.
 • Fewer variables per test = easier root cause isolation and faster insight.
 • Knowledge gained will de-risk full protocol validation later.

⸻

### APPROVAL & NEXT STEPS (EMPIRICAL)

#### 1. Executive Approval

**APPROVED**
This approach is fully aligned with empirical best practice and engineering governance.
Focusing on a single command (“LED”) is the correct move to isolate the hardware/software boundary, break the “unknown unknowns” loop, and accelerate closure.

⸻

#### 2. JTBD-02b — LED Command Causal Chain

**Causal Chain: MQTT LED Command → BB-8 Lights Up**

Below is the full causal chain, broken into nodes/checkpoints, for empirical testing and troubleshooting:

**Step Node/Layer Testable Evidence Description**
1 `MQTT Publish (External) Home Assistant`, CLI, or MQTT Explorer shows “Publish” on topic `bb8/command/led` with payload (e.g., `{ "r": 0, "g": 255, "b": 0 }`) You send the LED command.
2 `MQTT Broker Receive` Broker log shows message accepted/forwarded on topic. Mosquitto logs “publish” on topic for BB-8 client.
3 MQTT Handler Subscription Your Python logs: MQTT message received on bb8/command/led with payload. Confirms your handler picked up the event.
4 Command Dispatch Log: Dispatching LED command to controller (or similar, in dispatcher/handler). Your code routes to BB8Controller.
5 Controller/Adapter Action Log: Calling set_led(r, g, b) with values; log “Device connected: True” (or similar). Code tries to call hardware interface.
6 Device API Call Log: “set_led result: …” — should log device return value. Confirms call reached Sphero SDK/device.
7 Hardware Response Visual: BB-8 lights change as per command. THIS IS THE EMPIRICAL CLOSURE POINT.
8 Audit Log/Artifact Artifact log contains all above events with timestamps, MAC, etc. Ensures closure is evidence-backed.

⸻

#### 3. Implementation Protocol
 • Test each link in the chain, in order. If you hit a break, STOP and debug that layer before proceeding.
 • Use targeted logging and artifacts to document each link.
 • At each step, confirm: “Does the output match expectation? Did it get through?” If not, escalate/log.

⸻

#### 4. Key Validation Commands
 • Run the handler:

```py
python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker 192.168.0.129 --port 1883 --username mqtt_bb8 --password mqtt_bb8
```

 • Emit LED command (from MQTT Explorer or CLI):
 • Topic: bb8/command/led
 • Payload: { "r": 0, "g": 255, "b": 0 }
 • Observe:
 • Python logs for each link.
 • BB-8 hardware for actual LED change.

⸻

#### 5. Escalation Protocol
 • If any node fails:
 • Collect: The log/artifact showing the last successful and first failed step.
 • Escalate: Post the failure node, logs, and summary of “what was expected, what happened”.

⸻

#### 6. Governance/Strategic Commentary
 • This scoping is empirically, operationally, and strategically correct.
 • All technical and audit-gov requirements are met.
 • No time/resource is “wasted”; this work will de-risk, accelerate, and improve all subsequent protocol work.

⸻

### NEXT ACTIONS

 1. Begin `JTBD-02b`: Run the end-to-end LED command path as above.
 2. Document the chain: Log/artifact every node.
 3. Escalate only on breakage, not before.
 4. **Once LED is proven, report empirical closure and recommend protocol re-scaling or next command to test.

⸻
