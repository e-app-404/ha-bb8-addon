# 📊 **High-Level Governance Project Tracker**

## 🏊 **Swimlanes/Groups Overview**

| Group (Swimlane) | Health Score | Traffic Light | Open JTBDs | Comments/Status Summary |
|------------------|--------------|---------------|------------|-------------------------|
| **Type Safety** | 2 | 🟥 | 3 | Multiple type annotation, var-annotated, and Optional errors |
| **Test Coverage** | 1 | 🟥 | 2 | Feature/integration tests missing, error tests only |
| **Imports & Stubs** | 2 | 🟨 | 2 | Vendor and 3rd-party stubs/imports unresolved |
| **Structure & Hygiene** | 4 | 🟩 | 1 | Hygiene/flattening complete, only docstring/README updates |
| **Documentation** | 3 | 🟨 | 2 | README, patchlog, docstring coverage needs expansion |
| **Circular Imports** | 1 | 🟥 | 1 | Test harness blocked, v1 acceptance blocked |

### 📏 **Scoring Scale:**

- **1** = major blocker
- **3** = moderate risk
- **5** = healthy/low risk

---

## 📋 **JTBD Action Manifest Table**

| Action ID | Description | Group | Assigned To | P | I | E | PIE | Output Validation | Acceptance Criteria | RACI (R/A/C/I) |
|-----------|-------------|--------|-------------|---|---|---|-----|------------------|---------------------|-----------------|
| `import_stub_fix` | Resolve vendor/3rd-party stubs, imports (spherov2, paho.mqtt) | Imports & Stubs | Pythagoras | 4 | 5 | 3 | **4.1** | mypy has no [import-not-found/untyped] errors | All imports resolve, or doc reason if not possible | Pythagoras/Strategos/Copilot/Dev |
| `add_type_annotations` | Add type annotations for all flagged variables | Type Safety | Copilot | 3 | 5 | 4 | **4.1** | mypy has no [var-annotated] errors | No [var-annotated] errors; code runs | Copilot/Strategos/Pythagoras/Dev |
| `optional_type_hints` | Update all None default args with Optional[…] | Type Safety | Copilot | 2 | 4 | 4 | **3.6** | mypy shows no None default assignment/signature errors | No mypy errors for default None args | Copilot/Strategos/Pythagoras/Dev |
| `object_typing_narrow` | Narrow object typing for any attribute/index errors | Type Safety | Copilot | 3 | 4 | 3 | **3.5** | mypy shows no attr/index on object type | All object-typed vars are fixed, no access errors | Copilot/Strategos/Pythagoras/Dev |
| `restore_feature_tests` | Restore/rewrite 1 test per feature (move, stop, etc.) | Test Coverage | Pythagoras | 5 | 5 | 2 | **4.0** | pytest collects/runs/passes key tests, logs produced | At least one test per feature, all pass | Pythagoras/Strategos/Dev |
| `circular_import_fix` | Refactor to eliminate circular import in test harness | Circular Imports | Pythagoras | 5 | 5 | 2 | **4.0** | pytest runs w/ no ImportError/circular import error | No circular import errors in test run | Pythagoras/Strategos/Dev |
| `docstring_coverage` | Add/expand docstrings for all flagged modules/classes/functions | Documentation | Copilot | 2 | 3 | 5 | **3.4** | pylint score rises, C0114/5/6 errors disappear | All flagged docstrings added, pylint logs proof | Copilot/Strategos/Dev |
| `stub_type_install` | Install missing stubs for 3rd-party packages | Imports & Stubs | Copilot | 2 | 3 | 5 | **3.4** | pip freeze or requirements.txt, mypy logs clean | All required stubs present, no import-not-found | Copilot/Strategos/Dev |
| `readme_patchlog_update` | Update README/patchlog for latest hygiene/test/structure change | Documentation | Copilot | 1 | 2 | 5 | **2.3** | README/patchlog updated, checked in, notes visible | Docs reflect new reality, commit/check | Copilot/Strategos/Dev |

---

## 🎯 **Ordinal PIE Priority (Highest First):**

1. **`import_stub_fix`** (4.1)
2. **`add_type_annotations`** (4.1)
3. **`restore_feature_tests`** (4.0)
4. **`circular_import_fix`** (4.0)
5. **`optional_type_hints`** (3.6)
6. **`object_typing_narrow`** (3.5)
7. **`docstring_coverage`** (3.4)
8. **`stub_type_install`** (3.4)
9. **`readme_patchlog_update`** (2.3)

---

## 📖 **Legend:**

### **Assigned To:**

- **Pythagoras**: code/architecture/logic refactor
- **Copilot**: hygiene, doc, mechanical edit

### **RACI Model:**

- **R** = Responsible (does the work)
- **A** = Accountable (approves work)
- **C** = Consulted (provides input/expertise)
- **I** = Informed (kept in loop, no action)

---

## 🚀 **Next Steps**

- Use this as your master sprint/validation tracker.
- Assign jobs directly to Pythagoras or Copilot as indicated.
- For each closed item, return evidence/output here for final Strategos audit.
- Swimlane tracker gives you a "single pane of glass" for project health and gating issues.

```yaml
confidence_metrics:
  structural: {score: 95, rationale: "Clean table formatting with proper markdown structure preserved all original data integrity."}
  operational: {score: 92, rationale: "Swimlane tracking and PIE prioritization maintain functional workflow visibility."}
  semantic: {score: 96, rationale: "All technical content, scores, and action items preserved exactly as specified."}
  adoption_recommendation: true
```

## Mini-prompts

Scaffolded mini-prompts for each JTBD/action, assigned to Copilot or Pythagoras as per the manifest, in a copy-pasteable format for reliable autonomous handoff.

### **Instructions for Use**

 • Copy/paste the relevant mini-prompt into Copilot or assign to Pythagoras as noted.
 • When each JTBD is complete, return here with evidence/output.
 • Strategos will validate and update swimlane/project health accordingly.

### Mini-prompts for Manifested JTBD

1. **JTBD: import_stub_fix**
Raci: Pythagoras

Resolve all missing import/module/library stub issues for vendor and 3rd-party dependencies, specifically including but not limited to spherov2, paho.mqtt, and any flagged in mypy [import-not-found] or [import-untyped] errors.

## Steps

1. Ensure vendor and 3rd-party packages are accessible in PYTHONPATH and have proper `__init__.py`.
2. For 3rd-party libraries, install type stubs (e.g., `pip install types-paho-mqtt`).
3. For vendored code, resolve directory and import paths, add docstring markers if fully fixing is not possible.
4. Rerun `mypy ./src/ha_sphero_bb8` to confirm no [import-not-found] or [import-untyped] errors.

## Output Validation

- Paste or attach mypy output showing no import errors.

## Acceptance Criteria

- All imports in src/ and vendor/ resolve cleanly in mypy and at runtime, or have an in-file docstring stating the rationale if not possible.

⸻

2. JTBD: add_type_annotations

Assigned to: Copilot

Add type annotations for all variables flagged by mypy with [var-annotated], including but not limited to **all**, command_history, scan_history, etc.

## Steps

1. For every mypy [var-annotated] error, add the required type annotation as suggested.
2. Verify that the code remains runnable and unchanged in logic.

## Output Validation

- mypy ./src/ha_sphero_bb8 output shows zero [var-annotated] errors.

## Acceptance Criteria

- All variables flagged by mypy for missing type annotations are annotated and code runs.

⸻

3. optional_type_hints — Assigned to: Copilot

# JTBD: optional_type_hints

Update all function signatures and default assignments where None is a valid value, using Optional[...] type hints as appropriate.

## Steps

1. Review mypy errors for incompatible default arguments with None.
2. Add typing.Optional to all affected arguments and update imports as needed.

## Output Validation

- mypy ./src/ha_sphero_bb8 output shows no errors about incompatible None defaults.

## Acceptance Criteria

- All functions accepting None as a default value use Optional[...] and mypy is satisfied.

⸻

4. object_typing_narrow — Assigned to: Copilot

# JTBD: object_typing_narrow

Narrow variable and argument types currently set as 'object' but used as dict, list, or with attribute/index access, as flagged by mypy.

## Steps

1. For every 'object' type flagged by mypy for attribute/index access, assign a more precise type (e.g., dict, list, custom class).
2. Validate with mypy after each change.

## Output Validation

- mypy ./src/ha_sphero_bb8 output shows no attribute/index errors on 'object' type.

## Acceptance Criteria

- All attribute/index errors on object types are resolved and type assignments are precise.

⸻

5. restore_feature_tests — Assigned to: Pythagoras

# JTBD: restore_feature_tests

Restore or rewrite at least one functional integration test for each major feature (move, stop, rotate, led, diagnostics, etc).

## Steps

1. For each feature, ensure there is at least one test file or test case validating expected behavior.
2. Tests must run via pytest, not rely on legacy mocks, and provide clear pass/fail output.

## Output Validation

- pytest run collects and executes at least one test per major feature; log or screenshot of all passing.

## Acceptance Criteria

- Each feature (move, stop, rotate, led, diagnostics, etc.) has at least one passing test.

⸻

6. circular_import_fix — Assigned to: Pythagoras

# JTBD: circular_import_fix

Refactor project structure or base class location to eliminate the circular import blocking test harness (e.g., BB8Like/interface split).

## Steps

1. Identify and break circular import chain by relocating interfaces or restructuring imports.
2. Document changes in patchlog or comments.

## Output Validation

- pytest runs with no ImportError or circular import errors.

## Acceptance Criteria

- No circular import errors in pytest/test run; interfaces are split and documented.

⸻

7. docstring_coverage — Assigned to: Copilot

# JTBD: docstring_coverage

Add or expand docstrings for all flagged modules, classes, and functions as per pylint/mypy C0114/C0115/C0116 warnings.

## Steps

1. Add at least a minimal docstring for each flagged item.
2. Confirm that pylint C0114, C0115, C0116 errors are gone.

## Output Validation

- pylint ./src/ha_sphero_bb8 output with no C0114/5/6 errors.

## Acceptance Criteria

- All flagged items have docstrings, as validated by pylint logs.

⸻

8. stub_type_install — Assigned to: Copilot

# JTBD: stub_type_install

Install missing type stubs for all 3rd-party packages needed by mypy, e.g., types-paho-mqtt.

## Steps

1. Identify missing stubs from mypy output.
2. Install them with pip (e.g., pip install types-paho-mqtt).
3. Update requirements.txt as needed.

## Output Validation

- pip freeze or requirements.txt includes installed types.
- mypy output is clean for third-party stub errors.

## Acceptance Criteria

- All required type stubs are present and mypy shows no related errors.

⸻

9. readme_patchlog_update — Assigned to: Copilot

# JTBD: readme_patchlog_update

Update README.md and patchlog to document all recent hygiene, test, and structure changes.

## Steps

1. Summarize key hygiene and structure changes.
2. Document in both README.md and patchlog.
3. Check in and verify files.

## Output Validation

- README.md and patchlog are up-to-date and visible in repo.

## Acceptance Criteria

- Documentation accurately reflects new structure; files are committed.

⸻
