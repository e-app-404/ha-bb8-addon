# build.py

import sys
def log_or_exit(msg, code=1):
    sys.stderr.write(msg + '\n')
    sys.exit(code)
try:
    import setuptools
    from setuptools import setup
except ImportError:
    sys.stderr.write('setuptools not found. Please install setuptools before running build.py\n')
    sys.exit(1)

import os

APP = ['src/ha_sphero_bb8/launch_bb8.py']
DATA_FILES = []
OPTIONS = {
    'argv_emulation': True,
    'packages': ['ha_sphero_bb8'],
    'plist': {
        'CFBundleName': 'BB8 Control',
        'CFBundleDisplayName': 'BB8 Control',
        'CFBundleIdentifier': 'com.hestia.bb8control',
        'CFBundleVersion': '0.2.1-dev1',
        'NSBluetoothAlwaysUsageDescription': 'This app requires Bluetooth access to control BB-8.',
    },
    'iconfile': 'assets/bb8.icns',  # Optional, can be replaced
}

setup(
    app=APP,
    data_files=DATA_FILES,
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
)
