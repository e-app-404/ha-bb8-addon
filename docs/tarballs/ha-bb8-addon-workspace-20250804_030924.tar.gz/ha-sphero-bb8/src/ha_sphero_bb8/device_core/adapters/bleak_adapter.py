from typing import Optional, Any
import logging
import asyncio
try:
    from bleak import BleakScanner, BleakClient
    from bleak.exc import BleakError
except ImportError:
    BleakScanner = None
    BleakClient = None
    BleakError = Exception

class BleakAdapter:
    def __init__(self):
        self.client: Optional[Any] = None
        self.device_address: Optional[str] = None
        self.device: Optional[Any] = None  # Ensure device attribute exists
        self.logger = logging.getLogger(__name__)
        self._auto_reconnect_task: Optional[asyncio.Task] = None
        self._auto_reconnect_running = False

    async def scan(self, name_filter: str = "BB-8", timeout: float = 5.0):
        """Scan for BLE devices matching name_filter."""
        if BleakScanner is None:
            self.logger.error("[BLE] BleakScanner not available.")
            return []
        self.logger.info(f"[BLE] Scanning for devices (filter: {name_filter})")
        devices = await BleakScanner.discover(timeout=timeout)
        found = [d for d in devices if d.name and name_filter in d.name]
        for d in found:
            self.logger.info(f"[BLE] Found device: {d.name} ({d.address})")
        return found

    async def connect(self, address: str, timeout: float = 10.0, max_retries: int = 3):
        self.logger.debug(f"[BLE][DEBUG] connect() called with address={address}, timeout={timeout}, max_retries={max_retries}")
        if BleakClient is None:
            self.logger.error("[BLE] BleakClient not available.")
            return False
        self.device_address = address
        attempt = 0
        while attempt < max_retries:
            try:
                self.logger.info(f"[BLE] Attempting to connect to {address} (attempt {attempt+1})")
                self.logger.debug(f"[BLE][DEBUG] Creating BleakClient for address={address}")
                self.client = BleakClient(address)
                self.logger.debug(f"[BLE][DEBUG] Awaiting client.connect() with timeout={timeout}")
                await asyncio.wait_for(self.client.connect(), timeout=timeout)
                if await self.client.is_connected():
                    self.logger.info(f"[BLE] Connected to {address}")
                    self.logger.debug(f"[BLE][DEBUG] connect() success for address={address}")
                    # Start auto-reconnect after successful connect
                    self.start_auto_reconnect()
                    return True
            except (BleakError, asyncio.TimeoutError) as e:
                self.logger.error(f"[BLE] Connection attempt {attempt+1} failed: {e}")
                self.logger.debug(f"[BLE][DEBUG] connect() exception: {e}")
                attempt += 1
                await asyncio.sleep(2 * attempt)  # Exponential backoff
        self.logger.error(f"[BLE] Failed to connect to {address} after {max_retries} attempts")
        self.logger.debug(f"[BLE][DEBUG] connect() failed for address={address}")
        self.client = None
        return False

    async def disconnect(self):
        self.logger.debug(f"[BLE][DEBUG] disconnect() called for address={self.device_address}")
        if self.client:
            try:
                self.logger.debug(f"[BLE][DEBUG] Awaiting client.disconnect() for address={self.device_address}")
                await self.client.disconnect()
                self.logger.info(f"[BLE] Disconnected from {self.device_address}")
            except Exception as e:
                self.logger.error(f"[BLE] Error during disconnect: {e}")
                self.logger.debug(f"[BLE][DEBUG] disconnect() exception: {e}")
            finally:
                self.client = None
        # Stop auto-reconnect on disconnect
        self.stop_auto_reconnect()

    async def is_connected(self):
        self.logger.debug(f"[BLE][DEBUG] is_connected() called for address={self.device_address}")
        result = self.client is not None and await self.client.is_connected()
        self.logger.debug(f"[BLE][DEBUG] is_connected() result: {result}")
        return result

    # Example usage for sync context:
    def connect_sync(self, address, timeout=10.0, max_retries=3):
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.connect(address, timeout, max_retries))

    def disconnect_sync(self):
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.disconnect())

    def is_connected_sync(self):
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.is_connected())

    def roll(self, heading, speed): pass
    def set_main_led(self, r, g, b):
        """
        Set the main LED color on BB-8 using BLE.
        Ensures self.client is a valid BleakClient before attempting write.
        Uses type: ignore[union-attr] on write_gatt_char (safe due to instance check).
        """
        import logging
        logger = logging.getLogger(__name__)
        LED_CHAR_UUID = "22bb746f-2bb0-7554-2d6f-726568705327"
        try:
            logger.info(f"BleakAdapter.set_main_led called with r={r}, g={g}, b={b}")
            logger.debug(f"[BLE][DEBUG] set_main_led() called with r={r}, g={g}, b={b}")
            if BleakClient is None or self.client is None or not isinstance(self.client, BleakClient):
                logger.error("BleakAdapter: No valid BleakClient available for LED write.")
                logger.debug("[BLE][DEBUG] set_main_led() abort: no valid client")
                return False
            packet = bytearray([r, g, b])
            logger.debug(f"[BLE][DEBUG] set_main_led() sending packet: {packet} to {LED_CHAR_UUID}")
            import asyncio
            async def write_led():
                logger.debug(f"[BLE][DEBUG] write_led() about to write_gatt_char {LED_CHAR_UUID}")
                await self.client.write_gatt_char(LED_CHAR_UUID, packet)  # type: ignore[union-attr]
                logger.debug(f"[BLE][DEBUG] write_led() write_gatt_char complete")
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(write_led())
            except Exception as e:
                logger.error(f"BleakAdapter: Failed to write LED char: {e}")
                logger.debug(f"[BLE][DEBUG] set_main_led() exception: {e}")
                return False
            logger.info(f"Sent LED packet to BB-8: {packet}")
            logger.debug(f"[BLE][DEBUG] set_main_led() success")
            return True
        except Exception as e:
            logger.error(f"Failed to set BB-8 LED: {e}")
            logger.debug(f"[BLE][DEBUG] set_main_led() outer exception: {e}")
            return False

    def discover_services_and_characteristics(self):
        """
        Discover and log all BLE services and characteristics for the connected BB-8 device.
        Returns a dict of {service_uuid: [characteristic_uuids]}.
        """
        import logging
        logger = logging.getLogger(__name__)
        if BleakClient is None or self.client is None or not isinstance(self.client, BleakClient):
            logger.error("[DISCOVERY] No valid BleakClient for service discovery.")
            return None
        import asyncio
        async def discover():
            # Connect if not already connected
            if not getattr(self.client, 'is_connected', False):
                await self.client.connect()  # type: ignore[union-attr]  # Dynamic BLE client, safe by runtime check
            logger.info(f"[DISCOVERY] Connected: {getattr(self.client, 'is_connected', False)}")
            services = getattr(self.client, 'services', [])  # type: ignore[union-attr]  # Dynamic BLE client, safe by runtime check
            for service in services:
                logger.info(f"Service: {service.uuid}")
                for char in service.characteristics:
                    logger.info(f"  Characteristic: {char.uuid}, props: {char.properties}")
            return {service.uuid: [char.uuid for char in service.characteristics] for service in services}
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(discover())
        except Exception as e:
            logger.error(f"[DISCOVERY] Failed to discover services: {e}")
            return None

    def set_led(self, r: int, g: int, b: int) -> bool:
        """
        Sends a BLE packet to set BB-8's main LED color.
        Tries high-level SDK, then raw BLE fallback if needed.
        Returns True on success, False on failure.
        """
        import logging
        logger = logging.getLogger(__name__)
        logger.debug(f"[BLE][DEBUG] set_led() called with r={r}, g={g}, b={b}")
        # Try high-level SDK first
        if hasattr(self.device, 'set_main_led') and callable(getattr(self.device, 'set_main_led', None)):
            try:
                logger.info(f"[PATCH] set_led: using device.set_main_led({r}, {g}, {b})")
                logger.debug(f"[BLE][DEBUG] set_led() using device.set_main_led")
                self.device.set_main_led(r, g, b)  # type: ignore[attr-defined]
                logger.debug(f"[BLE][DEBUG] set_led() device.set_main_led success")
                return True
            except Exception as e:
                logger.warning(f"[PATCH] set_led: device.set_main_led failed: {e}")
                logger.debug(f"[BLE][DEBUG] set_led() device.set_main_led exception: {e}")
        # Raw BLE fallback
        LED_CHAR_UUID = "22bb746f-2ba6-7554-2d6f-726568705327"
        def make_led_packet(r, g, b):
            return bytes([0x8d, 0x0a, 0x01, r, g, b, 0x00])
        packet = make_led_packet(r, g, b)
        logger.info(f"[PATCH] set_led: fallback, sending raw BLE packet {packet} to {LED_CHAR_UUID}")
        logger.debug(f"[BLE][DEBUG] set_led() fallback sending packet: {packet} to {LED_CHAR_UUID}")
        if BleakClient is None or self.client is None or not isinstance(self.client, BleakClient):
            logger.error("[PATCH] set_led: No valid BleakClient for raw BLE write.")
            logger.debug("[BLE][DEBUG] set_led() fallback abort: no valid client")
            return False
        import asyncio
        async def write_led():
            logger.debug(f"[BLE][DEBUG] set_led() fallback about to write_gatt_char {LED_CHAR_UUID}")
            await self.client.write_gatt_char(LED_CHAR_UUID, packet)  # type: ignore[union-attr]
            logger.debug(f"[BLE][DEBUG] set_led() fallback write_gatt_char complete")
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(write_led())
            logger.info(f"[PATCH] set_led: Sent raw BLE LED packet to BB-8: {packet}")
            logger.debug(f"[BLE][DEBUG] set_led() fallback success")
            return True
        except Exception as e:
            logger.error(f"[PATCH] set_led: Failed to write raw BLE LED char: {e}")
            logger.debug(f"[BLE][DEBUG] set_led() fallback exception: {e}")
            return False
    def stop(self): pass
    def get_battery_voltage(self):
        """
        Retrieve the battery voltage from the connected BB-8 device using the vendor library.
        Returns None if not connected or on error.
        """
        import logging
        logger = logging.getLogger(__name__)
        try:
            from spherov2.commands.power import Power
        except ImportError:
            logger.error("spherov2.commands.power not available.")
            return None
        if self.device is None:
            logger.error("BleakAdapter: No connected BB-8 device for battery voltage.")
            return None
        try:
            voltage = Power.get_battery_voltage(self.device)
            logger.info(f"BB-8 battery voltage: {voltage}V")
            return voltage
        except Exception as e:
            logger.error(f"Failed to get BB-8 battery voltage: {e}")
            return None

    def get_battery_percentage(self):
        """
        Retrieve the battery percentage from the connected BB-8 device using the vendor library.
        Returns None if not connected or on error.
        """
        import logging
        logger = logging.getLogger(__name__)
        try:
            from spherov2.commands.power import Power
        except ImportError:
            logger.error("spherov2.commands.power not available.")
            return None
        if self.device is None:
            logger.error("BleakAdapter: No connected BB-8 device for battery percentage.")
            return None
        try:
            percentage = Power.get_battery_percentage(self.device)
            logger.info(f"BB-8 battery percentage: {percentage}%")
            return percentage
        except Exception as e:
            logger.error(f"Failed to get BB-8 battery percentage: {e}")
            return None
    def wake(self): pass  # Added for type safety

    async def _auto_reconnect_loop(self, interval: float = 5.0):
        """Background task: auto-reconnect if BLE connection drops."""
        self.logger.info("[BLE] Auto-reconnect loop started.")
        while self._auto_reconnect_running:
            try:
                if self.device_address and (not await self.is_connected()):
                    self.logger.warning(f"[BLE] Connection lost. Attempting auto-reconnect to {self.device_address}...")
                    await self.connect(self.device_address)
            except Exception as e:
                self.logger.error(f"[BLE] Auto-reconnect error: {e}")
            await asyncio.sleep(interval)
        self.logger.info("[BLE] Auto-reconnect loop stopped.")

    def start_auto_reconnect(self, interval: float = 5.0):
        """Start background auto-reconnect task."""
        if self._auto_reconnect_task and not self._auto_reconnect_task.done():
            self.logger.info("[BLE] Auto-reconnect already running.")
            return
        self._auto_reconnect_running = True
        loop = asyncio.get_event_loop()
        self._auto_reconnect_task = loop.create_task(self._auto_reconnect_loop(interval))
        self.logger.info("[BLE] Auto-reconnect task started.")

    def stop_auto_reconnect(self):
        """Stop background auto-reconnect task."""
        self._auto_reconnect_running = False
        if self._auto_reconnect_task:
            # Task will exit on next loop
            self.logger.info("[BLE] Auto-reconnect task signaled to stop.")
