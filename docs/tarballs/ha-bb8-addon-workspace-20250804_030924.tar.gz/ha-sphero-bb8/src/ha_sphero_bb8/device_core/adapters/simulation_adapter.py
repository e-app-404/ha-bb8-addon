"""
Simulation adapter is deprecated and no longer supported.
This file is retained as a stub for compatibility only.
All simulation, mock, and fallback logic has been removed from the project as of August 2025.
"""

# src/ha_sphero_bb8/device_core/adapters/simulation_adapter.py

import logging

logger = logging.getLogger(__name__)

class SimulationAdapter:
    def __init__(self, *args, **kwargs):
        logger.error("SimulationAdapter is deprecated. Simulation is no longer supported.")
        raise NotImplementedError("SimulationAdapter is deprecated. Simulation is no longer supported.")

# No simulation, mock, or fallback logic remains in this file.
