"""
Safe utility wrappers for BB8Like protocol methods.
Handles vendor quirks and missing/optional arguments.
"""
from typing import Any

def safe_ping(device: Any) -> bool:
    try:
        return device.ping()
    except Exception:
        return False

def safe_set_main_led(device: Any, r: int, g: int, b: int) -> bool:
    try:
        device.set_main_led(r, g, b)
        return True
    except Exception:
        return False

def safe_get_voltage(device: Any) -> float:
    return getattr(device, "get_battery_voltage", lambda: 0.0)()

def safe_get_percentage(device: Any) -> int:
    return getattr(device, "get_battery_percentage", lambda: -1)()
