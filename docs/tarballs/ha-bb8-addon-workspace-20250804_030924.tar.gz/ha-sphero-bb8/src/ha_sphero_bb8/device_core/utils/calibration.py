"""
Calibration utilities for BB-8 orientation and heading (not production).
"""

# calibration.py
# DEFERRED: This module is non-production and not used in the current release.
# Retained for future development. Do not use in production code.
# See simulation_purge_plan.json for details.

def start_calibration():
    """Start BB-8 orientation calibration."""
    raise NotImplementedError

def stop_calibration():
    """Stop calibration and fix heading."""
    raise NotImplementedError

__all__: list[str] = []
