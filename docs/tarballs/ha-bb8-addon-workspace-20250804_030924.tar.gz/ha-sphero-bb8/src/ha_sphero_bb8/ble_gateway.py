# ble_gateway.py — HESTIA α-tier compliant with BLE hardware diagnostics

"""
MODULE PURPOSE: BLE gateway abstraction for Sphero BB-8. Handles device discovery, connection, and diagnostics for real hardware only.
STATUS: production
MAIN ENTRYPOINTS: BleGateway class, scan_for_device, connect, diagnostics
DEPENDENCIES: Uses vendor.spherov2, controller.py, device_core
LAST VALIDATED: 2025-08-02
NOTES:
- Only real BLE hardware is supported. Simulation, adapters, and fallback logic have been removed.
- All BLE errors are logged and surfaced for diagnostics.
"""

# Do not import run_mqtt.py (entrypoint script) in library code to avoid circular imports.

import os
import platform
import logging
import time
import traceback
from typing import Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum
import subprocess
import datetime
try:
    import psutil
except ImportError:
    psutil = None

from typing import List

# Graceful import handling for BLE dependencies
try:
    from spherov2.scanner import find_BB8  # type: ignore  # Patched: uses local _vendor/spherov2, not pip
    from spherov2.toy.bb8 import BB8  # type: ignore  # Patched: uses local _vendor/spherov2, not pip
    SPHEROV2_AVAILABLE = True
except ImportError as e:
    SPHEROV2_AVAILABLE = False
    BB8 = None
    find_BB8 = None  # Ensure find_BB8 is always defined
    logging.getLogger(__name__).warning(f"spherov2 not available: {e}")

# Pylance validation: always define BB8Toy for type hints
try:
    from spherov2.toy.bb8 import BB8 as BB8Toy  # type: ignore  # Patched: uses local _vendor/spherov2, not pip
except ImportError:
    BB8Toy = None  # fallback for type hints

try:
    import bleak
    BLEAK_AVAILABLE = True
except ImportError as e:
    BLEAK_AVAILABLE = False
    logging.getLogger(__name__).warning(f"bleak not available: {e}")

from ha_sphero_bb8.device_core.adapters.bleak_adapter import BleakAdapter

logger = logging.getLogger(__name__)

class BLEStatus(Enum):
    """BLE connection status enumeration"""
    UNKNOWN = "unknown"
    DISABLED = "disabled"
    SCANNING = "scanning"
    CONNECTED = "connected"
    FAILED = "failed"
    TIMEOUT = "timeout"
    PERMISSION_DENIED = "permission_denied"

@dataclass
class BLEScanResult:
    """BLE scan operation result with comprehensive diagnostics"""
    status: BLEStatus
    devices_found: int = 0
    scan_duration_ms: float = 0.0
    error_message: Optional[str] = None
    trace_id: Optional[str] = None
    adapter_type: str = "unknown"
    platform_info: str = platform.platform()

Adapter = BleakAdapter
adapter = Adapter()

logger.info(f"BLE Gateway initialized with adapter: Bleak")

def scan_devices() -> BLEScanResult:
    """Perform a BLE scan and return a diagnostic result object"""
    start = time.perf_counter()
    trace_id = f"scan-{int(start * 1000)}"
    try:
        devices = adapter.scan()
        return BLEScanResult(
            status=BLEStatus.SCANNING,
            devices_found=len(devices),
            scan_duration_ms=(time.perf_counter() - start) * 1000,
            trace_id=trace_id,
            adapter_type='bleak'
        )
    except Exception as e:
        logger.error(f"[BLE] Scan failed: {e}\n{traceback.format_exc()}")
        return BLEScanResult(
            status=BLEStatus.FAILED,
            error_message=str(e),
            trace_id=trace_id,
            scan_duration_ms=(time.perf_counter() - start) * 1000,
            adapter_type='bleak'
        )

def connect_device(identifier: str) -> bool:
    """Connect to a BLE device by identifier"""
    try:
        return adapter.connect(identifier)
    except Exception as e:
        logger.error(f"[BLE] Connection failed: {e}")
        return False

def disconnect_device():
    """Disconnect the active BLE session if connected"""
    try:
        return adapter.disconnect()
    except Exception as e:
        logger.warning(f"[BLE] Disconnection failed: {e}")
        return False

def is_connected() -> bool:
    """Return whether BLE is currently connected"""
    try:
        return adapter.is_connected()
    except Exception as e:
        logger.debug(f"[BLE] is_connected check failed: {e}")
        return False

def get_ble_status() -> Dict[str, Any]:
    """Expose current BLE status for diagnostics and MQTT reporting"""
    return {
        "connected": is_connected(),
        "platform": platform.system(),
        "spherov2": SPHEROV2_AVAILABLE,
        "bleak": BLEAK_AVAILABLE
    }

def emit_ble_diagnostics():
    """
    Emit platform-specific BLE diagnostics to the log (console and artifact log).
    """
    import platform, logging, traceback
    logger = logging.getLogger(__name__)
    logger.info("[BLE_DIAG] Emitting BLE diagnostics:")
    logger.info(f"[BLE_DIAG] Platform: {platform.platform()}")
    try:
        if platform.system() == "Darwin":
            result = subprocess.run(["system_profiler", "SPBluetoothDataType"], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] system_profiler output:\n{result.stdout}")
        elif platform.system() == "Linux":
            result = subprocess.run(["bluetoothctl", "show"], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] bluetoothctl show:\n{result.stdout}")
    except Exception:
        logger.warning(f"[BLE_DIAG] Error running BLE system check: {traceback.format_exc()}")

def emit_ble_core_diagnostics():
    """
    Emit robust BLE diagnostics: adapter info, permissions, user context, session locks, and actionable next steps.
    """
    import platform, subprocess, os, logging, traceback
    logger = logging.getLogger(__name__)
    logger.info("[BLE_DIAG] ===== BLE CORE DIAGNOSTICS START =====")
    logger.info(f"[BLE_DIAG] Platform: {platform.platform()}")
    # 1. Adapter Introspection
    try:
        if platform.system() == "Darwin":
            result = subprocess.run(["system_profiler", "SPBluetoothDataType"], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] system_profiler output:\n{result.stdout}")
        elif platform.system() == "Linux":
            result = subprocess.run(["hciconfig"], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] hciconfig output:\n{result.stdout}")
            result2 = subprocess.run(["bluetoothctl", "devices"], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] bluetoothctl devices:\n{result2.stdout}")
    except Exception:
        logger.warning(f"[BLE_DIAG] Error running BLE adapter introspection: {traceback.format_exc()}")
    # 2. Permissions/User Context
    try:
        logger.info(f"[BLE_DIAG] User: {os.getlogin()} (euid={os.geteuid()}, egid={os.getegid()})")
        if platform.system() == "Darwin":
            result = subprocess.run(["ls", "-l"] + [f"/dev/{x}" for x in os.listdir("/dev") if x.startswith("tty.") or x.startswith("cu.")], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] /dev/tty.* and /dev/cu.* permissions:\n{result.stdout}")
        elif platform.system() == "Linux":
            result = subprocess.run(["ls", "-l", "/dev/bluetooth*"], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] /dev/bluetooth* permissions:\n{result.stdout}")
            result2 = subprocess.run(["groups"], capture_output=True, text=True)
            logger.info(f"[BLE_DIAG] User groups: {result2.stdout}")
    except Exception:
        logger.warning(f"[BLE_DIAG] Error running permissions/user context diagnostics: {traceback.format_exc()}")
    # 3. Connection/Session Detection
    try:
        if platform.system() == "Darwin":
            result = subprocess.run(["lsof", "-nP"], capture_output=True, text=True)
            for dev in [x for x in os.listdir("/dev") if x.startswith("tty.") or x.startswith("cu.")]:
                if dev in result.stdout:
                    logger.warning(f"[BLE_DIAG] Device lock: {dev} in use by:\n" + '\n'.join([line for line in result.stdout.splitlines() if dev in line]))
        elif platform.system() == "Linux":
            result = subprocess.run(["lsof", "/dev/bluetooth*"], capture_output=True, text=True)
            if result.stdout:
                logger.warning(f"[BLE_DIAG] /dev/bluetooth* in use by:\n{result.stdout}")
    except Exception:
        logger.warning(f"[BLE_DIAG] Error running connection/session detection: {traceback.format_exc()}")
    # 4. User Guidance/Next Steps
    logger.info("[BLE_DIAG] ===== BLE TROUBLESHOOTING CHECKLIST =====")
    logger.info("[BLE_DIAG] 1. Ensure BB-8 is powered on and awake.")
    logger.info("[BLE_DIAG] 2. Ensure Bluetooth is enabled and adapter is discoverable.")
    logger.info("[BLE_DIAG] 3. Close other BLE apps or utilities that may be using the adapter.")
    logger.info("[BLE_DIAG] 4. If adapter is busy/locked, try rebooting or run 'sudo pkill -f bluetoothd' (macOS) or restart bluetooth service (Linux).")
    logger.info("[BLE_DIAG] 5. Check user permissions and group membership for BLE access.")
    logger.info("[BLE_DIAG] 6. If all else fails, reboot your computer and BB-8.")
    logger.info("[BLE_DIAG] ===== BLE CORE DIAGNOSTICS END =====")

def list_ble_processes() -> List[str]:
    """Return a list of process names that may be using BLE resources (best effort)."""
    procs = []
    if psutil:
        for p in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if any(x in ' '.join(p.info.get('cmdline', [])) for x in ['bluetooth', 'ble', 'BlueTool', 'bluetoothd', 'Bluez', 'corebluetooth']):
                    procs.append(f"{p.info['name']} (pid {p.info['pid']})")
            except Exception:
                continue
    return procs

class BleGateway:
    """
    Class-based BLE Gateway for BB-8 device management.
    Encapsulates adapter selection, device scanning, connection, and shutdown.
    """
    def __init__(self, mode: Optional[str] = None):
        self.logger = logging.getLogger(__name__)
        self.mode = mode or os.environ.get("SPHERO_ADAPTER", "bleak")
        self.device = None
        self.adapter = None
        self._init_adapter()

    def _init_adapter(self):
        self.logger.info(f"Using BLE adapter mode: {self.mode}")
        try:
            from bleak import BleakClient
            # Scan for BB-8 device (address discovery)
            if not SPHEROV2_AVAILABLE:
                raise RuntimeError("spherov2 library not available")
            if not BLEAK_AVAILABLE:
                raise RuntimeError("bleak library not available for BLE")
            if not find_BB8:
                raise RuntimeError("find_BB8 function not available (spherov2 import failed)")
            self.logger.debug("[DEBUG] About to call find_BB8 for BLE scan...")
            bb8_toy = find_BB8(timeout=30)  # Increased timeout for initial scan
            self.logger.debug(f"[DEBUG] find_BB8 returned: {bb8_toy}")
            if not bb8_toy:
                raise RuntimeError("No BB-8 devices found during scan")
            address = getattr(bb8_toy, 'address', None)
            self.logger.debug(f"[DEBUG] BB-8 device attributes: {vars(bb8_toy) if hasattr(bb8_toy, '__dict__') else str(bb8_toy)}")
            if not address:
                raise RuntimeError("BB-8 device found but has no BLE address")
            self.logger.info(f"Found BB-8 at address: {address}")
            import asyncio
            async def connect_bleak():
                client = BleakClient(address)
                await client.connect()
                return client
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            client = loop.run_until_complete(connect_bleak())
            self.logger.info(f"BleakClient connected: {client}, {address}")
            self.adapter = BleakAdapter(client)
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            self.logger.error(f"BLE adapter initialization failed: {type(e).__name__}: {e}\n{tb}")
            self.logger.error(f"[DEBUG] Exception during BLE/protocol init: {e}, mode={self.mode}, platform={platform.platform()}, bleak={BLEAK_AVAILABLE}, spherov2={SPHEROV2_AVAILABLE}")
            self.logger.error("Troubleshooting checklist: Is Bluetooth enabled? Is the BB-8 device powered on? Is another BLE app running? On macOS, is CoreBluetooth available? On Linux, is bluez running and are permissions correct? Try restarting Bluetooth or your computer.")

    def scan_for_device(self, timeout: int = 10, retries: int = 3, delay: int = 2):
        import time, platform, traceback, datetime
        from bleak import BleakScanner
        attempt = 0
        last_exception = None
        all_visible_devices = []
        lock_detected = False
        devices = []  # Ensure devices is always defined
        import asyncio  # Ensure asyncio is always imported and available
        while attempt < retries:
            timestamp = datetime.datetime.utcnow().isoformat()
            self.logger.info(f"[BLE SCAN] Attempt {attempt+1}/{retries} at {timestamp} on platform {platform.platform()} mode={self.mode}")
            # Pre-scan: list visible BLE devices
            try:
                loop = None
                try:
                    loop = asyncio.get_event_loop()
                except RuntimeError:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                async def discover_ble():
                    return await BleakScanner.discover(timeout=3)
                try:
                    devices = loop.run_until_complete(discover_ble())
                except Exception as e:
                    self.logger.warning(f"[BLE SCAN] BleakScanner.discover failed: {e}\n{traceback.format_exc()}")
                    devices = []
                all_visible_devices.append(devices)
                self.logger.info(f"[BLE SCAN] Devices visible before scan: {[str(d) for d in devices]}")
            except Exception as e:
                self.logger.warning(f"[BLE SCAN] Could not enumerate BLE devices: {e}\n{traceback.format_exc()}")
            # Log adapter/process state
            if psutil:
                ble_procs = list_ble_processes()
                if ble_procs:
                    self.logger.warning(f"[BLE SCAN] Other BLE-related processes detected: {ble_procs}")
                    lock_detected = True
            try:
                self.logger.info(f"[BLE_STATE] Pre-scan: known device={getattr(self, 'device', None)}, adapter={self.adapter}, mode={self.mode}")
                if find_BB8 is None:
                    raise RuntimeError("find_BB8 function is not available (spherov2 import failed)")
                bb8_toy = find_BB8(timeout=timeout)
                self.logger.info(f"[BLE_STATE] Post-scan: found device={bb8_toy}")
                if bb8_toy:
                    address = getattr(bb8_toy, 'address', None)
                    self.logger.info(f"BB-8 device found: {bb8_toy}, address: {address}, on attempt {attempt+1}")
                    self.device = bb8_toy
                    # Summary log
                    self.logger.info(f"[BLE SCAN SUMMARY] Success on attempt {attempt+1}. Devices seen: {[str(d) for d in devices] if 'devices' in locals() else 'N/A'}. Lock detected: {lock_detected}")
                    return self.device
                else:
                    raise TimeoutError("No BB-8 devices found during scan")
            except Exception as e:
                tb = traceback.format_exc()
                self.logger.error(f"[BLE SCAN] Exception: {repr(e)}\n{tb}")
                self.logger.warning(f"[BLE_STATE] Adapter: {self.adapter}, Device: {getattr(self, 'device', None)}, Mode: {self.mode}")
                emit_ble_core_diagnostics()
                if any(x in str(e).lower() for x in ["busy", "locked", "resource"]):
                    self.logger.warning("[BLE_LOCK] BLE resource appears locked or busy. Recommend power-cycling adapter, restarting Bluetooth, or killing stuck processes.")
                    lock_detected = True
                self.logger.warning("[BLE SCAN] Actionable guidance: Reboot BB-8, restart Bluetooth, ensure no other BLE apps are running, and try again.")
                last_exception = e
                attempt += 1
                if attempt < retries:
                    self.logger.info(f"Retrying BB-8 scan in {delay} seconds...")
                    time.sleep(delay)
        # All attempts failed
        self.logger.error(f"Failed to find BB-8 after {retries} attempts.")
        self.logger.error(f"BLE/Adapter/Platform state: mode={self.mode}, platform={platform.platform()}, bleak={BLEAK_AVAILABLE}, spherov2={SPHEROV2_AVAILABLE}")
        self.logger.error(f"[BLE SCAN SUMMARY] Failure after {retries} attempts. Devices seen: {[[str(d) for d in devs] for devs in all_visible_devices]}. Lock detected: {lock_detected}. Root cause: {repr(last_exception)}")
        self.logger.error("Troubleshooting checklist: Is Bluetooth enabled? Is the BB-8 device powered on? Is another BLE app running? On macOS, is CoreBluetooth available? On Linux, is bluez running and are permissions correct? Try restarting Bluetooth or your computer.")
        emit_ble_core_diagnostics()
        raise last_exception if last_exception else RuntimeError("Could not find BB-8 device after retries.")

    def get_connection_status(self):
        return {"connected": self.device is not None}

    def shutdown(self):
        self.logger.info("BLE Gateway shutdown invoked")
        if self.adapter and hasattr(self.adapter, "disconnect"):
            try:
                self.adapter.disconnect()
            except Exception as e:
                self.logger.warning(f"Adapter disconnect failed: {e}")
        self.device = None

__all__: list[str] = []
