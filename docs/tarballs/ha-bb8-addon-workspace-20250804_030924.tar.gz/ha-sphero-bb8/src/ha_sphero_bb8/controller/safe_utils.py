# This file has been moved to ha_sphero_bb8.device_core.utils.safe_utils
raise ImportError("safe_utils.py has moved to ha_sphero_bb8.device_core.utils.safe_utils. Update your imports.")
