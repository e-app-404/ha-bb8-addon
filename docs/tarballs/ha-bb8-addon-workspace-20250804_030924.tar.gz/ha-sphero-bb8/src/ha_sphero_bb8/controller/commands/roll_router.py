from .roll_profiles import (
    roll_timed,
    roll_reverse,
)
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ha_sphero_bb8.controller import BB8Like
import logging

logger = logging.getLogger(__name__)

def dispatch_roll(payload: dict, device: "BB8Like") -> dict:
    mode = payload.get("mode", "default")
    if mode == "timed":
        return roll_timed(payload, device)
    elif mode == "reverse":
        return roll_reverse(payload, device)
    else:
        try:
            speed = int(payload.get("speed", 50))
            heading = int(payload.get("heading", 0))
            timeout = float(payload.get("timeout", 1.5))
            boost = bool(payload.get("boost", False))
            logger.info(f"Default roll: heading={heading}, speed={speed}, timeout={timeout}, boost={boost}")
            result = device.roll(speed=speed, heading=heading, timeout=timeout, boost=boost)
            return {"status": "rolled_default", "result": result}
        except Exception as e:
            logger.error(f"Roll command failed: {e}")
            return {"status": "error", "error": str(e)}

__all__ = [
    "dispatch_roll"
]
