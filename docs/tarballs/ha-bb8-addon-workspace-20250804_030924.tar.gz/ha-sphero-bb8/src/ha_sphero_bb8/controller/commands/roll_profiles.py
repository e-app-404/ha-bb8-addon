from typing import Protocol
import logging
import time
logger = logging.getLogger(__name__)

class BB8Like(Protocol):
    def roll(self, speed: int, heading: int, timeout: float = 0.0, boost: bool = False) -> dict: ...
    def stop(self) -> None: ...

def roll_timed(payload: dict, device: BB8Like):
    speed = int(payload.get("speed", 50))
    heading = int(payload.get("heading", 0))
    timeout = float(payload.get("timeout", 1.5))
    boost = bool(payload.get("boost", False))
    logger.info(f"Timed roll: heading={heading}, speed={speed}, timeout={timeout}, boost={boost}")
    result = device.roll(speed=speed, heading=heading, timeout=timeout, boost=boost)
    time.sleep(timeout)
    device.stop()
    return {"status": "rolled_timed", "result": result}

def roll_reverse(payload: dict, device: BB8Like):
    speed = int(payload.get("speed", 50))
    heading = int(payload.get("heading", 0))
    timeout = float(payload.get("timeout", 1.5))
    boost = bool(payload.get("boost", False))
    reverse_heading = (heading + 180) % 360
    logger.info(f"Reverse roll: heading={reverse_heading}, speed={speed}, timeout={timeout}, boost={boost}")
    result = device.roll(speed=speed, heading=reverse_heading, timeout=timeout, boost=boost)
    time.sleep(timeout)
    device.stop()
    return {"status": "rolled_reverse", "result": result}

__all__ = [
    "roll_timed",
    "roll_reverse"
]
