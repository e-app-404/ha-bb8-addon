import asyncio
import time
import logging
from typing import Any, Optional, Callable

def is_ping_success(result: Any) -> bool:
    """Determine if a ping result indicates success."""
    return result is True or (isinstance(result, dict) and result.get("success"))

async def run_ping(device: Any, safe_ping: Optional[Callable] = None) -> (bool, Optional[str]):
    """Attempt to ping the device, using async or sync ping if available."""
    try:
        if hasattr(device, "ping") and callable(device.ping):
            if asyncio.iscoroutinefunction(device.ping):
                result = await device.ping()
            else:
                result = device.ping()
        elif safe_ping:
            result = safe_ping(device)
        else:
            return False, "No ping method available"
        if is_ping_success(result):
            return True, None
        else:
            return False, str(result)
    except Exception as e:
        return False, str(e)

async def heartbeat_loop(
    device: Any,
    safe_ping: Optional[Callable],
    interval: int,
    failure_threshold: int,
    on_status: Callable[[bool, bool, int, Optional[str]], None],
    logger: Optional[logging.Logger] = None
):
    """Centralized heartbeat loop for BB-8 connection health."""
    heartbeat_failures = 0
    device_connected = True if device is not None else False
    while True:
        try:
            if device is None or not device_connected:
                if logger:
                    logger.warning("Heartbeat: device not connected; skipping ping.")
                on_status(False, False, heartbeat_failures, "Device not connected")
                await asyncio.sleep(interval)
                continue
            success, error = await run_ping(device, safe_ping)
            if success:
                if logger:
                    logger.info("Heartbeat: ping successful.")
                heartbeat_failures = 0
                on_status(True, True, heartbeat_failures, None)
            else:
                heartbeat_failures += 1
                if logger:
                    logger.warning(f"Heartbeat: ping failed ({heartbeat_failures} consecutive failures)")
                on_status(True, False, heartbeat_failures, error)
                if heartbeat_failures >= failure_threshold:
                    if logger:
                        logger.error("Heartbeat: connection lost, marking device as disconnected.")
                    device_connected = False
                    on_status(False, False, heartbeat_failures, error)
            await asyncio.sleep(interval)
        except Exception as e:
            heartbeat_failures += 1
            if logger:
                logger.error(f"Heartbeat: exception during ping: {e}")
            on_status(False, False, heartbeat_failures, str(e))
            await asyncio.sleep(interval)
