#!/usr/bin/env python3
"""
MODULE PURPOSE: Canonical CLI entrypoint for running the Sphero BB-8 MQTT event loop.
Handles command-line arguments, initializes the real BLE hardware,
and starts the main MQTTHandler loop.
STATUS: production
MAIN ENTRYPOINTS: main() function, CLI argument parsing, MQTTHandler instantiation
DEPENDENCIES: Imports mqtt_handler.py, constants.py
LAST VALIDATED: 2025-08-02
NOTES:
- All CLI launches should occur from project root:
    python -m ha_sphero_bb8.run_mqtt
- Extend here to add new CLI options (e.g., diagnostics, verbosity)
"""

import os
import sys
import argparse
import logging
import signal
import time
from datetime import datetime
from typing import Optional, TYPE_CHECKING
import traceback

try:
    import yaml
except ImportError:
    yaml = None

from ha_sphero_bb8.ble_gateway import BleGateway
from ha_sphero_bb8 import mqtt_handler
from ha_sphero_bb8.mqtt_dispatcher import dispatch_from_topic
import paho.mqtt.client as mqtt
from spherov2.scanner import find_BB8

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

from .constants import MQTT_CONTROL_TOPIC, MQTT_USER, MQTT_PW
from .bb8_control import initialize_bb8
from ha_sphero_bb8.controller import ControllerMode, BB8Controller

mqtt_client = None
bb8_device = None
shutdown_requested = False

def signal_handler(signum, frame):
    global shutdown_requested
    logger.info(f"🔄 Received signal {signum}, initiating graceful shutdown...")
    shutdown_requested = True

def load_config_yaml(path="config.yaml"):
    if yaml is None:
        return {}
    if not os.path.exists(path):
        return {}
    with open(path, "r") as f:
        return yaml.safe_load(f)

def setup_logging(verbose: bool = False):
    root_logger = logging.getLogger()
    if verbose:
        root_logger.setLevel(logging.DEBUG)
        logging.getLogger('ha_sphero_bb8').setLevel(logging.DEBUG)
        logger.info("🔍 Verbose logging enabled")
    else:
        root_logger.setLevel(logging.INFO)
        logging.getLogger('paho').setLevel(logging.WARNING)
        logging.getLogger('bleak').setLevel(logging.WARNING)

def setup_audit_logging(mac: str = "UNKNOWN"):
    artifacts_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "artifacts")
    os.makedirs(artifacts_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"JTBD-02_log_{timestamp}_{mac}.txt"
    log_path = os.path.join(artifacts_dir, log_filename)
    file_handler = logging.FileHandler(log_path, mode="a")
    file_handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    root_logger = logging.getLogger()
    for h in root_logger.handlers[:]:
        if isinstance(h, logging.FileHandler):
            root_logger.removeHandler(h)
    root_logger.addHandler(file_handler)
    logger.info(f"Audit log file created at: {log_path}")
    return log_path

def print_startup_status(args, device=None, mac=None):
    logger.info(f"\n===== BB-8 MQTT Orchestration Startup =====")
    logger.info(f"CLI Args: {args}")
    if mac:
        logger.info(f"BB-8 MAC: {mac}")
    if device:
        logger.info(f"Device: {device}")
    logger.info(f"==========================================\n")

def setup_mqtt_and_handler(config, controller):
    paho_client = mqtt.Client(client_id=getattr(config, 'client_id', None))
    if config.username and config.password:
        paho_client.username_pw_set(config.username, config.password)
    mqtt_handler_obj = mqtt_handler.MqttHandler(mqtt_client=paho_client, controller=controller, config=config)
    mqtt_handler_obj.connect()
    from ha_sphero_bb8.constants import MQTT_COMMAND_TOPIC, MQTT_CONTROL_TOPIC
    paho_client.subscribe(MQTT_COMMAND_TOPIC)
    paho_client.subscribe(MQTT_CONTROL_TOPIC)
    paho_client.loop_start()
    return paho_client, mqtt_handler_obj

def print_mqtt_instructions():
    logger.info("Send commands to the following MQTT topics and payloads:")
    logger.info("  Topic: bb8/command/move        Payload: {\"speed\": 80, \"heading\": 0}")
    logger.info("  Topic: bb8/command/move        Payload: {\"speed\": 80, \"heading\": 180}")
    logger.info("  Topic: bb8/command/rotate      Payload: {\"angle\": 90, \"speed\": 50}")
    logger.info("  Topic: bb8/command/led         Payload: {\"r\": 0, \"g\": 255, \"b\": 0}")
    logger.info("  Topic: bb8/command/led         Payload: {\"r\": 255, \"g\": 0, \"b\": 0}")
    logger.info("  Topic: bb8/command/stop        Payload: {}")
    logger.info("  Topic: bb8/command/diagnostics Payload: {}")
    logger.info("  Topic: bb8/command/test        Payload: {}")

def cleanup(paho_client, device=None):
    logger.info("Shutting down MQTT and device resources...")
    if paho_client:
        try:
            paho_client.loop_stop()
            paho_client.disconnect()
            logger.info("MQTT client disconnected.")
        except Exception as e:
            logger.error(f"Error during MQTT cleanup: {e}")
    if device and hasattr(device, 'close'):
        try:
            device.close()
            logger.info("Device closed.")
        except Exception as e:
            logger.error(f"Error during device cleanup: {e}")

def run_hardware_mode(args):
    from ha_sphero_bb8.controller import BB8Controller, ControllerMode
    from spherov2.scanner import find_BB8
    paho_client = None
    bb8 = None
    try:
        logger.debug(f"[DEBUG] Entering find_BB8 context manager with args: {args}")
        with find_BB8(timeout=30) as bb8:
            mac = getattr(bb8, 'mac', 'UNKNOWN')
            logger.info("✅ BB-8 device context opened successfully (hardware mode)")
            logger.debug(f"[DEBUG] BB-8 context details: {vars(bb8) if hasattr(bb8, '__dict__') else str(bb8)}")
            print_startup_status(args, device=bb8, mac=mac)
            controller_mode = ControllerMode.HARDWARE
            controller = BB8Controller(mode=controller_mode, device=bb8)
            config = mqtt_handler.create_default_config()
            config.host = args.broker
            config.port = args.port
            config.username = args.username if args.username else MQTT_USER
            config.password = args.password if args.password else MQTT_PW
            paho_client, _ = setup_mqtt_and_handler(config, controller)
            print_mqtt_instructions()
            logger.info("⌨️  Press Ctrl+C to shutdown")
            while not shutdown_requested:
                time.sleep(1)
    except Exception as e:
        logger.error(f"❌ Failed to open BB-8 context manager: {e}")
        logger.error(traceback.format_exc())
        logger.error(f"[DEBUG] Exception occurred in find_BB8 context: {e}, args: {args}")
        logger.error(f"CLI Args: {args}")
        raise
    finally:
        cleanup(paho_client, bb8)

def main():
    global mqtt_client, bb8_device
    config_defaults = load_config_yaml()
    parser = argparse.ArgumentParser(
        description="MQTT Runtime Orchestration for Sphero BB-8",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --broker localhost
  %(prog)s --verbose --broker 192.168.0.129 --port 1883
        """
    )
    parser.add_argument('--broker', default=config_defaults.get('broker', 'localhost'), help='MQTT broker address')
    parser.add_argument('--port', type=int, default=config_defaults.get('port', 1883), help='MQTT broker port')
    parser.add_argument('--username', default=config_defaults.get('username', None), help='MQTT username')
    parser.add_argument('--password', default=config_defaults.get('password', None), help='MQTT password')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose logging')
    parser.add_argument('--battery-status', action='store_true', help='Query and print BB-8 battery status, then exit')

    args = parser.parse_args()
    setup_logging(args.verbose)
    log_path = setup_audit_logging("UNKNOWN")
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    logger.info("🚀 Starting MQTT Runtime Orchestration for BB-8...")
    logger.info(f"📡 MQTT broker: {args.broker}:{args.port}")
    # BLE Gateway initialization
    ble_gateway = BleGateway()
    logger.debug("[DEBUG] BLE Gateway object: %r", ble_gateway)
    logger.info("==== BLE Gateway initialized, about to start hardware mode ====")
    try:
        run_hardware_mode(args)
    except Exception as e:
        logger.error(f"❌ Unhandled exception in main: {e}")
        logger.error(traceback.format_exc())
        logger.error(f"CLI Args: {args}")
        sys.exit(1)

if __name__ == "__main__":
    main()
