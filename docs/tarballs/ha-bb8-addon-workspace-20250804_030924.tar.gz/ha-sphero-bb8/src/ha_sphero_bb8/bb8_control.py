#!/usr/bin/env python3
"""
BB-8 device control and simulation entrypoints.
Provides CLI and programmatic access to BB-8 hardware and simulation.

MODULE PURPOSE: BB-8 device initialization, protocol compliance, and adapter logic.
STATUS: production
MAIN ENTRYPOINTS: initialize_bb8, BB8Adapter, Bb8Controller, BB8Control
DEPENDENCIES: controller.py, ble_gateway.py, spherov2, device_core/utils
LAST VALIDATED: 2025-06-18
NOTES:
- Ensures all devices conform to BB8Like protocol.
- Handles both real and simulated device initialization.
"""

# Do not import run_mqtt.py (entrypoint script) in library code to avoid circular imports.

from spherov2.sphero_edu import SpheroEduAPI
from spherov2.types import Color
import time
import logging
import sys
from typing import Optional, TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ha_sphero_bb8.controller import BB8Like  # type: ignore

from ha_sphero_bb8.device_core.utils.safe_utils import (
    safe_ping,
    safe_set_main_led,
    safe_get_voltage,
    safe_get_percentage
)
from ha_sphero_bb8.ble_gateway import BleGateway
from spherov2.toy.bb8 import BB8

# Configure logger
logger = logging.getLogger(__name__)
handler = logging.StreamHandler(sys.stderr)
handler.setLevel(logging.WARNING)
if not logger.hasHandlers():
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

class Bb8Controller:
    """Controller class for managing BB-8 device connection and basic operations."""
    def __init__(self) -> None:
        """Initialize the Bb8Controller with no connected toy."""
        self.toy: Optional[Any] = None
        self.api: Optional[Any] = None

    def disconnect(self) -> dict:
        """No-op disconnect for Bb8Controller (for shutdown consistency)."""
        logger.info("Bb8Controller: disconnect called (no-op)")
        return {"success": True, "message": "Bb8Controller: disconnect called"}

class BB8Adapter:
    """Adapter to ensure any device conforms to BB8Like protocol."""
    def __init__(self, device: Any) -> None:
        self._device = device
        # Runtime check for required protocol methods
        required = ["set_main_led", "ping", "roll", "stop"]
        for method in required:
            if not hasattr(self._device, method):
                logger.error(f"BB8Adapter: Underlying device missing required method: {method}")
        # Optionally, raise or log as needed

    def disconnect(self) -> dict:
        logger.info("BB8Adapter: disconnect called (no-op)")
        return {"success": True, "message": "BB8Adapter: disconnect called"}

    def set_main_led(self, r: int, g: int, b: int) -> None:
        """
        Protocol compliance: call set_main_led on the underlying device if available, else log error.
        """
        if hasattr(self._device, 'set_main_led') and callable(getattr(self._device, 'set_main_led', None)):
            return self._device.set_main_led(r, g, b)
        logger.error("BB8Adapter: set_main_led not implemented on underlying device.")
        raise NotImplementedError("set_main_led not implemented on device/adapter chain")

    def ping(self) -> bool:
        """
        Protocol compliance: call ping on the underlying device if available, else log error.
        """
        if hasattr(self._device, 'ping') and callable(getattr(self._device, 'ping', None)):
            return self._device.ping()
        logger.error("BB8Adapter: ping not implemented on underlying device.")
        raise NotImplementedError("ping not implemented on device/adapter chain")

    def roll(self, speed: int, heading: int, timeout: Optional[float] = None, boost: bool = False) -> dict:
        """
        Roll the BB-8 device at a given speed and heading, protocol-compliant signature.
        """
        if hasattr(self._device, 'roll') and callable(getattr(self._device, 'roll', None)):
            try:
                return self._device.roll(speed=speed, heading=heading, timeout=timeout, boost=boost)
            except TypeError:
                return self._device.roll(speed, heading)
        logger.error("BB8Adapter: roll not implemented on underlying device.")
        raise NotImplementedError("roll not implemented on device/adapter chain")

    def stop(self) -> None:
        if hasattr(self._device, 'stop') and callable(getattr(self._device, 'stop', None)):
            return self._device.stop()
        logger.error("BB8Adapter: stop not implemented on underlying device.")
        raise NotImplementedError("stop not implemented on device/adapter chain")

    def get_battery_voltage(self) -> float:
        if hasattr(self._device, 'get_battery_voltage'):
            return self._device.get_battery_voltage()
        raise NotImplementedError("get_battery_voltage not implemented")

    def get_battery_percentage(self) -> int:
        if hasattr(self._device, 'get_battery_percentage'):
            return self._device.get_battery_percentage()
        raise NotImplementedError("get_battery_percentage not implemented")

    def set_led(self, r: int, g: int, b: int) -> None:
        """
        Proxy set_led to the underlying device/adapter, with full logging of type and available methods.
        """
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"[BB8Adapter.set_led] device type: {type(self._device)}, dir: {dir(self._device)}")
        # Log BleakAdapter/device chain if present
        if hasattr(self._device, 'device'):
            logger.info(f"[BB8Adapter.set_led] self._device.device type: {type(self._device.device)}, dir: {dir(self._device.device)}")
        # Try set_led or set_main_led
        if hasattr(self._device, 'set_led') and callable(getattr(self._device, 'set_led', None)):
            logger.info("[BB8Adapter.set_led] Calling self._device.set_led...")
            return self._device.set_led(r, g, b)
        elif hasattr(self._device, 'set_main_led') and callable(getattr(self._device, 'set_main_led', None)):
            logger.info("[BB8Adapter.set_led] Calling self._device.set_main_led...")
            return self._device.set_main_led(r, g, b)
        else:
            logger.error(f"[BB8Adapter.set_led] ABORTED: device does not support set_led or set_main_led. type: {type(self._device)}, dir: {dir(self._device)}")
            raise NotImplementedError("set_led not implemented on device/adapter chain")

def initialize_bb8(adapter_mode: Optional[str] = None, allow_sim_fallback: Optional[bool] = None, scan_retries: int = 3, scan_delay: int = 2) -> 'BB8Like':
    """Initialize BB-8 device with BLE adapter and perform basic checks.
    Always returns BB8Like protocol-compliant device."""
    logger.info("Initializing BB-8 device...")

    gateway = BleGateway(mode=adapter_mode if adapter_mode is not None else "bleak", allow_sim_fallback=allow_sim_fallback)
    try:
        device = gateway.scan_for_device(retries=scan_retries, delay=scan_delay)
    except Exception as e:
        logger.error(f"❌ BB-8 device initialization failed after {scan_retries} attempts: {e}")
        import traceback
        logger.error(traceback.format_exc())
        logger.error("Troubleshooting: Ensure BB-8 is powered on and awake, Bluetooth is enabled, no other BLE apps are running, and try rebooting your system.")
        raise

    if device is None:
        raise RuntimeError("Failed to obtain BLE adapter")

    # Attempt to wake/ping device if supported
    if hasattr(device, 'wake') and callable(getattr(device, 'wake', None)):
        logger.debug("Waking BB-8 device...")
        try:
            device.wake()
            time.sleep(0.5)
        except Exception as wake_error:
            logger.debug(f"Wake step failed or not implemented: {wake_error}")

    if hasattr(device, 'ping') and callable(getattr(device, 'ping', None)):
        logger.debug("Pinging BB-8 device for connectivity check...")
        try:
            ping_response = safe_ping(device)
            if not ping_response:
                logger.warning("Ping response was empty or failed")
        except Exception as ping_error:
            logger.warning(f"Ping failed or not supported: {ping_error}")

    if device is None:
        raise ConnectionError("Device is not connected")
    logger.info("BB-8 connection confirmed")

    if hasattr(device, 'set_main_led') and callable(getattr(device, 'set_main_led', None)):
        logger.debug("Testing LED connectivity...")
        try:
            safe_set_main_led(device, 0, 0, 50)
            time.sleep(0.2)
            safe_set_main_led(device, 0, 0, 0)
            logger.debug("LED test successful")
        except Exception as led_error:
            logger.warning(f"LED test failed: {led_error}")

    # Ensure protocol compliance: always wrap unless already BB8Adapter or BB8Like
    from ha_sphero_bb8.controller import BB8Like  # runtime_checkable!
    try:
        from typing import runtime_checkable
        BB8Like = runtime_checkable(BB8Like)
    except Exception:
        pass  # Already runtime_checkable or not needed

    # Always wrap unless already BB8Adapter or BB8Like
    if not isinstance(device, BB8Adapter):
        device = BB8Adapter(device)

    logger.info("BB-8 initialization complete (protocol-compliant)")
    return device

class BB8Control:
    """Main class for BB-8 device control and simulation entrypoints."""
    def __init__(self, device: Optional[Any] = None, simulate: bool = False) -> None:
        self.device = device
        self.simulate_mode = simulate
        self.toy: Optional[Any] = None
        self.api: Optional[Any] = None

        if self.toy is not None:
            toy_for_api = getattr(self.toy, "_device", self.toy)
            if BB8 is not None and isinstance(toy_for_api, BB8):
                with SpheroEduAPI(toy_for_api) as api:
                    self.api = api
                    api.set_main_led(Color(255, 1, 0))
                    api.roll(0, 50, 2.0)
                    api.set_speed(60)
                    time.sleep(2)
                    api.set_speed(0)
            else:
                logger.warning("Underlying toy is not a BB8 instance; skipping SpheroEduAPI block.")

    def connect(self) -> None:
        """Connect to the BB-8 device or simulation."""
        print("[INFO] Attempting BB-8 connection (BLE_ENABLED gated)...")
        self.toy = initialize_bb8()
        if not self.toy:
            print("[INFO] Skipping BLE — run in simulation mode")
            self.simulate()
            return

        if self.toy is not None:
            toy_for_api = getattr(self.toy, "_device", self.toy)
            if BB8 is not None and isinstance(toy_for_api, BB8):
                with SpheroEduAPI(toy_for_api) as api:
                    self.api = api
                    api.set_main_led(Color(255, 1, 0))
                    api.roll(0, 50, 2.0)
                    api.set_speed(60)
                    time.sleep(2)
                    api.set_speed(0)
            else:
                logger.warning("Underlying toy is not a BB8 instance; skipping SpheroEduAPI block.")

    def disconnect(self) -> None:
        """Disconnect from the BB-8 device or simulation."""
        if self.toy:
            try:
                logger.info("Disconnecting from BB-8 device...")
                self.toy.disconnect()
            except Exception as e:
                logger.warning(f"Error during disconnection: {e}")
            finally:
                self.toy = None
        logger.info("BB-8 device disconnected")

    def roll(self, heading: int, speed: int) -> None:
        """Roll BB-8 in a given direction at a given speed."""
        if self.toy:
            self.toy.roll(heading, speed)
        else:
            logger.warning("roll called but BB-8 is not connected")

    def stop(self) -> None:
        """Stop BB-8's movement."""
        if self.toy:
            self.toy.stop()
        else:
            logger.warning("stop called but BB-8 is not connected")

    def get_diagnostics(self) -> None:
        """Get diagnostics and status for BB-8."""
        if self.toy:
            voltage = safe_get_voltage(self.toy)
            percentage = safe_get_percentage(self.toy)
            logger.info(f"BB-8 Diagnostics - Voltage: {voltage}V, Battery: {percentage}%")
        else:
            logger.warning("get_diagnostics called but BB-8 is not connected")

    def simulate(self) -> None:
        """Simulate BB-8 actions in simulation mode."""
        print("[SIMULATION] BB-8 would roll forward, set LED to red, then stop.")

__all__: list[str] = []
