"""
MODULE PURPOSE: Single source for all MQTT topics, adapter mode names, broker config, and shared project constants.
STATUS: production
MAIN ENTRYPOINTS: MQTT_COMMAND_TOPIC, MQTT_STATUS_TOPIC, MQTT_BROKER_HOST, ADAPTER_MODES, etc.
DEPENDENCIES: Imported by all handler, controller, and CLI modules.
LAST VALIDATED: 2025-06-18
NOTES:
- Update topic strings and config here ONLY. No hard-coded values elsewhere.
"""

# ha_sphero_bb8/constants.py
# Centralized project constants for MQTT topics, broker, and adapter modes

# MQTT Topics
MQTT_COMMAND_TOPIC = "bb8/command/#"
MQTT_STATUS_TOPIC = "bb8/status"
MQTT_DIAGNOSTICS_TOPIC = "bb8/diagnostics"
MQTT_RESPONSE_TOPIC = "bb8/response"

# Additional topic for control channel (used in run_mqtt.py)
MQTT_CONTROL_TOPIC = "bb8/control"

# MQTT Broker Config
HOST = "192.168.0.129"
MQTT_BROKER_HOST = "localhost"
MQTT_BROKER_ALIAS = "core.mosquitto.org"
MQTT_BROKER = "mosquitto"
MQTT_BROKER_PORT = 1883
MQTT_BROKER_KEEPALIVE = 60
MQTT_USER = "mqtt_bb8"
MQTT_PW = "mqtt_bb8"
MQTT_CLIENT_ID = "mqtt-explorer-mac"

# Adapter Modes
ADAPTER_REAL = "real"
ADAPTER_SIM = "sim"

# All supported adapter modes
ADAPTER_MODES = [ADAPTER_REAL, ADAPTER_SIM]

# Global flags
BLE_ENABLED = True  # Conservative default; BLE_ENABLED not defined in ble_gateway
MQTT_ENABLED = True

# Home Assistant/Project topic structure
BASE_TOPIC = "bb8"
COMMAND_TOPIC = f"{BASE_TOPIC}/command"
STATUS_TOPIC = f"{BASE_TOPIC}/status"
DIAGNOSTICS_TOPIC = f"{BASE_TOPIC}/diagnostics"
DISCOVERY_PREFIX = "homeassistant"
DEVICE_NAME = "Sphero BB-8"
DEVICE_ID = "sphero_bb8"

# BB-8 Specific Constants
BB8_DEVICE_NAME = "BB-8"
BB8_DEVICE_ID = "ha-bb-8"
BB8_DEVICE_MAC = "B8:17:C2:A8:ED:45"

# BB-8 LED Color Constants
BB8_LED_COLOR_RED = (255, 0, 0)
BB8_LED_COLOR_GREEN = (0, 255, 0)
BB8_LED_COLOR_BLUE = (0, 0, 255)
# BB-8 Battery Levels
BB8_BATTERY_LOW = 20  # Percentage
BB8_BATTERY_CRITICAL = 10  # Percentage
# BB-8 Speed Constants
BB8_SPEED_MIN = 0  # Minimum speed
BB8_SPEED_MAX = 255  # Maximum speed
# BB-8 Heading Constants
BB8_HEADING_MIN = 0  # Minimum heading (degrees)
BB8_HEADING_MAX = 360  # Maximum heading (degrees)
# BB-8 Rotation Constants
BB8_ROTATION_MIN = -180  # Minimum rotation angle (degrees)
BB8_ROTATION_MAX = 180  # Maximum rotation angle (degrees)
# BB-8 Diagnostics
BB8_DIAGNOSTICS_INTERVAL = 60  # Interval for diagnostics updates (seconds)
# BB-8 Connection Timeout
BB8_CONNECTION_TIMEOUT = 10  # Timeout for BB-8 connection attempts (seconds)

# BB-8 Default Values
BB8_DEFAULT_LED_COLOR = BB8_LED_COLOR_BLUE  # Default LED color when not specified
BB8_DEFAULT_SPEED = 50  # Default speed for BB-8 movement commands
BB8_DEFAULT_HEADING = 0  # Default heading for BB-8 movement commands
BB8_DEFAULT_ROTATION_ANGLE = 90  # Default rotation angle for BB-8 rotation commands
BB8_DEFAULT_BATTERY_CHECK_INTERVAL = 300  # Default interval for battery checks (seconds)
BB8_DEFAULT_LED_BRIGHTNESS = 255  # Default brightness for BB-8 LED (0-255)
BB8_DEFAULT_DIAGNOSTICS_UPDATE_INTERVAL = 60  # Default interval for diagnostics updates (seconds)
BB8_DEFAULT_CONNECTION_RETRY_INTERVAL = 5  # Default interval for connection retries (seconds)
BB8_DEFAULT_COMMAND_TIMEOUT = 5  # Default timeout for BB-8 commands (seconds)
BB8_DEFAULT_COMMAND_RETRIES = 3  # Default number of retries for BB-8 commands
BB8_DEFAULT_COMMAND_RETRY_INTERVAL = 2  # Default interval between command retries (seconds)

