# src/ha_sphero_bb8/color_dance.py

"""
MODULE PURPOSE: Demo script for color LED cycling on Sphero BB-8 via BLE. Used for hardware validation and visual diagnostics.
STATUS: production (utility/demo)
MAIN ENTRYPOINTS: color_dance sequence (main block)
DEPENDENCIES: ble_gateway.py, spherov2, SpheroEduAPI
LAST VALIDATED: 2025-06-18
NOTES:
- Not part of main CLI; run directly for hardware color test.
- Assumes BLE hardware is available and discoverable.
"""

from ha_sphero_bb8.ble_gateway import BleGateway
import time
from spherov2.toy import Toy
from spherov2.types import Color

__all__: list[str] = []

gateway = BleGateway(mode="bleak")
toy = gateway.scan_for_device()
if toy is not None:
    from spherov2.sphero_edu import SpheroEduAPI
    from spherov2.toy import Toy
    if isinstance(toy, Toy):
        api = SpheroEduAPI(toy)
        for r, g, b in [(255, 0, 0), (0, 255, 0), (0, 0, 255)]:
            api.set_main_led(Color(r, g, b))
            api.roll(0, 50, 1.5)
            api.stop_roll()
            time.sleep(1)
            time.sleep(1)
    else:
        print("Connected device is not a valid Sphero Toy for SpheroEduAPI.")
else:
    print("Failed to connect to a valid BB-8 toy.")
