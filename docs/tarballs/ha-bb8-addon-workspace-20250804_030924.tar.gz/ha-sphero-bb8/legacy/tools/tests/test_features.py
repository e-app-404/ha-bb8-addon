# tests/test_features.py
"""
MODULE PURPOSE: Functional integration tests for Sphero BB-8 feature commands via the MQTT handler/controller abstraction.
STATUS: prototype
MAIN ENTRYPOINTS: test_move_command, test_stop_command, test_rotate_command, test_led_command, test_diagnostics_command
DEPENDENCIES: pytest, unittest.mock, ha_sphero_bb8.mqtt_handler, ha_sphero_bb8.controller
LAST VALIDATED: 2025-06-19
NOTES:
- Each test validates end-to-end logic from handler command dispatch to controller method invocation.
- Relies on MagicMock for controller to ensure isolation from hardware and side effects.
- Test coverage ensures at least one passing assertion per major feature (move, stop, rotate, led, diagnostics).
- Easily extendable for new commands or controller features.
- Designed for continuous integration and developer feedback loops.
"""

import sys
import os
# Find the absolute path to the _vendor directory
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '..', '..'))  # Adjust as needed
vendor_parent = os.path.join(project_root, '_vendor')
if vendor_parent not in sys.path:
    sys.path.insert(0, vendor_parent)

import pytest
from unittest.mock import MagicMock
from ha_sphero_bb8.mqtt_handler import create_mqtt_handler, create_default_config

@pytest.fixture
def controller():
    """Mock controller for feature tests."""
    mock_ctrl = MagicMock()
    # Populate expected methods for each feature
    mock_ctrl.roll = MagicMock()
    mock_ctrl.stop = MagicMock()
    mock_ctrl.rotate = MagicMock()
    mock_ctrl.set_led = MagicMock()
    mock_ctrl.diagnostics = MagicMock()
    return mock_ctrl

@pytest.fixture
def handler(controller):
    config = create_default_config()
    return create_mqtt_handler(MagicMock(), controller=controller, config=config)

def test_move_command(handler, controller):
    """Test: Move command calls controller.roll()."""
    payload = {"command": "move", "speed": 60, "heading": 45}
    handler._handle_command_message(payload)
    controller.roll.assert_called_once_with(speed=60, heading=45)

def test_stop_command(handler, controller):
    """Test: Stop command calls controller.stop()."""
    payload = {"command": "stop"}
    handler._handle_command_message(payload)
    controller.stop.assert_called_once()

def test_rotate_command(handler, controller):
    """Test: Rotate command calls controller.roll() with speed=0 and heading=angle."""
    payload = {"command": "rotate", "angle": 90}
    handler._handle_command_message(payload)
    controller.roll.assert_called_once_with(speed=0, heading=90)

def test_led_command(handler, controller):
    """Test: LED command calls controller.set_led() with RGB tuple for blue."""
    payload = {"command": "led", "color": "blue"}
    handler._handle_command_message(payload)
    controller.set_led.assert_called_once_with(0, 0, 255)

def test_diagnostics_command(handler, controller):
    """Test: Diagnostics command calls controller.get_diagnostics_for_mqtt()."""
    payload = {"command": "diagnostics"}
    handler._handle_command_message(payload)
    # Allow for multiple calls due to publish_status; just ensure at least one call
    assert controller.get_diagnostics_for_mqtt.call_count >= 1
