import pytest
import asyncio
from unittest.mock import patch, AsyncMock
from ha_sphero_bb8.device_core.adapters.bleak_adapter import BleakAdapter

@pytest.mark.asyncio
async def test_connect_failure_bleakclient_not_available():
    adapter = BleakAdapter()
    # Simulate BleakClient import failure
    adapter.client = None
    with patch('ha_sphero_bb8.device_core.adapters.bleak_adapter.BleakClient', None):
        result = await adapter.connect('00:11:22:33:44:55')
        assert result is False

@pytest.mark.asyncio
async def test_connect_failure_timeout():
    adapter = BleakAdapter()
    with patch('ha_sphero_bb8.device_core.adapters.bleak_adapter.BleakClient') as MockClient:
        mock_client = AsyncMock()
        mock_client.connect.side_effect = asyncio.TimeoutError()
        MockClient.return_value = mock_client
        result = await adapter.connect('00:11:22:33:44:55', timeout=0.1, max_retries=2)
        assert result is False
        assert mock_client.connect.call_count == 2

@pytest.mark.asyncio
async def test_connect_failure_bleakerror():
    adapter = BleakAdapter()
    with patch('ha_sphero_bb8.device_core.adapters.bleak_adapter.BleakClient') as MockClient:
        mock_client = AsyncMock()
        from bleak.exc import BleakError
        mock_client.connect.side_effect = BleakError('Mock BLE error')
        MockClient.return_value = mock_client
        result = await adapter.connect('00:11:22:33:44:55', max_retries=2)
        assert result is False
        assert mock_client.connect.call_count == 2

@pytest.mark.asyncio
async def test_disconnect_handles_exception():
    adapter = BleakAdapter()
    with patch('ha_sphero_bb8.device_core.adapters.bleak_adapter.BleakClient') as MockClient:
        mock_client = AsyncMock()
        mock_client.disconnect.side_effect = Exception('Mock disconnect error')
        adapter.client = mock_client
        await adapter.disconnect()  # Should not raise
        assert adapter.client is None
