# ha-sphero-bb8

## **Hardware-Only Operation**

As of August 2025, this project supports only real Sphero BB-8 hardware. All simulation, mock, and fallback logic has been removed for a more robust, maintainable, and production-ready codebase.

- **Simulation and adapter support is no longer available.**
- All CLI, diagnostics, and controller logic now require a real BB-8 device connected via BLE.
- If you attempt to use any simulation or fallback features, you will receive a clear error.

## Project Overview

This project provides a robust BLE/MQTT bridge and controller for Sphero BB-8 robots, with:

- Unified hardware-only controller and diagnostics
- Extensible device capability detection and reporting
- Home Assistant and MQTT integration
- Modern Python 3.13+ codebase

## Getting Started

1. Ensure you have a real Sphero BB-8 device and BLE support on your system.
2. Follow the setup instructions in `setup.py` or `README.md` (see below for details).
3. Use the CLI and MQTT integration as described—no simulation or dry-run modes are available.

## Why Hardware-Only?

Simulation and fallback logic were removed to:

- Improve reliability and maintainability
- Reduce confusion and technical debt
- Focus on real-world, production use cases

## Troubleshooting

- If your BB-8 is not detected, ensure it is powered on and nearby.
- Check your system's Bluetooth permissions and drivers.
- All errors and diagnostics now reflect real hardware status only.

## Contributing

- Please do not submit simulation, mock, or fallback code.
- Contributions should focus on hardware robustness, diagnostics, and extensibility.

---

For more details, see the in-code documentation and comments.
