# Home Assistant BB-8 Add-on Development Checklist

---

## Phase 1: Core Add-on Foundation

- [ ] Create `Dockerfile`, `config.yaml`, and `run.sh` for add-on scaffolding
- [ ] Refactor Python package for HA (remove CLI, use env/HA options for config)
- [ ] Audit codebase for CLI/config file dependencies before refactor
- [ ] Plan and document migration path for config loading (env/HA options)
- [ ] Implement MQTT handler (connect, subscribe, publish)
- [ ] Implement BLE control logic (connect to BB-8, basic commands)
- [ ] Test BLE connectivity inside the add-on container on target HA hardware as early as possible
- [ ] Document and configure add-on options for BLE: `host_dbus: true`, `privileged: [bluetooth]`, etc.
- [ ] Perform repeated BLE connect/disconnect/reconnect cycles in the add-on container to validate reliability
- [ ] Implement and expose a healthcheck endpoint or MQTT topic for BLE status
- [ ] Provide a diagnostic script or MQTT command to report BLE adapter status and troubleshooting info
- [ ] Route all logging to stdout (HA log panel)
- [ ] Implement structured logging with log levels (INFO, WARNING, ERROR, DEBUG) routed to stdout
- [ ] Document how to adjust log verbosity via add-on options or environment variables
- [ ] Ensure MQTT credentials are securely handled (never logged, always required for broker)
- [ ] Document BLE pairing process and any security implications
- [ ] Add a warning in docs about not exposing sensitive info in logs
- [ ] Deploy and test the add-on in a real Home Assistant environment (not just local Docker) before proceeding to Phase 2
- [ ] Write minimal documentation (`.HA_ADDON_README.md`)

**Milestone:** Add-on runs in HA, connects to BB-8, responds to MQTT commands

---

## Phase 2: HA Entity & Automation Integration

- [ ] Implement MQTT Discovery (BB-8 appears as device/entity in HA)
- [ ] Test MQTT Discovery and entity registration with HA’s MQTT integration early and iteratively
- [ ] Design and document a clear, extensible schema for BB-8 actions/events and their mapping to HA services/entities
- [ ] Map BB-8 actions to HA services (service call handlers)
- [ ] Publish BB-8 events to MQTT for HA automations
- [ ] Implement state synchronization: reflect BB-8 online/offline status in HA entities
- [ ] Implement error feedback: publish failed commands, BLE disconnects, and error states to HA (e.g., via MQTT attributes or sensors)
- [ ] Provide user feedback: expose BB-8 status, errors, and availability in the HA UI/logs
- [ ] Provide example HA automations (YAML snippets)
- [ ] Update documentation (usage, config, automation examples)

**Milestone:** BB-8 is visible in HA UI, controllable, and can trigger automations

---

## Phase 3: Advanced Features & Polish

- [ ] Add robust error handling and diagnostics (logs to HA)
- [ ] Polish UI/UX (friendly names, icons, device info)
- [ ] (Optional) Expose REST endpoints for advanced integrations
- [ ] Write full test suite (unit/integration tests)
- [ ] Include real hardware-in-the-loop tests for BLE/MQTT reliability
- [ ] Finalize release documentation (install, troubleshooting, changelog)
- [ ] Plan and document update/upgrade strategy for the add-on (including breaking changes)
- [ ] Plan and document configuration migration steps for future schema changes
- [ ] Establish a feedback loop: provide a way for users to report bugs, request features, and get support (e.g., GitHub issues, forums)

**Milestone:** Add-on is robust, user-friendly, and ready for public/production use
