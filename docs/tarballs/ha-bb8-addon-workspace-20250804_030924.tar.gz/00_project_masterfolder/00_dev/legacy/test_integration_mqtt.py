import sys
import os
vendor_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '_vendor')
if vendor_path not in sys.path:
    sys.path.insert(0, vendor_path)
# moved from tests/mocks/test_integration_mqtt.py
# ...existing code...
