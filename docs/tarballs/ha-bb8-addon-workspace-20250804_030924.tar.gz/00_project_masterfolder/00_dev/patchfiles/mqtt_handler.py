import json
import logging

logger = logging.getLogger(__name__)

def route_mqtt_command(message):
    """Route incoming MQTT command message to appropriate handler"""
    try:
        # Parse message payload as JSON
        if hasattr(message, 'payload'):
            payload_str = message.payload.decode('utf-8')
        else:
            payload_str = str(message)

        payload = json.loads(payload_str)

        # Extract command from payload
        command = payload.get('command')
        if not command:
            logger.warning(f"No command specified in payload: {payload}")
            return {"success": False, "error": "Missing command field"}

        logger.info(f"Received MQTT command: {command} with payload: {payload}")

        # Route to appropriate handler
        if command == "roll":
            return handle_roll_command(payload)
        elif command == "led":
            return handle_led_command(payload)
        elif command == "stop":
            return handle_stop_command(payload)
        elif command == "status":
            return handle_status_command(payload)
        elif command == "diagnostics":
            return handle_diagnostics_command(payload)
        else:
            logger.warning(f"Unknown command: {command}")
            return {"success": False, "error": f"Unknown command: {command}"}

    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse JSON payload: {e}")
        return {"success": False, "error": "Invalid JSON payload"}
    except Exception as e:
        logger.error(f"Error routing MQTT command: {e}")
        return {"success": False, "error": str(e)}

def handle_roll_command(payload):
    """Handle BB-8 roll command"""
    logger.info(f"[STUB] Roll command received: {payload}")

    # Extract parameters
    heading = payload.get('heading', 0)
    speed = payload.get('speed', 50)
    duration = payload.get('duration')

    # Validate parameters
    if not (0 <= heading <= 359):
        return {"success": False, "error": f"Invalid heading: {heading}"}
    if not (0 <= speed <= 255):
        return {"success": False, "error": f"Invalid speed: {speed}"}

    # Command routing stub
    return {
        "success": True,
        "command": "roll",
        "parameters": {"heading": heading, "speed": speed, "duration": duration},
        "message": f"[STUB] Would roll BB-8 at heading {heading} with speed {speed}"
    }

def handle_led_command(payload):
    """Handle BB-8 LED color command"""
    logger.info(f"[STUB] LED command received: {payload}")

    # Extract RGB values
    r = payload.get('r', 0)
    g = payload.get('g', 0)
    b = payload.get('b', 0)

    # Validate RGB values
    rgb_values = [r, g, b]
    if not all(0 <= val <= 255 for val in rgb_values):
        return {"success": False, "error": f"Invalid RGB values: ({r}, {g}, {b})"}

    # Command routing stub
    return {
        "success": True,
        "command": "led",
        "parameters": {"r": r, "g": g, "b": b},
        "message": f"[STUB] Would set BB-8 LED to RGB({r}, {g}, {b})"
    }

def handle_stop_command(payload):
    """Handle BB-8 stop command"""
    logger.info(f"[STUB] Stop command received: {payload}")

    # Command routing stub
    return {
        "success": True,
        "command": "stop",
        "parameters": {},
        "message": "[STUB] Would stop BB-8 movement"
    }

def handle_status_command(payload):
    """Handle BB-8 status request command"""
    logger.info(f"[STUB] Status command received: {payload}")

    # Command routing stub
    return {
        "success": True,
        "command": "status",
        "parameters": {},
        "message": "[STUB] Would return BB-8 status information"
    }

def handle_diagnostics_command(payload):
    """Handle BB-8 diagnostics request command"""
    logger.info(f"[STUB] Diagnostics command received: {payload}")

    # Command routing stub
    return {
        "success": True,
        "command": "diagnostics",
        "parameters": {},
        "message": "[STUB] Would return BB-8 diagnostic information"
    }
