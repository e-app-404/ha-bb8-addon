# src/ha_sphero_bb8/mqtt_handler.py
"""
MQTT Handler for BB-8 Device Control (ζ-tier)
Enhanced MQTT integration with proper client handling and type safety

Provides:
- Safe MQTT client initialization and management
- Command routing to BB8Controller interface
- Comprehensive error handling and logging
- Type-safe device command dispatching

HESTIA Compliance:
- Tier: ζ (services - external interface)
- Consumes: β-tier controller interface
- Exposes: MQTT commands for Home Assistant integration
- Abstracts: Device complexity behind MQTT protocol
"""

import json
import logging
import time
from typing import Optional, Dict, Any, Protocol, TYPE_CHECKING
from dataclasses import dataclass
from enum import Enum

# Safe MQTT imports with fallback
try:
    import paho.mqtt.client as mqtt
    from paho.mqtt.client import CallbackAPIVersion
    MQTT_AVAILABLE = True
except ImportError as e:
    mqtt = None
    CallbackAPIVersion = None
    MQTT_AVAILABLE = False
    logging.getLogger(__name__).warning(f"MQTT not available: {e}")

# Import controller and topics
from .controller import BB8Controller, ControllerMode
from .topics import MQTT_CONTROL_TOPIC, MQTT_DIAGNOSTIC_TOPIC

if TYPE_CHECKING:
    from .controller import BB8Like

logger = logging.getLogger(__name__)

class MQTTStatus(Enum):
    """MQTT connection status enumeration"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    FAILED = "failed"
    UNAVAILABLE = "unavailable"

@dataclass
class MQTTConfig:
    """MQTT connection configuration"""
    broker_host: str = "localhost"
    broker_port: int = 1883
    username: Optional[str] = None
    password: Optional[str] = None
    client_id: str = "bb8_controller"
    keep_alive: int = 60
    control_topic: str = MQTT_CONTROL_TOPIC
    diagnostic_topic: str = MQTT_DIAGNOSTIC_TOPIC

class BB8MQTTHandler:
    """
    BB-8 MQTT Command Handler

    Provides MQTT interface for BB-8 device control with proper
    client management and type safety.
    """

    def __init__(self,
                 config: Optional[MQTTConfig] = None,
                 controller: Optional[BB8Controller] = None):
        self.config = config or MQTTConfig()
        self.controller = controller
        self.client: Optional[mqtt.Client] = None
        self.status = MQTTStatus.UNAVAILABLE if not MQTT_AVAILABLE else MQTTStatus.DISCONNECTED
        self.logger = logging.getLogger(f"{__name__}.BB8MQTTHandler")

        # Message tracking
        self.messages_received = 0
        self.messages_processed = 0
        self.last_message_time: Optional[float] = None

        self._initialize_client()

    def _initialize_client(self) -> bool:
        """Initialize MQTT client with proper error handling"""
        if not MQTT_AVAILABLE:
            self.logger.error("MQTT library not available")
            return False

        try:
            # Create client with proper callback API version
            self.client = mqtt.Client(
                client_id=self.config.client_id,
                callback_api_version=CallbackAPIVersion.VERSION2
            )

            if self.client is None:
                self.logger.error("Failed to create MQTT client")
                return False

            # Set credentials if provided
            if self.config.username and self.config.password:
                self.client.username_pw_set(self.config.username, self.config.password)

            # Set callbacks
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client.on_message = self._on_message
            self.client.on_subscribe = self._on_subscribe
            self.client.on_publish = self._on_publish

            self.status = MQTTStatus.DISCONNECTED
            self.logger.info("MQTT client initialized successfully")
            return True

        except Exception as e:
            self.logger.error(f"Failed to initialize MQTT client: {e}")
            self.client = None
            self.status = MQTTStatus.FAILED
            return False

    def connect(self) -> bool:
        """Connect to MQTT broker"""
        if not self.client:
            self.logger.error("MQTT client not initialized")
            return False

        try:
            self.status = MQTTStatus.CONNECTING
            self.logger.info(f"Connecting to MQTT broker {self.config.broker_host}:{self.config.broker_port}")

            result = self.client.connect(
                self.config.broker_host,
                self.config.broker_port,
                self.config.keep_alive
            )

            if not MQTT_AVAILABLE or not hasattr(mqtt, 'MQTT_ERR_SUCCESS'):
                # Fallback for when MQTT constants aren't available
                success_code = 0
            else:
                success_code = mqtt.MQTT_ERR_SUCCESS

            if result == success_code:
                self.client.loop_start()
                self.logger.info("MQTT connection initiated")
                return True
            else:
                self.logger.error(f"MQTT connection failed with code: {result}")
                self.status = MQTTStatus.FAILED
                return False

        except Exception as e:
            self.logger.error(f"MQTT connection error: {e}")
            self.status = MQTTStatus.FAILED
            return False

    def disconnect(self):
        """Disconnect from MQTT broker"""
        if self.client:
            try:
                self.client.loop_stop()
                self.client.disconnect()
                self.status = MQTTStatus.DISCONNECTED
                self.logger.info("MQTT client disconnected")
            except Exception as e:
                self.logger.error(f"MQTT disconnect error: {e}")

    def _on_connect(self, client, userdata, flags, reason_code, properties=None):
        """Handle MQTT connection established"""
        if reason_code == 0:
            self.status = MQTTStatus.CONNECTED
            self.logger.info("MQTT connected successfully")

            # Subscribe to control topic
            if self.client:
                result = self.client.subscribe(self.config.control_topic)
                if result[0] == 0:
                    self.logger.info(f"Subscribed to {self.config.control_topic}")
                else:
                    self.logger.error(f"Failed to subscribe to {self.config.control_topic}")
        else:
            self.status = MQTTStatus.FAILED
            self.logger.error(f"MQTT connection failed with reason code: {reason_code}")

    def _on_disconnect(self, client, userdata, flags, reason_code, properties=None):
        """Handle MQTT disconnection"""
        self.status = MQTTStatus.DISCONNECTED
        self.logger.info(f"MQTT disconnected with reason code: {reason_code}")

    def _on_message(self, client, userdata, message):
        """Handle incoming MQTT message"""
        try:
            self.messages_received += 1
            self.last_message_time = time.time()

            topic = message.topic
            payload = message.payload.decode('utf-8')

            self.logger.info(f"Received message on topic '{topic}': {payload}")

            # Route message based on topic
            if topic == self.config.control_topic:
                result = self._handle_control_message(payload)
                self._publish_response(result)
            else:
                self.logger.warning(f"Unknown topic: {topic}")

        except Exception as e:
            self.logger.error(f"Error processing MQTT message: {e}")

    def _on_subscribe(self, client, userdata, mid, reason_code_list, properties=None):
        """Handle MQTT subscription confirmation"""
        self.logger.debug(f"Subscription confirmed with message ID: {mid}")

    def _on_publish(self, client, userdata, mid, reason_code=None, properties=None):
        """Handle MQTT publish confirmation"""
        self.logger.debug(f"Message published with ID: {mid}")

    def _handle_control_message(self, payload: str) -> Dict[str, Any]:
        """Handle control command message"""
        try:
            # Parse JSON payload
            command_data = json.loads(payload)
            command = command_data.get('command')

            if not command:
                return {
                    "success": False,
                    "error": "Missing command field",
                    "timestamp": time.time()
                }

            self.logger.info(f"Processing command: {command}")

            # Ensure we have a controller
            if not self.controller:
                return {
                    "success": False,
                    "error": "Controller not available",
                    "command": command,
                    "timestamp": time.time()
                }

            # Route to appropriate command handler
            result = self._dispatch_command(command, command_data)

            self.messages_processed += 1
            return result

        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON payload: {e}")
            return {
                "success": False,
                "error": "Invalid JSON payload",
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Command handling error: {e}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": time.time()
            }

    def _dispatch_command(self, command: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch command to appropriate controller method"""
        try:
            if command == "roll":
                return self._handle_roll_command(data)
            elif command == "led":
                return self._handle_led_command(data)
            elif command == "stop":
                return self._handle_stop_command(data)
            elif command == "status":
                return self._handle_status_command(data)
            elif command == "diagnostics":
                return self._handle_diagnostics_command(data)
            else:
                return {
                    "success": False,
                    "error": f"Unknown command: {command}",
                    "command": command,
                    "timestamp": time.time()
                }

        except Exception as e:
            self.logger.error(f"Command dispatch error: {e}")
            return {
                "success": False,
                "error": str(e),
                "command": command,
                "timestamp": time.time()
            }

    def _handle_roll_command(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle BB-8 roll command via controller"""
        try:
            speed = int(data.get("speed", 50))
            heading = int(data.get("heading", 0))
            timeout = data.get("timeout")
            boost = bool(data.get("boost", False))

            # Validate parameters
            if not (0 <= speed <= 255):
                return {
                    "success": False,
                    "error": f"Invalid speed: {speed} (must be 0-255)",
                    "command": "roll"
                }

            if not (0 <= heading <= 359):
                return {
                    "success": False,
                    "error": f"Invalid heading: {heading} (must be 0-359)",
                    "command": "roll"
                }

            # Execute via controller
            if self.controller and hasattr(self.controller, 'roll'):
                result = self.controller.roll(speed, heading, timeout=timeout, boost=boost)
                return {
                    "success": result.get("success", True),
                    "command": "roll",
                    "parameters": {"speed": speed, "heading": heading, "timeout": timeout, "boost": boost},
                    "result": result,
                    "timestamp": time.time()
                }
            else:
                return {
                    "success": False,
                    "error": "Roll command not available on controller",
                    "command": "roll"
                }

        except (ValueError, TypeError) as e:
            return {
                "success": False,
                "error": f"Parameter error: {e}",
                "command": "roll"
            }

    def _handle_led_command(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle BB-8 LED command via controller"""
        try:
            r = int(data.get("r", 0))
            g = int(data.get("g", 0))
            b = int(data.get("b", 0))

            # Validate RGB values
            for color, value in [("red", r), ("green", g), ("blue", b)]:
                if not (0 <= value <= 255):
                    return {
                        "success": False,
                        "error": f"Invalid {color} value: {value} (must be 0-255)",
                        "command": "led"
                    }

            # Execute via controller
            if self.controller and hasattr(self.controller, 'set_led'):
                result = self.controller.set_led(r, g, b)
                return {
                    "success": result.get("success", True),
                    "command": "led",
                    "parameters": {"r": r, "g": g, "b": b},
                    "result": result,
                    "timestamp": time.time()
                }
            else:
                return {
                    "success": False,
                    "error": "LED command not available on controller",
                    "command": "led"
                }

        except (ValueError, TypeError) as e:
            return {
                "success": False,
                "error": f"Parameter error: {e}",
                "command": "led"
            }

    def _handle_stop_command(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle BB-8 stop command via controller"""
        try:
            if self.controller and hasattr(self.controller, 'stop'):
                result = self.controller.stop()
                return {
                    "success": result.get("success", True),
                    "command": "stop",
                    "result": result,
                    "timestamp": time.time()
                }
            else:
                return {
                    "success": False,
                    "error": "Stop command not available on controller",
                    "command": "stop"
                }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "command": "stop"
            }

    def _handle_status_command(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle BB-8 status request via controller"""
        try:
            if self.controller and hasattr(self.controller, 'get_controller_status'):
                status = self.controller.get_controller_status()
                return {
                    "success": True,
                    "command": "status",
                    "status": {
                        "mode": status.mode.value,
                        "connected": status.device_connected,
                        "ble_status": status.ble_status,
                        "uptime": status.uptime,
                        "commands": status.command_count,
                        "errors": status.error_count,
                        "last_command": status.last_command
                    },
                    "timestamp": time.time()
                }
            else:
                return {
                    "success": False,
                    "error": "Status command not available on controller",
                    "command": "status"
                }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "command": "status"
            }

    def _handle_diagnostics_command(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle BB-8 diagnostics request via controller"""
        try:
            if self.controller and hasattr(self.controller, 'get_diagnostics_for_mqtt'):
                diagnostics = self.controller.get_diagnostics_for_mqtt()
                return {
                    "success": True,
                    "command": "diagnostics",
                    "diagnostics": diagnostics,
                    "timestamp": time.time()
                }
            else:
                return {
                    "success": False,
                    "error": "Diagnostics command not available on controller",
                    "command": "diagnostics"
                }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "command": "diagnostics"
            }

    def _publish_response(self, response: Dict[str, Any]):
        """Publish command response to diagnostic topic"""
        if not self.client:
            self.logger.error("Cannot publish: MQTT client not available")
            return

        try:
            payload = json.dumps(response)

            if not MQTT_AVAILABLE or not hasattr(mqtt, 'MQTT_ERR_SUCCESS'):
                # Fallback for when MQTT constants aren't available
                success_code = 0
            else:
                success_code = mqtt.MQTT_ERR_SUCCESS

            result = self.client.publish(self.config.diagnostic_topic, payload)

            if result.rc == success_code:
                self.logger.debug(f"Response published to {self.config.diagnostic_topic}")
            else:
                self.logger.error(f"Failed to publish response: {result.rc}")

        except Exception as e:
            self.logger.error(f"Publish error: {e}")

    def get_status(self) -> Dict[str, Any]:
        """Get MQTT handler status"""
        return {
            "mqtt_status": self.status.value,
            "mqtt_available": MQTT_AVAILABLE,
            "client_connected": self.client is not None and self.status == MQTTStatus.CONNECTED,
            "messages_received": self.messages_received,
            "messages_processed": self.messages_processed,
            "last_message_time": self.last_message_time,
            "config": {
                "broker": f"{self.config.broker_host}:{self.config.broker_port}",
                "control_topic": self.config.control_topic,
                "diagnostic_topic": self.config.diagnostic_topic
            }
        }

# Legacy compatibility functions
def route_mqtt_command(message) -> Dict[str, Any]:
    """Legacy function for backward compatibility"""
    logger.warning("Using deprecated route_mqtt_command - use BB8MQTTHandler instead")

    try:
        # Parse message payload as JSON
        if hasattr(message, 'payload'):
            payload_str = message.payload.decode('utf-8')
        else:
            payload_str = str(message)

        payload = json.loads(payload_str)
        command = payload.get('command')

        if not command:
            return {"success": False, "error": "Missing command field"}

        # Create temporary handler for legacy support
        handler = BB8MQTTHandler()
        return handler._handle_control_message(payload_str)

    except json.JSONDecodeError as e:
        return {"success": False, "error": "Invalid JSON payload"}
    except Exception as e:
        return {"success": False, "error": str(e)}

# Legacy command handlers for backward compatibility
def handle_roll_command(payload):
    """Legacy roll command handler"""
    logger.warning("Using deprecated handle_roll_command")
    return _legacy_command_stub("roll", payload)

def handle_led_command(payload):
    """Legacy LED command handler"""
    logger.warning("Using deprecated handle_led_command")
    return _legacy_command_stub("led", payload)

def handle_stop_command(payload):
    """Legacy stop command handler"""
    logger.warning("Using deprecated handle_stop_command")
    return _legacy_command_stub("stop", payload)

def handle_status_command(payload):
    """Legacy status command handler"""
    logger.warning("Using deprecated handle_status_command")
    return _legacy_command_stub("status", payload)

def handle_diagnostics_command(payload):
    """Legacy diagnostics command handler"""
    logger.warning("Using deprecated handle_diagnostics_command")
    return _legacy_command_stub("diagnostics", payload)

def _legacy_command_stub(command: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Legacy command stub for backward compatibility"""
    return {
        "success": True,
        "command": command,
        "message": f"[LEGACY STUB] Command {command} received",
        "payload": payload,
        "timestamp": time.time()
    }
