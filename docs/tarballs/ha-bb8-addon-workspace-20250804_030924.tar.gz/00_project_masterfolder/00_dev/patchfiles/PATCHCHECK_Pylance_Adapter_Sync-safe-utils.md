### 📂 patch_manifest.yaml
patch_manifest:
  files_modified:
    - src/ha_sphero_bb8/controller.py
    - src/ha_sphero_bb8/ble_gateway.py
    - src/ha_sphero_bb8/bb8_control.py
    - src/ha_sphero_bb8/mqtt_handler.py
    - src/ha_sphero_bb8/launch_bb8.py
    - src/ha_sphero_bb8/controller/safe_utils.py

### 📉 Diff Logs

# FILE: src/ha_sphero_bb8/controller/safe_utils.py
```python
from typing import Any

def safe_ping(device: Any) -> bool:
    try:
        return device.ping()
    except TypeError:
        try:
            return device.ping(toy=device)
        except Exception:
            return False

def safe_set_main_led(device: Any, r: int, g: int, b: int) -> bool:
    try:
        device.set_main_led(r, g, b)
        return True
    except Exception:
        return False

def safe_get_voltage(device: Any) -> float:
    return getattr(device, "get_battery_voltage", lambda: 0.0)()

def safe_get_percentage(device: Any) -> int:
    return getattr(device, "get_battery_percentage", lambda: -1)()
```

# FILE: src/ha_sphero_bb8/controller.py
```python
# ADDITIONAL EXPORTS
__all__ = [
    "handle_roll_command",
    "handle_stop_command",
    "handle_led_command",
    "handle_status_command",
    "handle_diagnostics_command",
]
```

# FIX: Ensure all LED calls use 3 args
# FIX: Import safe utils where used and replace direct device.ping, set_main_led etc.
