def get_ble_adapter(mode: str = None):
    import time
    import logging

    logger = logging.getLogger(__name__)
    mode = mode or os.environ.get("SPHERO_ADAPTER", "bleak")

    if mode == "sim":
        logger.info("Using simulated BB-8 adapter")
        return SimulatedDevice()

    # Real BLE adapter with error handling and retries
    max_retries = 3
    retry_delay = 2.0

    for attempt in range(max_retries):
        try:
            logger.info(f"Attempting BLE connection (attempt {attempt + 1}/{max_retries})")

            # Check if BLE is available
            if not SPHEROV2_AVAILABLE:
                raise RuntimeError("spherov2 library not available")

            if not BLEAK_AVAILABLE:
                raise RuntimeError("bleak library not available for BLE")

            # Scan for BB-8 with timeout
            scanner_timeout = 10
            logger.debug(f"Scanning for BB-8 devices (timeout: {scanner_timeout}s)")

            bb8_toy = find_BB8(timeout=scanner_timeout)

            if bb8_toy:
                logger.info(f"BB-8 device found: {bb8_toy}")
                return bb8_toy
            else:
                raise TimeoutError("No BB-8 devices found during scan")

        except Exception as e:
            logger.warning(f"BLE adapter attempt {attempt + 1} failed: {e}")

            if attempt < max_retries - 1:
                logger.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logger.error("All BLE adapter attempts failed")
                raise RuntimeError(f"Failed to initialize BLE adapter after {max_retries} attempts: {e}")

    return None
