def initialize_bb8(adapter_mode: str = None):
    import logging
    import time

    logger = logging.getLogger(__name__)

    try:
        logger.info("Initializing BB-8 device...")

        # Get BLE adapter with error handling
        device = get_ble_adapter(mode=adapter_mode)

        if device is None:
            raise RuntimeError("Failed to obtain BLE adapter")

        # Attempt to wake/ping device if supported
        if hasattr(device, 'wake'):
            logger.debug("Waking BB-8 device...")
            device.wake()
            time.sleep(0.5)  # Allow wake command to process

        if hasattr(device, 'ping'):
            logger.debug("Pinging BB-8 device for connectivity check...")
            ping_response = device.ping()
            if not ping_response:
                logger.warning("Ping response was empty or failed")

        # Confirm connection status if available
        if hasattr(device, 'is_connected'):
            if not device.is_connected():
                raise ConnectionError("Device reports as not connected")
            logger.info("BB-8 connection confirmed")

        # Test basic functionality with a safe command
        if hasattr(device, 'set_main_led'):
            logger.debug("Testing LED connectivity...")
            try:
                # Brief LED test - set to dim blue and turn off
                device.set_main_led(0, 0, 50)
                time.sleep(0.2)
                device.set_main_led(0, 0, 0)
                logger.debug("LED test successful")
            except Exception as led_error:
                logger.warning(f"LED test failed: {led_error}")

        logger.info("BB-8 initialization complete")

        # Future motion commands will be implemented here:
        # - device.roll(speed, heading, duration) for movement
        # - device.stop() for emergency stop
        # - device.set_raw_motors(left, right) for precise control

        # Future LED commands will be implemented here:
        # - device.set_main_led(r, g, b) for color control
        # - device.set_back_led(brightness) for tail light

        return device

    except Exception as e:
        logger.error(f"BB-8 initialization failed: {e}")
        raise RuntimeError(f"Cannot initialize BB-8: {e}")
