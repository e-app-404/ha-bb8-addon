#!/usr/bin/env python3
"""
MQTT Runtime Orchestration for ha-sphero-bb8
ζ-tier service orchestration module

Provides:
- MQTT broker connection and subscription management
- Command routing from MQTT to BB-8 device controller
- Device initialization and lifecycle management
- CLI interface for adapter mode selection

HESTIA Compliance:
- Tier: ζ (services - MQTT orchestration)
- Consumes: β-tier controller, MQTT infrastructure
- Exposes: MQTT service interface for Home Assistant
"""

import argparse
import logging
import signal
import sys
import time
import json
from typing import Optional, Dict, Any

from ha_sphero_bb8.controller import BB8Like
from ha_sphero_bb8.ble_gateway import BleGateway
from ha_sphero_bb8 import mqtt_handler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import project modules
from .topics import MQTT_CONTROL_TOPIC
from .bb8_control import initialize_bb8

# Global state for clean shutdown
mqtt_client = None
bb8_device = None
shutdown_requested = False

class MQTTAdapter:
    """MQTT adapter for BB-8 command routing and orchestration"""

    def __init__(self, broker_host="localhost", broker_port=1883):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.client = None
        self.connected = False
        self.device = None
        self.message_count = 0

    def connect(self, device):
        """Connect to MQTT broker and store device reference"""
        try:
            import paho.mqtt.client as mqtt

            self.device = device
            self.client = mqtt.Client()

            # Set up callbacks
            self.client.on_connect = self._on_connect
            self.client.on_message = self._on_message
            self.client.on_disconnect = self._on_disconnect
            self.client.on_log = self._on_log

            logger.info(f"Connecting to MQTT broker at {self.broker_host}:{self.broker_port}")
            self.client.connect(self.broker_host, self.broker_port, 60)

            return True

        except ImportError:
            logger.error("paho-mqtt library not available. Install with: pip install paho-mqtt")
            return False
        except Exception as e:
            logger.error(f"MQTT connection failed: {e}")
            return False

    def _on_connect(self, client, userdata, flags, rc):
        """Callback for successful MQTT connection"""
        if rc == 0:
            self.connected = True
            logger.info("✅ Connected to MQTT broker")

            # Subscribe to control topic
            result = client.subscribe(MQTT_CONTROL_TOPIC)
            if result[0] == 0:
                logger.info(f"📡 Subscribed to topic: {MQTT_CONTROL_TOPIC}")
            else:
                logger.error(f"Failed to subscribe to topic: {MQTT_CONTROL_TOPIC}")
        else:
            error_messages = {
                1: "Incorrect protocol version",
                2: "Invalid client identifier",
                3: "Server unavailable",
                4: "Bad username or password",
                5: "Not authorized"
            }
            error_msg = error_messages.get(rc, f"Unknown error code {rc}")
            logger.error(f"MQTT connection failed: {error_msg}")

    def _on_message(self, client, userdata, msg):
        """Handle incoming MQTT messages"""
        try:
            self.message_count += 1
            topic = msg.topic
            payload = msg.payload.decode('utf-8')

            logger.info(f"📨 Message #{self.message_count} received on '{topic}': {payload}")

            # Route command to handler with device parameter
            result = route_mqtt_command(msg, self.device)

            # Log the result with detailed status
            if result.get("success"):
                command = result.get("command", "unknown")
                message = result.get("message", "")
                logger.info(f"✅ Command '{command}' executed successfully: {message}")

                # Log additional result details if present
                if "parameters" in result:
                    logger.debug(f"Parameters: {result['parameters']}")
            else:
                error = result.get("error", "Unknown error")
                command = result.get("command", "unknown")
                logger.error(f"❌ Command '{command}' failed: {error}")

        except Exception as e:
            logger.error(f"💥 Error processing MQTT message: {e}")
            import traceback
            logger.debug(traceback.format_exc())

    def _on_disconnect(self, client, userdata, rc):
        """Callback for MQTT disconnection"""
        self.connected = False
        if rc != 0:
            logger.warning(f"⚠️  Unexpected MQTT disconnection (code: {rc})")
        else:
            logger.info("📡 MQTT client disconnected cleanly")

    def _on_log(self, client, userdata, level, buf):
        """MQTT client logging callback"""
        # Only log important MQTT events in debug mode
        if level <= 16:  # MQTT_LOG_ERROR and above
            logger.debug(f"MQTT: {buf}")

    def loop_forever(self):
        """Start the blocking MQTT loop"""
        if self.client:
            logger.info("🔄 Starting MQTT message loop...")
            try:
                self.client.loop_forever()
            except KeyboardInterrupt:
                logger.info("🛑 MQTT loop interrupted")
            except Exception as e:
                logger.error(f"💥 MQTT loop error: {e}")
                raise

    def disconnect(self):
        """Disconnect from MQTT broker"""
        if self.client and self.connected:
            logger.info("📡 Disconnecting from MQTT broker...")
            self.client.disconnect()
            self.client.loop_stop()

class SimulatedDevice:
    """Simulated BB-8 device for testing"""

    def __init__(self):
        self.connected = True
        logger.info("🤖 Using simulated BB-8 device")

    def roll(self, speed, heading, **kwargs):
        logger.info(f"[SIM] Rolling at speed {speed}, heading {heading}")
        return {"success": True}

    def set_main_led(self, r, g, b):
        logger.info(f"[SIM] Setting LED to RGB({r}, {g}, {b})")
        return {"success": True}

    def stop(self):
        logger.info("[SIM] Stopping movement")
        return {"success": True}

    def disconnect(self):
        logger.info("[SIM] Disconnecting simulated device")
        self.connected = False

def signal_handler(signum, frame):
    """Handle shutdown signals gracefully"""
    global shutdown_requested
    logger.info(f"🔄 Received signal {signum}, initiating graceful shutdown...")
    shutdown_requested = True

def create_argument_parser():
    """Create comprehensive CLI argument parser"""
    parser = argparse.ArgumentParser(
        description="MQTT Runtime Orchestration for Sphero BB-8",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --adapter bleak
  %(prog)s --adapter sim --broker localhost
  %(prog)s --verbose --broker 192.168.1.100 --port 1883
  %(prog)s --adapter sim --broker test.mosquitto.org --port 1883
        """
    )

    parser.add_argument(
        "--adapter",
        choices=["bleak", "sim"],
        default="bleak",
        help="BLE adapter mode (default: bleak)"
    )

    parser.add_argument(
        "--broker",
        default="localhost",
        help="MQTT broker hostname (default: localhost)"
    )

    parser.add_argument(
        "--port",
        type=int,
        default=1883,
        help="MQTT broker port (default: 1883)"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run in simulation mode regardless of adapter setting"
    )

    return parser

def setup_logging(verbose: bool = False):
    """Configure logging based on verbosity level"""
    root_logger = logging.getLogger()

    if verbose:
        root_logger.setLevel(logging.DEBUG)
        logging.getLogger('ha_sphero_bb8').setLevel(logging.DEBUG)
        logger.info("🔍 Verbose logging enabled")
    else:
        root_logger.setLevel(logging.INFO)
        # Reduce noise from external libraries
        logging.getLogger('paho').setLevel(logging.WARNING)
        logging.getLogger('bleak').setLevel(logging.WARNING)

def initialize_device(adapter_mode: str, dry_run: bool = False):
    """Initialize BB-8 device based on adapter mode"""
    if dry_run or adapter_mode == "sim":
        logger.info("🤖 Initializing simulated BB-8 device...")
        return SimulatedDevice()

    try:
        logger.info(f"🔌 Initializing BB-8 device with adapter: {adapter_mode}")
        device = initialize_bb8(adapter_mode=adapter_mode)

        if device is None:
            logger.warning("⚠️  Real device initialization failed, falling back to simulation")
            return SimulatedDevice()

        logger.info("✅ BB-8 device initialized successfully")
        return device

    except Exception as e:
        logger.error(f"❌ Device initialization failed: {e}")
        logger.info("🤖 Falling back to simulated device")
        return SimulatedDevice()

def main():
    """Main MQTT orchestration entry point"""
    global mqtt_client, bb8_device

    # Parse command line arguments
    parser = create_argument_parser()
    args = parser.parse_args()

    # Setup logging
    setup_logging(args.verbose)

    # Setup signal handlers for clean shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    logger.info("🚀 Starting MQTT Runtime Orchestration for BB-8...")
    logger.info(f"🔧 Adapter mode: {args.adapter}")
    logger.info(f"📡 MQTT broker: {args.broker}:{args.port}")

    if args.dry_run:
        logger.info("🧪 Dry-run mode enabled")

    exit_code = 0

    try:
        # Device initialization block
        gateway = BleGateway(args.adapter)
        device = gateway.scan_for_device()
        if not device:
            sys.exit("No BB-8 found")
        assert isinstance(device, BB8Like)

        # Create and connect MQTT adapter
        mqtt_client = MQTTAdapter(args.broker, args.port)

        if not mqtt_client.connect(device):
            raise RuntimeError("Failed to connect to MQTT broker")

        # Wait for connection to be established
        connection_timeout = 10
        wait_time = 0
        while not mqtt_client.connected and wait_time < connection_timeout:
            time.sleep(0.1)
            wait_time += 0.1

        if not mqtt_client.connected:
            raise RuntimeError(f"MQTT connection timeout after {connection_timeout}s")

        # MQTT client setup
        import paho.mqtt.client as mqtt
        client = mqtt.Client()

        # Topic subscription rewrite
        client.message_callback_add("bb8/roll", lambda c, u, msg: mqtt_handler.on_message_roll(json.loads(msg.payload), device))
        client.message_callback_add("bb8/stop", lambda c, u, msg: mqtt_handler.on_message_stop(json.loads(msg.payload), device))
        # ...add other topic subscriptions as needed...

        # Start the main MQTT loop
        logger.info("🎯 MQTT orchestration ready - waiting for commands...")
        logger.info(f"👂 Listening on topic: {MQTT_CONTROL_TOPIC}")
        logger.info("⌨️  Press Ctrl+C to shutdown")

        # Print helpful usage information
        logger.info("📋 Send commands to MQTT topic with JSON payload:")
        logger.info(f"   Topic: {MQTT_CONTROL_TOPIC}")
        logger.info('   Example: {"command": "roll", "speed": 100, "heading": 90}')

        # Blocking loop - will run until interrupted or error
        mqtt_client.loop_forever()

    except KeyboardInterrupt:
        logger.info("🛑 Shutdown requested by user")
        exit_code = 0

    except Exception as e:
        logger.error(f"💥 MQTT orchestration error: {e}")
        exit_code = 1

        if args.verbose:
            import traceback
            logger.debug("Full error traceback:")
            logger.debug(traceback.format_exc())

    finally:
        # Cleanup resources
        logger.info("🧹 Cleaning up resources...")

        if mqtt_client:
            try:
                mqtt_client.disconnect()
                logger.info("📡 MQTT client disconnected")
            except Exception as e:
                logger.warning(f"⚠️  Error disconnecting MQTT: {e}")

        if bb8_device and hasattr(bb8_device, 'disconnect'):
            try:
                bb8_device.disconnect()
                logger.info("🔌 BB-8 device disconnected")
            except Exception as e:
                logger.warning(f"⚠️  Error disconnecting BB-8: {e}")

    logger.info(f"🏁 MQTT Runtime Orchestration exiting with code: {exit_code}")
    return exit_code

if __name__ == "__main__":
    sys.exit(main())
