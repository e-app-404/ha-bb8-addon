# Copilot Prompt: Implement Sphero BB-8 BLE Main LED Control in BleakAdapter

Context:

- The BB8Adapter.set_led and BleakAdapter.set_main_led methods are wired and log their parameters.
- set_main_led is currently a stub; it must actually send a BLE packet to BB-8 to change the main LED color.
- Use the Bleak BLE library (already present in the project).

Instructions:

1. **Implement set_main_led in BleakAdapter to control BB-8’s LED.**
2. The method signature is:

```python
   def set_main_led(self, r: int, g: int, b: int) -> bool:
```

 3. The method should:
 • Connect to the BB-8 device (if not already connected).
 • Write the correct GATT characteristic with the LED color (r, g, b).
 • Return True on success, log and return False on failure.

Reference:
 • The Sphero BB-8 main LED is controlled via a specific BLE characteristic.
 • The characteristic UUID for BB-8’s LED is often reported in open source projects as:

`22bb746f-2bb0-7554-2d6f-726568705327`

 • The packet structure for setting the LED may be more involved (command ID, flags, checksum, etc.), but for many community projects, writing an RGB byte sequence works for simple effects.

Pseudo-implementation (you must check your BB-8 protocol docs!):

```python
LED_CHAR_UUID = "22bb746f-2bb0-7554-2d6f-726568705327"

def set_main_led(self, r: int, g: int, b: int) -> bool:
    try:
        packet = bytearray([r, g, b])
        self._ble_device.write_gatt_char(LED_CHAR_UUID, packet)
        self.logger.info(f"Sent LED packet to BB-8: {packet}")
        return True
    except Exception as e:
        self.logger.error(f"Failed to set BB-8 LED: {e}")
        return False
```

 4. If your BB-8 library or underlying device already exposes a `set_led` or `set_main_led`, call that directly.
 5. Log all actions for audit.

Task:

Replace the stub in `BleakAdapter.set_main_led` with a real BLE write as above. Adjust the packet and UUID as needed for BB-8. Log the result.

If you need to discover or confirm the correct characteristic UUID or packet format, check community repos, the Sphero developer docs, or experiment using a BLE scanner and the original Sphero app.

### **2. Retrieve the file that contains UUID/Protocol information**

Search the vendor source code for references to **any of the following**:

- A `constants.py` or similar file mentioning “LED”, “CHARACTERISTIC”, or “UUID”.
- Any `ble_*`, `sphero_*`, or `protocol` modules.
- Documentation, markdowns, or source with BLE protocol comments.

If you **want me to check** your tarballs for this information, just confirm which file to search or let me know to perform a scan.

**Summary:**

- Use the above prompt for Copilot to wire the “real” LED BLE command.
- If you want me to **dig for UUID/packet details in your codebase or tarballs, just say the word.**

Would you like me to search your codebase for BB-8 BLE UUIDs and LED packet formats before you run Copilot?
