### 📂 patch_manifest.yaml
patch_manifest:
  files_modified:
    - src/ha_sphero_bb8/controller.py
    - src/ha_sphero_bb8/ble_gateway.py
    - src/ha_sphero_bb8/bb8_control.py
    - src/ha_sphero_bb8/mqtt_handler.py
    - src/ha_sphero_bb8/launch_bb8.py

### 📉 Diff Logs

# FILE: src/ha_sphero_bb8/controller.py
```python
# ... [existing controller.py content, already verified]
```

# FILE: src/ha_sphero_bb8/launch_bb8.py
```python
import argparse
from ha_sphero_bb8.bb8_control import initialize_bb8
from ha_sphero_bb8.controller import (
    handle_roll_command,
    handle_stop_command,
    handle_led_command,
    handle_status_command,
    handle_diagnostics_command,
)

def cli_roll(args):
    payload = {"heading": args.heading, "speed": args.speed}
    device = initialize_bb8()
    result = handle_roll_command(payload, device)
    print(result)

def cli_led(args):
    payload = {"mode": args.mode}
    device = initialize_bb8()
    result = handle_led_command(payload, device)
    print(result)

def cli_stop(args):
    device = initialize_bb8()
    result = handle_stop_command(device)
    print(result)

def cli_status(args):
    device = initialize_bb8()
    result = handle_status_command(device)
    print(result)

def cli_diag(args):
    device = initialize_bb8()
    result = handle_diagnostics_command(device)
    print(result)

def main():
    parser = argparse.ArgumentParser(description="BB-8 CLI Controller")
    subparsers = parser.add_subparsers(dest="command")

    roll = subparsers.add_parser("roll")
    roll.add_argument("--heading", type=int, default=0)
    roll.add_argument("--speed", type=int, default=50)
    roll.set_defaults(func=cli_roll)

    led = subparsers.add_parser("led")
    led.add_argument("--mode", type=str, choices=["charging", "blink", "error"], default="error")
    led.set_defaults(func=cli_led)

    subparsers.add_parser("stop").set_defaults(func=cli_stop)
    subparsers.add_parser("status").set_defaults(func=cli_status)
    subparsers.add_parser("diagnostics").set_defaults(func=cli_diag)

    args = parser.parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
```
