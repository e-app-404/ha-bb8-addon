#PATCHCHECK:CONTROLLER_REWRITE_DISPATCHER

from typing import Protocol

# --- BB8Like Protocol ---

class BB8Like(Protocol):
    def roll(self, heading: int, speed: int) -> None: ...
    def stop(self) -> None: ...
    def set_main_led(self, r: int, g: int, b: int) -> None: ...

# --- Command Handlers ---

def handle_roll_command(payload: dict, device: BB8Like) -> None:
    heading = int(payload.get("heading", 0))
    speed = int(payload.get("speed", 50))
    device.roll(heading, speed)

def handle_stop_command(payload: dict, device: BB8Like) -> None:
    device.stop()

def handle_led_command(payload: dict, device: BB8Like) -> None:
    r = payload.get("r", 255)
    g = payload.get("g", 255)
    b = payload.get("b", 255)
    device.set_main_led(r, g, b)

def handle_battery_command(payload: dict, device: BB8Like) -> dict:
    from spherov2.commands.power import Power
    voltage = Power.get_battery_voltage(device)
    percent = Power.get_battery_percentage(device)
    return {"voltage": voltage, "percent": percent}
