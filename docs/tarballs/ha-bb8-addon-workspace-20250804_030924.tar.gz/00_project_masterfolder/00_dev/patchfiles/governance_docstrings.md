### **`mqtt_handler.py`**

```python
"""
MODULE PURPOSE: Main MQTT event handler for Sphero BB-8. Manages broker connection, topic subscription,
and dispatching inbound MQTT messages to command handlers (real and simulation).
STATUS: production
MAIN ENTRYPOINTS: MQTTHandler class, on_connect, on_message, on_disconnect, publish, subscribe
DEPENDENCIES: Used by run_mqtt.py (as main event loop). Imports controller.py, constants.py.
LAST VALIDATED: 2025-06-18
NOTES:
- Every command handler should use try/except for robust error logging.
- Command dispatcher must be updated if new bb8/command/* topics are added.
- Simulation mode supported via injected adapter.
"""
```

---

### **`controller.py`**

```python
"""
MODULE PURPOSE: Main BB-8 controller. Implements device command logic for movement, rotation, diagnostics,
and LED control. All MQTT commands are ultimately routed here via handlers.
STATUS: production
MAIN ENTRYPOINTS: BB8Controller class, handle_command, move_forward, rotate, stop, get_diagnostics
DEPENDENCIES: Called by mqtt_handler.py. Uses device_core/adapter(s), supports dependency injection for simulation.
LAST VALIDATED: 2025-06-18
NOTES:
- Methods should wrap hardware/sim interactions with result wrappers and log failures.
- Update dependency injection paths when simulation/hardware adapters change.
"""
```

---

### **`simulation_adapter.py`**

```python
"""
MODULE PURPOSE: Simulation-only BLEAdapter replacement for development/testing.
Provides a full mock BLE interface, logging all commands, and emulates device responses.
STATUS: simulation (sole supported simulation adapter—retain and refactor as needed)
MAIN ENTRYPOINTS: SimulationBLEAdapter class (must emulate all methods of BLEAdapter)
DEPENDENCIES: Used by controller.py for simulation runs. Should be injected via adapter selection.
LAST VALIDATED: 2025-06-18
NOTES:
- All simulation code should route through this adapter—no additional mocks.
- Add toggles for verbosity/logging as needed for future test coverage.
"""
```

---

### **`constants.py`**

```python
"""
MODULE PURPOSE: Single source for all MQTT topics, adapter mode names, broker config, and shared project constants.
STATUS: production
MAIN ENTRYPOINTS: MQTT_COMMAND_TOPIC, MQTT_STATUS_TOPIC, MQTT_BROKER_HOST, ADAPTER_MODES, etc.
DEPENDENCIES: Imported by all handler, controller, and CLI modules.
LAST VALIDATED: 2025-06-18
NOTES:
- Update topic strings and config here ONLY. No hard-coded values elsewhere.
"""
```

---

### **`run_mqtt.py`**

```python
"""
MODULE PURPOSE: Canonical CLI entrypoint for running the Sphero BB-8 MQTT event loop.
Handles command-line arguments, initializes the appropriate adapter (real/sim),
and starts the main MQTTHandler loop.
STATUS: production
MAIN ENTRYPOINTS: main() function, CLI argument parsing, MQTTHandler instantiation
DEPENDENCIES: Imports mqtt_handler.py, constants.py
LAST VALIDATED: 2025-06-18
NOTES:
- All CLI launches should occur from project root:
    python -m ha_sphero_bb8.run_mqtt --adapter [real|sim]
- Extend here to add new CLI options (e.g., diagnostics, verbosity)
"""
```

---

### **`device_core/voltage_diagnostics.py`** *(example utility module)*

```python
"""
MODULE PURPOSE: Provides voltage and battery diagnostics for BB-8.
STATUS: production
MAIN ENTRYPOINTS: get_voltage, get_battery_level
DEPENDENCIES: Imported by controller.py for diagnostics
LAST VALIDATED: 2025-06-18
NOTES:
- All diagnostics returned as structured result objects.
"""
```

---

### **Deprecated/To-be-Purged Files (e.g., `mock_adapter.py`, `integration_stub.py`)**

```python
"""
MODULE PURPOSE: [Describe if any unique stub function, else:]
Legacy mock/simulation adapter for BB-8. Previously used for test scaffolding.
STATUS: deprecated (do not use; pending removal)
MAIN ENTRYPOINTS: [n/a]
DEPENDENCIES: [none—do not import in production code]
LAST VALIDATED: 2025-06-18
NOTES:
- This file is slated for deletion per simulation_purge_plan.json.
- All simulation/testing should use simulation_adapter.py exclusively.
"""
```

---

## **How to Use:**

* Paste at the **very top** of each respective file.
* Adjust `LAST VALIDATED` date as you make changes.
* Update **NOTES** section if new risks, dependencies, or policies are introduced.
