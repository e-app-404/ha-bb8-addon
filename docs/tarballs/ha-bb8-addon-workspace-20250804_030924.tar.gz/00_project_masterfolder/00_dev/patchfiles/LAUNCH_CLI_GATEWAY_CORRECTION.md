# 📦 PATCH: launch_bb8.py BLE Gateway Cleanup

# PATCHCHECK:LAUNCH_CLI_GATEWAY_CORRECTION

from ha_sphero_bb8.ble_gateway import BleGateway
from ha_sphero_bb8.controller import handle_roll_command

def main():
    gateway = BleGateway()

    # ✅ Use updated method
    device = gateway.scan_for_device()
    if not device:
        print("No BB-8 device found.")
        return

    # ✅ Updated contract
    status = gateway.get_connection_status()
    print(f"Connected to BB-8: {status}")

    payload = {"heading": 0, "speed": 60}
    handle_roll_command(payload, device)

    gateway.shutdown()

if __name__ == "__main__":
    main()
