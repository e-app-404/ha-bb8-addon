Copilot Prompt: Direct Hardware Validation of BB-8 via Local spherov2

⸻

Prompt:

Our local spherov2 package is now confirmed loaded and working.
The BLE scan detects my BB-8 with MAC address:
259ED00E-3026-2568-C410-4590C9A9297C

Action Required:

 1. Insert a script or notebook (or emit a CLI patch) that performs:
 • Connects directly to the BB-8 using this exact MAC.
 • Sets the main LED to a visible color (e.g., red: 255, 0, 0).
 • Optionally, rolls the BB-8 and then stops after 2 seconds for physical validation.
 2. Use only the confirmed local spherov2 (do not reference the pip package or any vendor import).
 3. Emit the code as a copy-paste Python snippet using the actual detected MAC address, not a placeholder.
 4. Ensure the code is ready to run in an activated venv and will output any exceptions if BLE or permissions fail.
 5. Include a comment to capture operator observation of physical hardware feedback (“BB-8 lights up/moves”).
 6. Document the path or filename for this script, e.g., hardware_validate_bb8.py, so the artifact is traceable.
 7. After code execution, prompt the user to paste the terminal output and a description (or photo/video) of BB-8’s physical response for governance signoff.

⸻

Example Code Structure:

from spherov2.toy.bb8 import BB8
import time

bb8_mac = '259ED00E-3026-2568-C410-4590C9A9297C'
bb8 = BB8(bb8_mac)
bb8.set_main_led(255, 0, 0)  # Set to RED for visible validation
bb8.roll(50, 0)              # Roll forward
time.sleep(2)
bb8.stop()
print("BB-8 test complete. Please confirm if BB-8 lit up or moved.")

⸻

Governance Acceptance Criteria:
 • This code must use the real MAC.
 • The operator must confirm (via log and description/photo) that BB-8 physically responds.
 • Mark as “hardware validated” only if both code output and physical feedback are confirmed.

⸻
