# UPDATE MQTT_HANDLER TO DISPATCH TOPICS

def dispatch_from_topic(topic: str, payload: dict, controller) -> dict:
    """
    Dispatch MQTT command topic to the correct controller method.
    """
    response = {"topic": topic, "handled": False}

    if topic == "bb8/command/move":
        speed = payload.get("speed", 50)
        heading = payload.get("heading", 0)
        response["result"] = controller.roll(speed, heading)
        response["handled"] = True

    elif topic == "bb8/command/stop":
        response["result"] = controller.stop()
        response["handled"] = True

    elif topic == "bb8/command/rotate":
        angle = payload.get("angle", 90)
        response["result"] = controller.rotate(angle)
        response["handled"] = True

    elif topic == "bb8/command/led":
        r, g, b = payload.get("r", 255), payload.get("g", 255), payload.get("b", 255)
        response["result"] = controller.set_led(r, g, b)
        response["handled"] = True

    elif topic == "bb8/command/diagnostics":
        response["result"] = controller.get_diagnostics_for_mqtt()
        response["handled"] = True

    elif topic == "bb8/command/test":
        response["result"] = controller.simulate() if hasattr(controller, "simulate") else {"error": "No simulate method"}
        response["handled"] = True

    else:
        response["error"] = "Unknown topic"

    return response

# INJECT THIS INTO run_mqtt.py:

def on_message(client, userdata, msg):
    import json, logging
    topic = msg.topic
    payload = json.loads(msg.payload.decode())
    result = dispatch_from_topic(topic, payload, controller)
    logging.getLogger("ha_sphero_bb8").info(f"Handled {topic}: {result}")
