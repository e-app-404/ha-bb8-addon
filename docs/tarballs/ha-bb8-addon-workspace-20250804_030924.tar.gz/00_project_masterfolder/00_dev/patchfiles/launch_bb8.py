# src/ha_sphero_bb8/launch_bb8.py
"""
BB-8 Launch Script with CLI Orchestration
Enhanced runtime orchestration for BB-8 device control via CLI

Provides:
- CLI argument parsing for command execution
- Device initialization using initialize_bb8()
- Command routing to controller functions
- Payload handling (CLI JSON or defaults)
- Structured logging and JSON output

HESTIA Compliance:
- Tier: ζ (services - user interface)
- Consumes: α-tier BLE gateway, β-tier controller
- Exposes: CLI interface for device control
- Prepares: Foundation for HA service integration
"""

import argparse
import json
import logging
import sys
import time
from typing import Dict, Any, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_argument_parser() -> argparse.ArgumentParser:
    """Create comprehensive CLI argument parser"""
    parser = argparse.ArgumentParser(
        description="Sphero BB-8 Control Launcher with CLI Orchestration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s roll --payload '{"speed": 100, "heading": 90}'
  %(prog)s led --payload '{"r": 255, "g": 0, "b": 0}'
  %(prog)s stop
  %(prog)s status --adapter sim
  %(prog)s diagnostics --adapter bleak
        """
    )

    parser.add_argument(
        "command",
        choices=["roll", "led", "stop", "status", "diagnostics"],
        help="Command to execute on BB-8 device"
    )

    parser.add_argument(
        "--adapter",
        choices=["bleak", "sim"],
        default="bleak",
        help="BLE adapter mode (default: bleak)"
    )

    parser.add_argument(
        "--payload",
        type=str,
        help="Command payload as JSON string"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run in simulation mode without device interaction"
    )

    parser.add_argument(
        "--json-output",
        action="store_true",
        help="Output results in JSON format"
    )

    return parser

def setup_logging(verbose: bool = False):
    """Configure logging based on verbosity"""
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logging.getLogger('ha_sphero_bb8').setLevel(logging.DEBUG)
    else:
        logging.getLogger().setLevel(logging.INFO)
        # Reduce noise from external libraries
        logging.getLogger('bleak').setLevel(logging.WARNING)
        logging.getLogger('spherov2').setLevel(logging.WARNING)

def get_default_payload(command: str) -> Dict[str, Any]:
    """Get safe default payload for each command"""
    defaults = {
        "roll": {
            "speed": 50,
            "heading": 0,
            "duration": 2.0
        },
        "led": {
            "r": 0,
            "g": 255,
            "b": 0  # Safe green color
        },
        "stop": {},
        "status": {},
        "diagnostics": {}
    }

    return defaults.get(command, {})

def parse_payload(payload_str: Optional[str], command: str) -> Dict[str, Any]:
    """Parse payload string or return default"""
    if payload_str:
        try:
            payload = json.loads(payload_str)
            logger.debug(f"Parsed payload: {payload}")
            return payload
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON payload: {e}")
            raise ValueError(f"Invalid JSON payload: {e}")
    else:
        default_payload = get_default_payload(command)
        logger.info(f"Using default payload for {command}: {default_payload}")
        return default_payload

def initialize_bb8_device(adapter_mode: str, dry_run: bool = False):
    """Initialize BB-8 device using the available interface"""
    try:
        # Import the initialization function
        if dry_run:
            adapter_mode = "sim"

        # Try to import from the separate initialize_bb8.py file first
        try:
            from .initialize_bb8 import initialize_bb8
            logger.info(f"Initializing BB-8 device with adapter: {adapter_mode}")
            device = initialize_bb8(adapter_mode=adapter_mode)
        except ImportError:
            # Fallback: try to import from bb8_control.py
            try:
                from .bb8_control import initialize_bb8
                logger.info(f"Initializing BB-8 device with adapter: {adapter_mode}")
                device = initialize_bb8(adapter_mode=adapter_mode)
            except ImportError:
                # Final fallback: use basic connection logic
                logger.warning("initialize_bb8 not found, using basic connection")
                from .ble_gateway import connect_bb8
                device = connect_bb8()

        if device is None:
            raise RuntimeError("Failed to initialize BB-8 device")

        logger.info("BB-8 device initialized successfully")
        return device

    except Exception as e:
        logger.error(f"Device initialization failed: {e}")
        raise

def execute_command(command: str, payload: Dict[str, Any], device, dry_run: bool = False) -> Dict[str, Any]:
    """Execute command using controller functions"""
    try:
        # Import command handlers from controller
        from .controller import (
            handle_roll_command,
            handle_led_command,
            handle_stop_command,
            handle_status_command,
            handle_diagnostics_command
        )

        execution_start = time.time()

        if dry_run:
            logger.info(f"[DRY-RUN] Would execute {command} with payload: {payload}")
            result = {
                "success": True,
                "command": command,
                "payload": payload,
                "message": f"[DRY-RUN] Would execute {command} command",
                "dry_run": True
            }
        else:
            logger.info(f"Executing command: {command}")

            # Route to appropriate handler
            if command == "roll":
                result = handle_roll_command(payload, device)
            elif command == "led":
                result = handle_led_command(payload, device)
            elif command == "stop":
                result = handle_stop_command(device)
            elif command == "status":
                result = handle_status_command(device)
            elif command == "diagnostics":
                result = handle_diagnostics_command(device)
            else:
                raise ValueError(f"Unknown command: {command}")

        # Add execution metadata
        execution_time = time.time() - execution_start
        result.update({
            "execution_time": execution_time,
            "timestamp": time.time()
        })

        logger.info(f"Command {command} completed in {execution_time:.3f}s")
        return result

    except Exception as e:
        logger.error(f"Command execution failed: {e}")
        return {
            "success": False,
            "command": command,
            "payload": payload,
            "error": str(e),
            "timestamp": time.time()
        }

def format_output(result: Dict[str, Any], json_output: bool = False) -> str:
    """Format command result for output"""
    if json_output:
        return json.dumps(result, indent=2)
    else:
        # Human-readable format
        success = "✅" if result.get("success", False) else "❌"
        command = result.get("command", "unknown")

        output_lines = [
            f"{success} Command: {command}",
            f"Status: {'Success' if result.get('success') else 'Failed'}"
        ]

        if result.get("dry_run"):
            output_lines.append("Mode: DRY-RUN")

        if result.get("message"):
            output_lines.append(f"Message: {result['message']}")

        if result.get("error"):
            output_lines.append(f"Error: {result['error']}")

        if result.get("execution_time"):
            output_lines.append(f"Execution time: {result['execution_time']:.3f}s")

        return "\n".join(output_lines)

def main():
    """Main CLI entry point"""
    parser = create_argument_parser()
    args = parser.parse_args()

    # Setup logging
    setup_logging(args.verbose)

    logger.info("BB-8 Control Launcher starting...")
    logger.info(f"Command: {args.command}, Adapter: {args.adapter}")

    exit_code = 0
    device = None

    try:
        # Parse payload
        payload = parse_payload(args.payload, args.command)

        # Initialize device
        device = initialize_bb8_device(args.adapter, args.dry_run)

        # Execute command
        result = execute_command(args.command, payload, device, args.dry_run)

        # Output result
        output = format_output(result, args.json_output)
        print(output)

        # Set exit code based on success
        if not result.get("success", False):
            exit_code = 1

    except KeyboardInterrupt:
        logger.info("Operation cancelled by user")
        exit_code = 130

    except Exception as e:
        logger.error(f"Launcher error: {e}")

        error_result = {
            "success": False,
            "error": str(e),
            "command": getattr(args, 'command', 'unknown'),
            "timestamp": time.time()
        }

        output = format_output(error_result, args.json_output)
        print(output)

        if args.verbose:
            import traceback
            traceback.print_exc()

        exit_code = 1

    finally:
        # Cleanup device connection if needed
        if device and hasattr(device, 'disconnect'):
            try:
                device.disconnect()
                logger.info("Device disconnected")
            except Exception as e:
                logger.warning(f"Device disconnect error: {e}")

    logger.info(f"BB-8 Control Launcher exiting with code: {exit_code}")
    return exit_code

if __name__ == "__main__":
    sys.exit(main())
