### 📂 patch_manifest.yaml
patch_manifest:
  files_modified:
    - src/ha_sphero_bb8/controller.py
    - src/ha_sphero_bb8/ble_gateway.py
    - src/ha_sphero_bb8/bb8_control.py
    - src/ha_sphero_bb8/mqtt_handler.py
    - src/ha_sphero_bb8/launch_bb8.py
    - src/ha_sphero_bb8/controller/safe_utils.py
    - src/ha_sphero_bb8/device_core/adapters/simulation_adapter.py
    - src/ha_sphero_bb8/device_core/adapters/mockBB8device.py
    - src/ha_sphero_bb8/device_core/utils/motor_utils.py

### 📉 Diff Logs

# FILE: src/ha_sphero_bb8/controller/safe_utils.py
```python
from typing import Any

def safe_ping(device: Any) -> bool:
    try:
        return device.ping()
    except Exception:
        return False

def safe_set_main_led(device: Any, r: int, g: int, b: int) -> bool:
    try:
        device.set_main_led(r, g, b)
        return True
    except Exception:
        return False

def safe_get_voltage(device: Any) -> float:
    return getattr(device, "get_battery_voltage", lambda: 0.0)()

def safe_get_percentage(device: Any) -> int:
    return getattr(device, "get_battery_percentage", lambda: -1)()
```

# FILE: src/ha_sphero_bb8/controller.py
```python
# EXPORTS UPDATED
__all__ = [
    "handle_roll_command",
    "handle_stop_command",
    "handle_led_command",
    "handle_status_command",
    "handle_diagnostics_command",
    "BB8Like"
]

# BB8Like PROTOCOL UPDATED
class BB8Like(Protocol):
    def roll(self, speed: int, heading: int, timeout: Optional[float] = None, boost: bool = False) -> dict: ...
    def stop(self) -> None: ...
    def set_main_led(self, r: int, g: int, b: int) -> None: ...
    def wake(self) -> None: ...
    def ping(self) -> bool: ...
    def get_battery_voltage(self) -> float: ...
    def get_battery_percentage(self) -> int: ...
```

# FILE: src/ha_sphero_bb8/device_core/adapters/simulation_adapter.py
```python
# UNIFIED MOCK BB8 DEVICE DEFINITION
class MockBB8Device:
    def roll(self, speed: int, heading: int, timeout: float = 0.0, boost: bool = False) -> dict:
        return {"success": True, "speed": speed, "heading": heading, "timeout": timeout, "boost": boost}

    def stop(self) -> None:
        pass

    def set_main_led(self, r: int, g: int, b: int) -> None:
        pass

    def wake(self) -> None:
        pass

    def ping(self) -> bool:
        return True

    def get_battery_voltage(self) -> float:
        return 3.7

    def get_battery_percentage(self) -> int:
        return 80
```

# FILE: src/ha_sphero_bb8/device_core/adapters/mockBB8device.py
```python
# FILE REMOVED — superseded by simulation_adapter.MockBB8Device
```

# FILE: src/ha_sphero_bb8/device_core/utils/motor_utils.py
```python
class EnhancedMotorControl:
    def __init__(self, device, simulation_mode=False):
        self.device = device
        self.simulation_mode = simulation_mode

    def roll(self, speed: int, heading: int, timeout: Optional[float] = None, boost: bool = False) -> dict:
        return self.device.roll(speed=speed, heading=heading, timeout=timeout, boost=boost)
```
