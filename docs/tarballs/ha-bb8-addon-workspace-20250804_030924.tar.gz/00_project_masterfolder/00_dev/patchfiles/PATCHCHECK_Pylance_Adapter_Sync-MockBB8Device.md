class MockBB8Device:
    def roll(self, speed: int, heading: int, timeout: float = 0.0, boost: bool = False) -> dict:
        return {"success": True, "speed": speed, "heading": heading, "timeout": timeout, "boost": boost}

    def stop(self) -> None:
        pass

    def set_main_led(self, r: int, g: int, b: int) -> None:
        pass

    def wake(self) -> None:
        pass

    def ping(self) -> bool:
        return True

    def get_battery_voltage(self) -> float:
        return 3.7

    def get_battery_percentage(self) -> int:
        return 80
