class MockBLEAdapter:
    def scan(self): return ['MOCK-DEVICE']
    def connect(self, identifier): return True
    def disconnect(self): return True
    def is_connected(self): return True
    def roll(self, heading, speed): print(f"Mock roll {heading=} {speed=}")
    def set_main_led(self, r, g, b): print(f"Mock LED {r=} {g=} {b=}")
    def stop(self): print("Mock stop")
    def get_battery_voltage(self): return 3.7
    def get_battery_percentage(self): return 42
    def wake(self): pass  # Added for type safety
