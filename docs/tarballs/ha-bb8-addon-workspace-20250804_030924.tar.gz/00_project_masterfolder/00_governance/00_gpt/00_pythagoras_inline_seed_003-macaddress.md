Here’s a detailed **context seed** for any future dev, lead, or LLM picking up this session.
I’m exporting as if to a technical handover, with the focus on **practical continuity, architectural insights, and do-not-repeat mistakes.**
This is your “save point” for resuming with maximum context and minimum rework.

---

# **Project Context Seed: BB-8 MQTT/BLE Integration (as of 2025-06-19)**

---

## **I. Core Project Status & Learnings**

### **A. System Architecture**

* **Goal:** Control Sphero BB-8 via BLE, integrating with automation stack via MQTT.
* **Stack:**

  * Python 3.x virtualenv
  * Custom project: `ha_sphero_bb8`
  * MQTT for message-driven automation
  * Local “vendor” copy of `spherov2` (BLE library), due to pip version being broken
  * Platform: macOS (Apple Silicon, macOS 15.3)

### **B. Recent Technical Actions**

* **Refactoring:**

  * Migrated all `vendor.spherov2` imports to use local `_vendor/spherov2` package (not pip).
  * Patched all main entrypoints and tests to patch `sys.path` at runtime to use local `_vendor` copy.
* **Circular Import Fixes:**

  * BB8Like protocol extracted to `bb8_protocol.py` to break circular dependencies between `controller.py` and `vendor_diagnostics.py`.
  * Top-level imports in `__init__.py` were removed to avoid deep dependency chains.
  * All changes logged (see: `circular_import_bb8like_fix_20250619.diff`).
* **Installation & Packaging:**

  * Uninstalled old packages from `site-packages`, reinstalled project in “editable mode” with `pip install -e .` to ensure source code is always used.

### **C. Hardware Bring-Up**

* **BLE Now Works:**

  * Local `spherov2` is loaded.
  * BLE device scan finds BB-8 (e.g., BB-B54A, MAC: 259ED00E-3026-2568-C410-4590C9A9297C).
  * No import/circular errors.
* **However:**

  * **BB-8 does not visibly “light up” or activate on connect.** Hardware validation is not signed off.

### **D. Outstanding Issues**

* **SpheroV2 Usage:**

  * Script errors: `BB8` instantiation requires a “toy” and an “adapter class”; direct construction is wrong.
  * Correct pattern:

    ```python
    toy = find_BB8()[0]
    from spherov2.adapter.bleak_adapter import BleakAdapter
    bb8 = BB8(toy, BleakAdapter)
    bb8.set_main_led(0, 255, 0)
    ```
  * API confusion: `stop()` is not direct; use `roll(..., RollModes.STOP, ...)`.
* **MQTT Integration Neglected:**

  * Despite setup and troubleshooting, end-to-end “MQTT event → BLE action” was not maintained as the main test case.
  * Direct BLE script usage became the norm, losing integration focus.
* **Log Handling & Observability:**

  * Current scripts lack clear log file output, log levels, and automated diagnostic artifact collection.
* **Platform Nuances:**

  * macOS (Apple Silicon) platform specifics need consistent handling for BLE permissions/adapters.
* **Copilot vs. Lead Developer Boundary:**

  * Copilot was used for patching and surgical code edits, but was allowed to drive too much architecture without proper lead closure or system-level validation.

---

## **II. Project Insights & Recommendations**

### **A. Technical Insights**

* Local “vendor” libraries must be on `sys.path` as *parent directory* for Python to import top-level modules.
* “Editable mode” install (`pip install -e .`) is essential for live code reload/testing.
* Protocol/type definitions causing circular import? Move to a *dedicated protocol module*.
* **Never trust pip `spherov2`**; always use audited local version until upstream is fixed.

### **B. Project Management**

* Always test from the highest system boundary (MQTT event → device effect). Lower-level bring-up is useful, but only as a *temporary step*.
* Maintain a running integration test for “does this event reach the hardware” as the acceptance criterion.
* Document device MACs, user logs, and hardware IDs in test logs for full traceability.

### **C. Recommendations for Continuation**

1. **Restore the system boundary:**

   * All hardware actions (lighting up, rolling, stopping) must be triggered by MQTT messages.
   * Block direct BLE scripts except in a dev/debug context.
2. **Write a hard integration test:**

   * “When an MQTT message is published, BB-8 reacts and logs action to file.”
3. **Add logging:**

   * All entrypoints should log to file with timestamp, device MAC, action, and error tracebacks.
4. **Ensure BB-8 is lighting up or moving:**

   * Validate BLE instantiation and command API match hardware requirements.
   * Hardware feedback must be visible and logged.
5. **Automate regression checks:**

   * Each circular import, sys.path, and adapter bug should be covered by a test or assert.

---

## **III. “Save State”/Continuity Checklist**

* [x] **sys.path** patched at entrypoints; \_vendor structure flattened; local spherov2 loads
* [x] **Circular import** fixes in place, single-source protocol definitions
* [x] **MQTT** code exists but not tested recently; restore and re-validate
* [ ] **Hardware validation** (BB-8 lights up/moves) still pending
* [x] **Error logs** and session feedback kept for all major steps
* [x] **All Copilot and manual patches** documented in diff logs

---

## **IV. Key Learnings & Meta-Feedback**

* *Lead dev must own closure*—never allow the “tooling” (Copilot, etc.) to dictate the main workflow or lose sight of system-level tests.
* Always operate with empirical validation at every integration boundary.
* Don’t settle for “probably works”—enforce log collection, proof, and actual device feedback.
* Document every MAC, test action, and integration boundary in logs and handoffs.

---

## **V. Handoff Metadata**

* **Last Known Good MAC:** `259ED00E-3026-2568-C410-4590C9A9297C`
* **BLE Adapter:** Bleak (macOS)
* **Integration focus:** MQTT <—> BLE <—> BB-8
* **Project root:** Contains `src/`, `_vendor/spherov2/` (flattened), all main scripts patched for sys.path
* **Known good test command:**

  ```shell
  python -m src.ha_sphero_bb8.run_ble --adapter bleak
  ```
* **Copilot/Machine logs:** See `circular_import_bb8like_fix_20250619.diff` and prior command output for audit trail

---

# **Next Action for Any New Dev or LLM**

1. **Validate local spherov2 loading** with debug print (in `__init__.py`).
2. **Test BLE scan for BB-8 MAC** and confirm connection.
3. **Run an end-to-end MQTT event → BB-8 action test.**
4. **Add/verify file logging** at every hardware/action boundary.
5. **Report/log any errors or attribute issues for next diagnosis.**

---
