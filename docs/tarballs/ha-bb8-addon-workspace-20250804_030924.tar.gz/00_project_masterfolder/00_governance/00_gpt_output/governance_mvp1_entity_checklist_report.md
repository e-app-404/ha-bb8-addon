# MVP1 Hardware Integration Entity Map (Excerpt)

| File                                       | Entity Type   | Name/Signature                   | Description                            |
|:-------------------------------------------|:--------------|:---------------------------------|:---------------------------------------|
| controller.py                              | Protocol      | BB8Like                          | Defines BB-8 device interface contract |
| controller.py                              | Class         | BB8Adapter(BB8Like)              | Adapts vendor BB8 to BB8Like           |
| controller.py                              | Function      | initialize_bb8(...)              | Returns protocol-compliant BB8 device  |
| ble_gateway.py                             | Class         | BLEGateway                       | Handles BLE device connections         |
| mqtt_handler.py                            | Class         | MQTTHandler                      | Receives/processes MQTT messages       |
| mqtt_dispatcher.py                         | Class         | MQTTDispatcher                   | Routes MQTT topics to handlers         |
| device_core/adapters/bleak_adapter.py      | Class         | BleakAdapter                     | Wraps BleakClient for BB8 device       |
| device_core/adapters/simulation_adapter.py | Class         | SimulationAdapter                | Simulates BB8 for test/dev             |
| controller/commands/led_state_variants.py  | Function      | set_led_variant(device, variant) | LED state helper                       |
| device_core/utils/battery_utils.py         | Function      | read_battery_status(device)      | Reads battery diagnostics              |
| controller.py                              | Decorator     | @runtime_checkable               | Enforces protocol compliance           |
| bb8_control.py                             | Function      | roll(...)                        | Moves BB-8 device                      |
| bb8_control.py                             | Function      | stop(...)                        | Stops BB-8 device                      |
| controller/commands/roll_profiles.py       | Function      | get_roll_profile(...)            | Profiles for roll command              |
| controller/commands/battery_diagnostics.py | Function      | diagnose_battery(...)            | Battery health diagnostics             |
| controller.py                              | Function      | is_protocol_compliant(...)       | Checks protocol compliance at runtime  |
| device_core/utils/color_utils.py           | Function      | set_color(...)                   | Sets device LED color                  |
| mqtt_dispatcher.py                         | Function      | dispatch(...)                    | MQTT topic to command handler mapping  |
| ble_gateway.py                             | Function      | scan_devices(...)                | BLE device discovery                   |
| ble_gateway.py                             | Function      | connect(...)                     | Connects to BLE device                 |

# Checklist Coverage Matrix (Excerpt)

| Checklist Item                 | Code Entity/Location                          | Status   | Notes                          |
|:-------------------------------|:----------------------------------------------|:---------|:-------------------------------|
| BLE device discovery           | ble_gateway.py: BLEGateway.scan_devices       | COMPLETE | Finds all BB-8s                |
| BLE connect/disconnect         | ble_gateway.py: BLEGateway.connect/disconnect | COMPLETE | Connect/disconnect logic solid |
| BLE command send/receive       | bleak_adapter.py: BleakAdapter.send_command   | COMPLETE | Can send/receive BLE packets   |
| Protocol enforcement           | controller.py: BB8Like, BB8Adapter            | COMPLETE | Static/runtime enforced        |
| MQTT receive command           | mqtt_handler.py: MQTTHandler.on_message       | COMPLETE | All inbound handled            |
| MQTT dispatch                  | mqtt_dispatcher.py: MQTTDispatcher.dispatch   | COMPLETE | Topic mapped to handler        |
| BB-8 roll command              | bb8_control.py: roll                          | COMPLETE | Can roll via MQTT              |
| BB-8 stop command              | bb8_control.py: stop                          | COMPLETE | Can stop via MQTT              |
| BB-8 set LED                   | led_state_variants.py: set_led_variant        | COMPLETE | LED variant settable           |
| Battery diagnostics            | battery_utils.py: read_battery_status         | PARTIAL  | Not yet mapped to MQTT         |
| Sensor diagnostics             | controller/commands/vendor_diagnostics.py     | PARTIAL  | Logic partial                  |
| Simulation support             | simulation_adapter.py                         | COMPLETE | All flows can be simulated     |
| Test CLI/demo                  | run_ble.py, launch_bb8.py                     | PARTIAL  | Needs consolidation            |
| Central audit log              | core handlers                                 | PARTIAL  | Basic per-module               |
| Error handling                 | BLEGateway, Adapters                          | PARTIAL  | Needs centralization           |
| Protocol compliance at runtime | controller.py: @runtime_checkable             | COMPLETE | Everywhere enforced            |
| Import correctness             | controller.py, adapters                       | COMPLETE | No vendor import errors        |
| No unresolved protocol errors  | ALL                                           | COMPLETE | All clear                      |
| MQTT status/diagnostics        | TO DO                                         | MISSING  | Needs feedback mapping         |
| Full coverage for demo         | ALL                                           | PARTIAL  | Demo loop needs finishing      |