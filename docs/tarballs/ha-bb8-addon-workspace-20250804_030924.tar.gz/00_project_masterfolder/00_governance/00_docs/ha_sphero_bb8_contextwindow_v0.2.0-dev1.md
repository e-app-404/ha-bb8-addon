terminal:
  session:
  name: sphero_bb8_ble_activation
  prerequisites:
    - Activated virtualenv via: source spherovenv/bin/activate
    - Working build using: python3 -m build && pip install --force-reinstall dist/*.whl

  commands:
    - step: "Install BLE adapter dependency"
      shell: pip install bleak

    - step: "Verify bleak import"
      shell: python3 -c "import bleak"

    - step: "Run live BLE-enabled connection test"
      shell: python3 -m ha_sphero_bb8.run_ble
      expects_output:
        - "[BLE_GATEWAY] Scanning for BB-8"
        - "[BLE_GATEWAY] BB-8 toy connected."
      fallback_on_failure:
        - Confirm BB-8 is charged and powered on
        - Reduce interference (Bluetooth-only environment)
        - Retry scan with BLE_ENABLED confirmed True
