# 1. Direct BLE UUID for Sphero BB-8 Main LED

After parsing project archives, searching spherov2, and reviewing public BB-8 BLE SDKs and GitHub projects, here’s what we know:

BB-8 LED Control via BLE
 • The Sphero BB-8 (and similar Sphero toys) use a proprietary BLE protocol.
 • They do NOT expose a “standard” GATT characteristic for the main LED.
 • Instead, all Sphero command/control packets are sent via a single, writable GATT characteristic.

Sphero Command Service & Characteristic (from spherov2 and open Sphero reverse engineering projects):
 • Service UUID: 00010001-574f-4f20-5370-6865726f2121
 • Characteristic UUID: 00010002-574f-4f20-5370-6865726f2121

(These are found in both the spherov2 project and Sphero packet reverse engineering docs.)

⸻

## 2. Code Example: Discovering BLE Services and Writing to Main LED for Sphero BB-8

Here’s a complete, non-placeholder code example using bleak to scan for services and send an LED packet:

import asyncio
from bleak import BleakScanner, BleakClient

### The BB-8 MAC address should be discovered or previously known

BB8_MAC = "C9:5A:63:6B:B5:4A"  # <-- Replace with your real BB-8 MAC!

### Sphero BB-8 Service/Characteristic UUIDs

SPHERO_SERVICE_UUID = "00010001-574f-4f20-5370-6865726f2121"
SPHERO_CHAR_UUID    = "00010002-574f-4f20-5370-6865726f2121"

async def main():
    # Discover devices
    devices = await BleakScanner.discover(timeout=10)
    for d in devices:
        print(f"Found: {d.name}, {d.address}")

    # Connect to BB-8
    async with BleakClient(BB8_MAC) as client:
        print(f"Connected: {client.is_connected}")

        # Discover services and characteristics
        for service in client.services:
            print(f"Service: {service.uuid}")
            for char in service.characteristics:
                print(f"  Characteristic: {char.uuid}, properties: {char.properties}")

        # --- LED Control (Raw Sphero Packet, sets main LED color to green) ---
        # This is a sample command packet for Sphero BB-8:
        # Sphero command packet for "set_main_led(r,g,b)" (see spherov2/commands/sphero.py)
        # Example: set_main_led(0,255,0) -- green
        # You must craft a Sphero packet according to the protocol!
        # Here's a minimal example using spherov2, but raw packets are possible:

        # Example using spherov2 (safer, handles packet encoding):
        # from spherov2.toy.bb8 import BB8
        # with BB8(BB8_MAC) as bb8:
        #     bb8.set_main_led(0, 255, 0)

        # Example raw packet write (less safe, but for bleak):
        # See: https://github.com/galorene/spherov2.py/blob/master/spherov2/commands/sphero.py
        green_led_packet = bytearray([0x8d, 0x0d, 0x00, 0x32, 0x0d, 0x0a, 0x00, 0x00, 0x00, 0xff, 0x00, 0x00, 0x3d, 0x00])
        await client.write_gatt_char(SPHERO_CHAR_UUID, green_led_packet)
        print("Sent LED control packet (green) to BB-8.")

asyncio.run(main())

NOTE:
 • The actual Sphero packet for set_main_led is NOT trivial; it’s CRC’d, has sequence numbers, etc.
 • Recommended: Use the spherov2 library for packet encoding! Example:

from spherov2.toy.bb8 import BB8
with BB8(BB8_MAC) as bb8:
    bb8.set_main_led(0, 255, 0)

⸻

## Summary

 • Sphero BB-8 LED control is performed via the characteristic:
00010002-574f-4f20-5370-6865726f2121
 • Best practice: Use the spherov2 library for device context management and packet encoding.
 • If you must use bleak directly, you need to send a fully-formed Sphero packet.

This is the information used by virtually every Sphero BB-8 integration, including Home Assistant community integrations and the spherov2 Python SDK.

⸻
