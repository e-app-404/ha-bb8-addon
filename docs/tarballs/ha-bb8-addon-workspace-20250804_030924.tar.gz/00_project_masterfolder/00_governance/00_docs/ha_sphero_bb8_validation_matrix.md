# ✅ Sphero BB-8 Validation Matrix (Phase 2.3)

Welcome! This checklist helps you test the BB-8 app safely — even if you're 8 years old. 🎮✨

---

## 🛠️ Setup

| ✅ Step | Command | Notes |
|--------|---------|-------|
| 🐍 Activate Python | `source spherovenv/bin/activate` | You’ll see `(spherovenv)` in your terminal |
| 📦 Install packages | `python3 -m pip install -r requirements.txt` | Uses pinned Sphero library version |
| 🧭 Check paths | `echo $PYTHONPATH` | Should return: `src` |

---

## 🚀 CLI Test Modes

### 1.Always Start from the Project Root

Every make, bb8-control, python tools/..., etc. assumes you’re in this root.

`cd ~/Projects/ha_sphero_bb8`

### 2.Activate the right virtual environment

`source spherovenv/bin/activate`

Should show something like: `(spherovenv) % _`

| ✅ Test | Command | PASS if… |
|--------|---------|-----------|
| 🧪 Dry-run | `bb8-control --noop` | You see: `SIMULATION` in the output |
| 🧼 Lint | `tox` | All 3 phases pass: test, build, noop |
| 🧠 Controller logic | `python -m unittest discover tests` | You see: `OK` |
| 🧪 BLE Dry Test | `python tools/run_ble.py` | You see a message saying BLE is disabled |

If you ever see ModuleNotFoundError, you're likely one directory too deep or missing PYTHONPATH

---

## 🧬 BLE Activation

| 🛡️ Safety Step | ✅ Confirm |
|----------------|-----------|
| `BLE_ENABLED = False` by default | ✅ Yes |
| Paired BB-8 is nearby and powered | 🔄 You do this |
| Run pairing | `python tools/run_ble.py` | You see `Connected to BB-8: ...` |

---

```bash
# 🧪 Dry-run CLI test
bb8-control --noop

# 🚀 Run BLE connection (if BLE_ENABLED = True)
python tools/run_ble.py

# 🔨 Build the wheel
make build

# ✅ Run tests with path injected
make test

# 🧼 Install local wheel
make install

# 🧠 Confirm CLI and structure
make check  # (optional, if tools/check_status.py is added)

# 🧹 Clean build artifacts
make clean
```

---

| Terminal         | Status     | Note                                 |
| ---------------- | ---------- | ------------------------------------ |
| macOS Terminal   | ✅ Tested   | Use `zsh`, `.zshrc` for env vars     |
| iTerm2           | ✅ Optimal  | Keeps env state persistent           |
| VS Code Terminal | ✅ IDE-safe | Auto-loads `.env`, picks interpreter |

---

## 🔚 Done?

If all above are ✅ → you're ready for Phase 3 🎉
Don't forget to tag `v0.2.0-dev1` if BLE connects successfully.
