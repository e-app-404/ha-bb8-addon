# 🟦 **BB-8 v1 Developer Briefing (Release Block)**

**Purpose:**
Deliver a *production-ready* BB-8 MQTT integration that passes all code quality, simulation, and vendor feature checks as specified in the v1 release manifest.

---

## **Output Requirements**

1. **No legacy or duplicate code:**

   * Only one simulation adapter (simulation_adapter.py), one controller (controller.py).
   * All mocks/shims (mock_bb8.py, mock_adapter.py, etc.) must be removed.

2. **Governance docstrings:**

   * Every Python module/class must have a docstring stating purpose, status, and dependencies.

3. **Type safety & lint:**

   * No Pylance/linter errors (unless flagged as false positive).
   * All public methods/classes have type annotations.

4. **Error handling:**

   * All command handlers in mqtt_handler.py must be wrapped in try/except with error logging.
   * All shutdown and disconnect routines must be safe.

5. **Testing:**

   * All tests must use simulation_adapter for mocks; no legacy mocks.
   * Integration tests must cover: move, stop, rotate, led, diagnostics, test (for MQTT).
   * Use pytest harness; tests must be runnable via CLI.

6. **Configuration:**

   * All MQTT topics, broker config, and adapter modes must be in constants.py—no hardcoded values elsewhere.

7. **Documentation:**

   * README must document CLI usage (with adapter flags), architecture, simulation mode, and how to run tests.
   * Patchlog must describe all major changes/removals.

8. **Deployment:**

   * requirements.txt and pyproject.toml must be accurate.
   * Package must build and install in a clean environment.

9. **Operational:**

   * CLI (run_mqtt.py) must work with both real and simulation adapters.
   * All CLI options must be documented and tested.
   * Logging should be clear and use standard levels.

10. **Vendor features:**

    * All Sphero movement, lights, sensors, and events (from vendor list) must be implemented or stubbed with NotImplementedError and a docstring.

---

## **Validation & Review**

* **All requirements are binary:**
  Each must be demonstrably met; ambiguity means “not done.”
* **Reviewer/PO (Pythagoras/Strategos) has authority** to accept or reject PRs based on this checklist.
* **Independent test/log review:**
  Output test logs and SHA256 manifest must be attached for validation.
* **If stubbing any vendor feature:**
  Must add docstring and a test case asserting NotImplementedError.

---

## **What’s Not Required**

* No additional simulation or mock code outside simulation_adapter.py.
* No UI or web integration—CLI and MQTT only.
* No undocumented features or “silent” changes.

---

**Proceed with implementation, attach manifest and checklist to all PRs.**
*Deviations must be flagged, justified, and pre-approved.*
