release_manifest: bb8_v1
scope: |
  This contract covers the production readiness, engineering action items, and minimum
  feature set required for Sphero BB-8 v1.0 release.
  All items MUST be completed, tested, and documented before release approval.

production_checklist:
  code_quality:
    - [ ] Governance docstrings: All modules have up-to-date, purpose/status docstrings
    - [ ] No duplicate/legacy classes: Only one simulation adapter, one controller present
    - [ ] Dead code/mocks removed: No deprecated mocks or unused files
    - [ ] Interface parity: All device classes implement consistent interface (disconnect(), etc)
  type_safety:
    - [ ] Zero Pylance/type/linter errors (except documented false positives)
    - [ ] All public classes/functions have type annotations
    - [ ] No stray or phantom types (undefined classes, etc)
  testing:
    - [ ] Dependency injection in all tests (use simulation_adapter only for mocks)
    - [ ] Integration tests for ALL MQTT commands: move, stop, rotate, led, diagnostics, test
    - [ ] Tests assert both MQTT message receipt and controller method calls
    - [ ] Simulation mode matches real device API
  error_handling:
    - [ ] All command handlers wrapped in try/except with error logging
    - [ ] Safe shutdown/cleanup (no disconnect runtime errors)
    - [ ] All exceptions logged with context
  config_constants:
    - [ ] MQTT topics, broker config, and adapter modes in constants.py only
    - [ ] No hard-coded values in business logic
  docs:
    - [ ] README up-to-date (usage, architecture, simulation notes)
    - [ ] Patchlog includes all major changes/migrations
    - [ ] All modules have purpose/status/dependency docstrings
  packaging:
    - [ ] requirements.txt/pyproject.toml accurate and minimal
    - [ ] Build scripts (Makefile/setup.py) tested/documented
    - [ ] Package builds/installs cleanly from scratch
  operational:
    - [ ] CLI entrypoint (run_mqtt.py) runs with real/sim adapters
    - [ ] CLI options documented/tested
    - [ ] Logging: info/warning/error levels set and used
  security:
    - [ ] No secrets/credentials in code or config
    - [ ] All dependencies are up-to-date/maintained

dev_action_items:
  - [ ] Refactor simulation_adapter.py: Add BLE disconnect logging, error state simulation
  - [ ] Remove all legacy mocks/shims: mock_bb8.py, mock_adapter.py, etc.
  - [ ] Migrate to pytest harness: Structure tests/, add pytest-mock, CLI targets
  - [ ] Document roll_mode, reverse_flag, known enums (README/type hints)
  - [ ] Gate unused utilities: color_utils.py, calibration.py behind feature flags or raise NotImplementedError

vendor_features_required:
  movements:
    - roll
    - set_speed
    - stop_roll
    - set_heading
    - spin
    - set_stabilization
    - raw_motor
    - reset_aim
    - play_animation
  lights:
    - set_main_led
    - set_back_led
    - fade
    - strobe
  sensors:
    - get_acceleration
    - get_vertical_acceleration
    - get_orientation
    - get_gyroscope
    - get_velocity
    - get_location
    - get_distance
    - get_speed
    - get_heading
    - get_main_led
    - get_back_led
  events:
    - register_event
    - EventType.on_charging
    - EventType.on_not_charging

acceptance_criteria:
  - [ ] All production checklist items are checked
  - [ ] All vendor feature methods implemented or stubbed (with NotImplementedError and docstrings)
  - [ ] CI runs all tests and passes
  - [ ] README and patchlog updated for v1 release
  - [ ] SHA256 manifest matches deployed package

signoff:
  dev: [FILL]
  reviewer: [FILL]
  owner: [FILL]
  date: [FILL]

