# Progress Tracker: Readiness to Launch

## 1. **Ready-to-Run Integration Test Stub (`test_integration_mqtt.py`)**

**Placed in:** `tests/test_integration_mqtt.py`
**Run from project root:**

## 2. **Checklist: All `bb8/command/*` Handlers to Verify**

| Command Topic             | Handler Present? | Controller Dispatch? | Empirically Tested? |
| ------------------------- | ---------------- | -------------------- | ------------------- |
| `bb8/command/move`        | ❌                | ✅                    | ☐                   |
| `bb8/command/stop`        | ❌                | ✅                    | ☐                   |
| `bb8/command/rotate`      | ❌                | ❌                    | ☐                   |
| `bb8/command/led`         | ❌                | ✅                    | ☐                   |
| `bb8/command/diagnostics` | ❌                | ✅                    | ☐                   |
| `bb8/command/test`        | ❌                | ❌                    | ☐                   |

**Instructions:**

* Check each box as you verify:

  1. Handler function is present in `mqtt_handler.py`
  2. Correct dispatch to `controller.py`
  3. Test message produces expected effect or log

---

## 3. **Sample MQTT Test Script (`mqtt_send_test.py`)**

**Place in project root or `/tests`. Run from project root.**

```python
# mqtt_send_test.py
import paho.mqtt.publish as publish

broker = "localhost"
port = 1883

commands = [
    ("bb8/command/test", "integration-ping"),
    ("bb8/command/move", '{"direction": 0, "speed": 50}'),
    ("bb8/command/stop", '{}'),
    ("bb8/command/rotate", '{"angle": 90}'),
    ("bb8/command/led", '{"color": "red"}'),
    ("bb8/command/diagnostics", '{}'),
]

for topic, payload in commands:
    print(f"Publishing to {topic}: {payload}")
    publish.single(topic, payload, hostname=broker, port=port)
```

**Expected:**

* Each message should trigger the corresponding handler (log or action).

---

## 4. **BB8 Setup/Run CLI Commands Log (`BB8_CLI_SETUP_LOG.txt`)**

**Assume these are run from the project root (`ha-sphero-bb8/`).**

```
# 1. Clean/Create Virtual Environment
python3 -m venv .venv
source .venv/bin/activate

# 2. Install requirements
pip install --upgrade pip
pip install -r requirements.txt

# 3. Build wheel (if using setup.py or pyproject.toml)
python setup.py bdist_wheel

# 4. Install the built package
pip install dist/ha_sphero_bb8-*.whl

# 5. Run the MQTT CLI in simulation mode (from project root)
python -m ha_sphero_bb8.run_mqtt --adapter sim

# 6. Run the MQTT CLI in real (hardware) mode (from project root)
python -m ha_sphero_bb8.run_mqtt --adapter real

# 7. Run the integration test (from project root)
python -m tests.test_integration_mqtt

# 8. Publish sample MQTT test commands (from project root)
python mqtt_send_test.py
```

---

### **Input/Expected Output Table**

| Command / Step                                    | Expected Output / State                                      |
| ------------------------------------------------- | ------------------------------------------------------------ |
| `python3 -m venv .venv`                           | `.venv/` folder created                                      |
| `source .venv/bin/activate`                       | Shell prompt shows venv active                               |
| `pip install --upgrade pip`                       | pip upgraded, no errors                                      |
| `pip install -r requirements.txt`                 | All deps install, no errors                                  |
| `python setup.py bdist_wheel`                     | `dist/ha_sphero_bb8-*.whl` created                           |
| `pip install dist/ha_sphero_bb8-*.whl`            | Package installs, no errors                                  |
| `python -m ha_sphero_bb8.run_mqtt --adapter sim`  | MQTT CLI starts, subscribes to `bb8/command/#`, logs running |
| `python -m ha_sphero_bb8.run_mqtt --adapter real` | MQTT CLI starts, attempts hardware connection                |
| `python -m tests.test_integration_mqtt`           | Test publishes/receives, logs "Test message...received"      |
| `python mqtt_send_test.py`                        | Publishes test commands, see logs in CLI for each message    |

---

## **MQTT Lifecycle CLI — What It Means**

A **MQTT lifecycle CLI** is a command-line tool/script that:

* **Starts the MQTT event loop** (connects to broker, maintains connection)
* **Subscribes** to the required MQTT topics (`bb8/command/#`, etc.)
* **Receives and handles** incoming MQTT messages
* **Dispatches** them to the appropriate handler/controller (real or sim)
* **Cleans up/disconnects** gracefully when done or interrupted

In other words: it is the **single authority** for starting, running, and stopping all MQTT-based command handling for Sphero BB-8, both for real hardware and simulation/testing.

---

## **Governance Flag / Readiness Note**

* If any expected command (e.g., `bb8/command/rotate` or `bb8/command/led`) is not implemented or not routed from MQTT to controller, **this must be flagged and resolved** before declaring integration “complete.”
* If your test logs do not show successful round-trip for each command, **do not proceed** to release—raise an issue for immediate attention.
* If your CLI does not launch, connect, and subscribe as documented, **stop and debug** before further development.

---

**Would you like all of these as downloadable files for your project root/tests/ directory?**
**Any additional MQTT commands you want hardwired into the checklist?**

Standing by for artifact delivery or further directives!
