
# ha_sphero_bb8_contextwindow.md

## 🧠 Project Overview
`ha-sphero-bb8` is a modular Home Assistant integration and control framework for the Sphero BB-8 robot. It leverages `spherov2` for BLE communication and selectively incorporates `spheropy` for low-level motor and diagnostics control. The project complies with HESTIA's tiered configuration architecture and targets CLI/MQTT service exposure.

### Primary Goals:
1. Package BB-8 control into a standalone macOS `.app` using `py2app`.
2. Integrate control features into Home Assistant via command-line services and MQTT.
3. Maintain strict architectural and traceability alignment with HESTIA standards.

---

## 📦 Project Components
- **src/ha_sphero_bb8/controller.py** → Centralized command logic abstraction (β-tier)
- **src/ha_sphero_bb8/device_core/** → Extracted motor & diagnostic utilities from `spheropy` (δ-tier)
- **src/ha_sphero_bb8/ble_gateway.py** → Toy discovery and BLE pairing (α-tier)
- **src/ha_sphero_bb8/launch_bb8.py** → CLI entrypoint for macOS App, MQTT trigger wrapper
- **mqtt_handler/** *(planned)* → Exposes high-level actions as HA services (ζ-tier)

### Supplementary Files:
- **pyproject.toml** → Primary build system metadata (PEP 621)
- **setup.py** → Deprecated, replaceable by `pyproject.toml`
- **hatch.toml** → Optional alt-packager; clarify usage
- **entrypoints_plan.yaml** → CLI integration schema
- **refactor_plan.yaml** → Structural roadmap
- **requirements.txt**, **tox.ini**, **Makefile** → Pip/test/build tools
- **vendor/** → Embedded copy of `spherov2` (partial)

---

## 🧩 Build System & Packaging
- Target platform: macOS `.app` via `py2app`
- Ensure reproducibility and PEP 621 compliance
- Audit for deprecated mechanisms (e.g., `pkg_resources`, `distutils`)
- Risk: `setup.py` present; transition recommended

---

## 🏠 Home Assistant Integration
- Command-to-service bridge via CLI + MQTT
- Abstraction layering must respect:
  - `signal_plane_abstraction_001`
  - `tier_integrity_002`
  - `alias_attribute_canonical_tracking_001`
- MQTT actions and CLI triggers must resolve through tiered APIs

---

## 🔄 Integration with `spheropy`
- Motor control and power diagnostics extracted to:
  - `device_core/motor_utils.py`
  - `device_core/voltage_diagnostics.py`
- High-level controller routes all BB-8 actions
- BB-8 pairing retained from `spherov2`

---

## 🗂 HESTIA Tier Assignments
| Tier       | Module/File                   | Role                                |
|------------|-------------------------------|-------------------------------------|
| α (gateway)| `ble_gateway.py`              | BLE discovery and toy acquisition   |
| β (fusion) | `controller.py`               | Unified LED, motor, diag API        |
| δ (core)   | `device_core/*`               | Raw motor & voltage utilities       |
| ζ (service)| `mqtt_handler/` (planned)     | HA service trigger exposure         |

---

## 📌 Recommendations
- Deprecate and remove `setup.py`
- Enforce tier-based file layout for all logic
- Generate `.service.yaml` or automation interfaces from `mqtt_handler`
- All exposed HA actions must wrap controller API, not device_core directly

## ✅ Current Status: v0.2.0-dev1
- Modular structure in progress
- `spheropy` merge in planning stage
- MQTT and HA automation logic pending
