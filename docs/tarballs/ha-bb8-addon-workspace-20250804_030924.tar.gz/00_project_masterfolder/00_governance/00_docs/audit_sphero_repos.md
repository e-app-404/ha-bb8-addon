**Audit:** Analyze and compare two Sphero control libraries for BB‑8:

**Repositories to review:**

- `https://github.com/darin‑costello/spheropy` – Sphero 2.0 Python SDK.
- Your `ha‑sphero‑bb8` project.

---

### 1. Feature extraction: *spheropy*

Based on the README ([github.com][1], [repos.ecosyste.ms][2], [stackoverflow.com][3]), **spheropy** offers:

- Device discovery
- Ping & basic motor commands (e.g., `roll`, `stop`, `boost`)
- LED color control
- Diagnostics: power state, voltage monitoring
- Async sensor data polling
- Collision detection
- Motor raw control & motion timeout settings

### 2. Feature extraction: *ha‑sphero‑bb8*

Your existing integration (from context) includes:

- Bluetooth control via `spherov2`
- Full BB‑8-specific support: LED, rolling, heading
- py2app bundling for macOS
- Planned HA integration via CLI/MQTT endpoints
- Legacy and build scaffolding (`setup.py`, `hatch.toml`, etc.)

### 3. **Overlap matrix**

| Capability          | spheropy       | ha‑sphero‑bb8             |
| ------------------- | -------------- | ------------------------- |
| Device discovery    | ✅              | ✅ (via spherov2)          |
| Roll & stop         | ✅              | ✅                         |
| Heading control     | (via roll API) | ✅                         |
| LED control         | ✅              | ✅                         |
| Raw motor commands  | ✅              | ❌ (delegated to spherov2) |
| Voltage diagnostics | ✅              | ✅                         |
| Sensor data polling | ✅ (async)      | ✅ (BLE streaming)         |
| Collision detection | ✅              | ✅ (via spherov2)          |

### 4. **Synergy & gaps**

- **Redundancy**: Core controls (roll, color, ping) are duplicated.
- **Gaps in spheropy**: No BLE support, no macOS packaging, and no HA integration logic.
- **Strengths in spheropy**: Simplified raw motor access and diagnostics could extend HA control granularity.
- **Strengths in ha‑sphero‑bb8**: Mature BLE handling, packaging, and HA service scaffolding.

### 5. **Opportunities**

- *Extract raw motor/voltage utilities* from spheropy to enrich `ha-sphero-bb8` diagnostics.
- Use spheropy code as lightweight BLE stub for non‑BB‑8 Sphero bots.
- Consolidate duplicated logic: choose `spherov2` or `spheropy` APIs consistently.
- Consider modularizing: `device_core`, `motor_tools`, `ha_bridge`.

---

## ✅ Recommendation summary

- **Merge**: Incorporate spheropy’s motor & diagnostics utilities into a `device_core` submodule of `ha-sphero-bb8`.
- **Deprecate duplication**: Remove redundant discovery, roll, LED code in favor of single implementation.
- **Extend**: Add spheropy-derived diagnostics into macOS app and HA service metadata.
- **Package**: Ensure all new code conforms to HESTIA tier and build standards.

Let me know if you'd like a draft of the merged device-core module or HESTIA-compliant packaging state machine next.

[1]: https://github.com/darin-costello/spheropy?utm_source=chatgpt.com "darin-costello/spheropy: A Python SDK for Sphero - GitHub"
[2]: https://repos.ecosyste.ms/topics/sphero?utm_source=chatgpt.com "sphero | Topic | Ecosyste.ms: Repos"
[3]: https://stackoverflow.com/questions/54057260/has-sphero-broken-compatibility-with-python-sdks-when-introducing-bolt?utm_source=chatgpt.com "Has Sphero broken compatibility with Python SDKs when ..."

---

## Impact Evaluation Response

```yaml
# 📊 Evaluation: Impact of spheropy audit on ha-sphero-bb8

impact_scope:
  affected_subsystems:
    - ble_gateway
    - bb8_control
    - controller (planned)
    - launch_bb8
    - diagnostics (unimplemented)
    - HESTIA mqtt_handler bridge (planned)

summary:
  - ha-sphero-bb8 currently delegates nearly all BLE and control logic to spherov2.
  - `spheropy` provides direct motor control and diagnostics not exposed in spherov2.
  - `spheropy` lacks packaging, integration architecture, and BB-8 specificity.
  - Merging selected `spheropy` capabilities into a modular `device_core` would enhance control fidelity and sensor visibility.

recommendations:
  merge_targets:
    - source: spheropy.commands.motor
      dest: src/ha_sphero_bb8/device_core/motor_utils.py
      rationale: Expose motor timeout and boost logic to HA actions
    - source: spheropy.commands.power
      dest: src/ha_sphero_bb8/device_core/voltage_diagnostics.py
      rationale: Publish battery and charging state via MQTT

  integration_changes:
    - remove duplicate roll/led logic from `bb8_control.py` if exact behavior matches
    - retain spherov2 BB-8 BLE scan routines for physical pairing
    - route high-level motion commands through unified `controller` class

  packaging_todos:
    - audit spheropy imports for namespace collision (e.g. `spherov2.toy` vs `spheropy.toy`)
    - ensure any integrated modules conform to HESTIA's tiered layout: ['α: gateway', 'β: fusion', 'δ: device-core']

HESTIA_alignment:
  tier_assignments:
    α_gateway: ble_gateway → BLE pairing and toy acquisition
    β_fusion: controller → unify diagnostics, motion, LED, power into consistent API
    δ_core: device_core → embed low-level control extracted from spheropy
    ζ_services: mqtt_handler (planned) → expose core routines as HA triggers
  migration_note: Avoid direct use of `spheropy` classes in user-facing logic. Use as device-core utility layer only.

risk_profile:
  duplication: medium
  collision: low (due to non-overlapping packaging)
  maintenance: increased short-term, lower long-term (fewer upstream breakages)
  confidence_metrics:
    structural: 0.93
    operational: 0.89
    semantic: 0.95

next_steps:
  - [ ] Create `src/ha_sphero_bb8/device_core/` and placeholder modules
  - [ ] Extract and stub `motor_utils.py`, `voltage_diagnostics.py` from spheropy
  - [ ] Wrap extracted logic in HESTIA-compliant APIs
  - [ ] Integrate into `controller.py` and expose via `launch_bb8`
  - [ ] Harden runtime tests for `roll + boost`, `battery state`, `raw motor tick`
```
