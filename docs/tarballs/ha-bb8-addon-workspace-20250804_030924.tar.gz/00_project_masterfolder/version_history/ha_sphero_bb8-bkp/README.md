ha_sphero_bb8/
├── pyproject.toml
├── setup.py
├── Makefile
├── requirements.txt
├── README.md                  # need to generate
├── spherovenv/                # venv, ignored from packaging
├── src/
│   └── ha_sphero_bb8/
│       ├── __init__.py        # new (empty)
│       ├── bb8_control.py
│       ├── ble_gateway.py
│       ├── controller.py      # placeholder
│       ├── integration_stub.py
│       ├── launch_bb8.py
│       ├── mqtt_handler.py
│       └── run_ble.py
├── tests/
│   ├── test_bb8_control.py
│   ├── test_ble_gateway.py
│   └── test_integration_stub.py
├── docs/
│   ├── ble_manifest.yaml
│   └── command_registry.yaml
    └── [text](docs/ble_manifest.yaml) [text](docs/changelog_phase0_phase1.yaml) [text](docs/command_registry.yaml) [text](docs/integration_manifest.yaml) [text](docs/phase2_entrypoints.yaml)
├── meta/
│   └── pyproject_manifest.yaml
    └── [text](meta/ha_sphero_bb8_script_audit_manifest.yaml) [text](meta/pyproject_manifest.yaml) [text](meta/script_audit_manifest.yaml) [text](meta/test_manifest.yaml) [text](meta/wheel_manifest.yaml)
├── logs/
│   └── spherov2_problem_report.log
├── governance/
    └──  [text](governance/ha_sphero_bb8_context_hestia-conversation.md) [text](governance/ha_sphero_bb8_contextwindow.md) [text](governance/ha_sphero_bb8_validation_matrix.md) [text](governance/tree_ha_sphero_bb8.md) [text](governance/spherov2.py-main.zip)
