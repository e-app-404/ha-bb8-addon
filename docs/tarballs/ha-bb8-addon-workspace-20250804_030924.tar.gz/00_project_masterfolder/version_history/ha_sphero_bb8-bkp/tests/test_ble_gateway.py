from spherov2 import scanner
from spherov2.sphero_edu import SpheroEduAPI

async def run():
    toy = await scanner.find_toy()
    async with SpheroEduAPI(toy) as api:
        await api.roll(0, 100, 2)

if __name__ == "__main__":
    import asyncio
    asyncio.run(run())
