# tests/test_bb8_control.py
import unittest
from .bb8_control import Bb8Controller
import subprocess
import sys

class TestBb8Controller(unittest.TestCase):
    def test_simulate_method(self):
        controller = Bb8Controller()
        try:
            controller.simulate()
        except Exception as e:
            self.fail(f"simulate() raised an exception: {e}")

    def test_cli_noop(self):
        result = subprocess.run(
            [sys.executable, "ha_sphero_bb8.launch_bb8", "--noop"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        self.assertIn("SIMULATION", result.stdout.upper())
        self.assertEqual(result.returncode, 0)

if __name__ == "__main__":
    unittest.main()
