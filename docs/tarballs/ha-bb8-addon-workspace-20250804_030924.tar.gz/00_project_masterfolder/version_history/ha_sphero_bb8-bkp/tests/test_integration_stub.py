# tests/test_integration_stub.py
import unittest
from .integration_stub import BB8ServiceStub

class TestIntegrationStub(unittest.TestCase):
    def setUp(self):
        self.stub = BB8ServiceStub()

    def test_noop_returns_correct_status(self):
        result = self.stub.noop()
        self.assertEqual(result["status"], "noop")

    def test_start_returns_started_status(self):
        result = self.stub.start(payload={"mode": "test"})
        self.assertEqual(result["status"], "started")
        self.assertEqual(result["payload"]["mode"], "test")

    def test_stop_transitions_correctly(self):
        self.stub.start()
        result = self.stub.stop()
        self.assertEqual(result["status"], "stopped")
        self.assertEqual(self.stub.status, "stopped")

if __name__ == "__main__":
    unittest.main()
