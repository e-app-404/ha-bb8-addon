# src/ha_sphero_bb8/integration_stub.py

class BB8ServiceStub:
    def __init__(self):
        self.status = "initialized"

    def start(self, payload=None):
        print("[STUB] BB-8 would start control sequence.")
        self.status = "started"
        return {"status": self.status, "payload": payload}

    def stop(self, payload=None):
        print("[STUB] BB-8 would stop activity.")
        self.status = "stopped"
        return {"status": self.status, "payload": payload}

    def noop(self):
        print("[STUB] Noop triggered — this is a dry-run.")
        return {"status": "noop"}
