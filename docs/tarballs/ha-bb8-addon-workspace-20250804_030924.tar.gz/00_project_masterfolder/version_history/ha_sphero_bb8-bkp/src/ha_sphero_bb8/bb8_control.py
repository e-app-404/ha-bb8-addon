# src/bb8_control.py
# pyright: reportUnknownMemberType=false

from .ble_gateway import connect_bb8
from spherov2.sphero_edu import SpheroEduAPI

class Bb8Controller:
    def __init__(self):
        self.toy = None
        self.api = None

    def run(self):
        print("[INFO] Attempting BB-8 connection (BLE_ENABLED gated)...")
        self.toy = connect_bb8()
        if not self.toy:
            print("[INFO] Skipping BLE — run in simulation mode")
            self.simulate()
            return

        with SpheroEduAPI(self.toy) as api:
            self.api = api
            api.set_main_led(255, 1, 0)
            api.roll(0, 50, 2.0)  # duration explicitly passed
            api.wait(2)
            api.stop()

    def simulate(self):
        print("[SIMULATION] BB-8 would roll forward, set LED to red, then stop.")
