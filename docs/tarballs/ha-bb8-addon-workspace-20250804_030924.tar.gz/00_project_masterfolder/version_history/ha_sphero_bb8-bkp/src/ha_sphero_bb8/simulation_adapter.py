# src/ha_sphero_bb8/simulation_adapter.py
"""
BLE Simulation Adapter for Development (α-tier)
Phase 1: Simulation fallback adapter for BLE logic path parity

Provides complete simulation of BB-8 BLE functionality for development:
- Mock BB-8 device with realistic behavior
- Simulated motor control responses
- Realistic power consumption modeling  
- Development-safe testing environment

HESTIA Compliance:
- Tier: α (gateway simulation)
- Replaces: Live BLE hardware for development
- Maintains: Same API surface as real BLE gateway
- Enables: Hardware-free development and testing
"""

import logging
import time
import random
import threading
from typing import Optional, Dict, Any, Callable
from dataclasses import dataclass
from enum import Enum
import json
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class SimulationMode(Enum):
    """Simulation behavior modes"""
    REALISTIC = "realistic"      # Realistic delays and responses
    FAST = "fast"               # Minimal delays for rapid testing
    FAILURE = "failure"         # Simulate various failure conditions
    PERFECT = "perfect"         # Always successful responses

@dataclass
class SimulatedDeviceState:
    """State tracking for simulated BB-8 device"""
    connected: bool = True
    position_x: float = 0.0
    position_y: float = 0.0
    heading: float = 0.0
    speed: int = 0
    led_color: tuple = (0, 0, 0)
    battery_voltage: float = 7.4
    battery_percentage: int = 85
    temperature: float = 22.0
    last_command_time: float = 0.0
    motor_left_speed: int = 0
    motor_right_speed: int = 0
    boost_active: bool = False
    charging: bool = False

class MockBB8Device:
    """
    Mock BB-8 device that simulates realistic behavior
    
    Maintains state and responds to commands like a real BB-8,
    enabling full development workflow without hardware.
    """
    
    def __init__(self, device_name: str = "BB-8-SIM", simulation_mode: SimulationMode = SimulationMode.REALISTIC):
        self.device_name = device_name
        self.simulation_mode = simulation_mode
        self.state = SimulatedDeviceState()
        self.logger = logging.getLogger(f"{__name__}.{device_name}")
        
        # Realistic constraints
        self.max_speed = 255
        self.max_heading = 359.9
        self.battery_drain_rate = 0.1  # % per minute of operation
        
        # Command history for debugging
        self.command_history = []
        self.max_history_size = 100
        
        # Background simulation thread
        self._simulation_active = True
        self._simulation_thread = threading.Thread(target=self._background_simulation, daemon=True)
        self._simulation_thread.start()
        
        self.logger.info(f"Mock BB-8 device '{device_name}' initialized in {simulation_mode.value} mode")
    
    def roll(self, speed: int, heading: int, duration: float = None) -> Dict[str, Any]:
        """Simulate roll command with realistic physics"""
        command_start = time.time()
        
        # Validate parameters like real device would
        if not (0 <= speed <= self.max_speed):
            return {
                "success": False,
                "error": f"Speed {speed} out of range [0, {self.max_speed}]",
                "timestamp": command_start
            }
        
        if not (0 <= heading <= self.max_heading):
            heading = heading % 360
        
        # Record command
        command = {
            "type": "roll",
            "speed": speed,
            "heading": heading,
            "duration": duration,
            "timestamp": command_start
        }
        self._add_command_history(command)
        
        # Simulate execution delay based on mode
        execution_delay = self._get_execution_delay("roll")
        if execution_delay > 0:
            time.sleep(execution_delay)
        
        # Update simulated state
        self.state.speed = speed
        self.state.heading = heading
        self.state.last_command_time = time.time()
        
        # Simulate realistic position change
        if speed > 0:
            self._update_position(speed, heading, duration or 1.0)
        
        # Simulate battery drain
        self._drain_battery(speed, duration or 1.0)
        
        result = {
            "success": True,
            "command": "roll",
            "parameters": {"speed": speed, "heading": heading, "duration": duration},
            "execution_time": time.time() - command_start,
            "device_state": self._get_current_state(),
            "timestamp": command_start
        }
        
        self.logger.info(f"[SIMULATION] Roll executed: speed={speed}, heading={heading}")
        return result
    
    def set_main_led(self, r: int, g: int, b: int) -> Dict[str, Any]:
        """Simulate LED color change"""
        command_start = time.time()
        
        # Validate RGB values
        rgb_values = [r, g, b]
        if not all(0 <= val <= 255 for val in rgb_values):
            return {
                "success": False,
                "error": f"RGB values must be 0-255, got ({r}, {g}, {b})",
                "timestamp": command_start
            }
        
        # Record command
        command = {
            "type": "set_main_led",
            "r": r, "g": g, "b": b,
            "timestamp": command_start
        }
        self._add_command_history(command)
        
        # Simulate execution
        execution_delay = self._get_execution_delay("led")
        if execution_delay > 0:
            time.sleep(execution_delay)
        
        # Update state
        self.state.led_color = (r, g, b)
        self.state.last_command_time = time.time()
        
        result = {
            "success": True,
            "command": "set_main_led",
            "parameters": {"r": r, "g": g, "b": b},
            "execution_time": time.time() - command_start,
            "device_state": self._get_current_state(),
            "timestamp": command_start
        }
        
        self.logger.info(f"[SIMULATION] LED set to RGB({r}, {g}, {b})")
        return result
    
    def stop(self) -> Dict[str, Any]:
        """Simulate stop command"""
        command_start = time.time()
        
        command = {
            "type": "stop",
            "timestamp": command_start
        }
        self._add_command_history(command)
        
        # Simulate braking delay
        execution_delay = self._get_execution_delay("stop")
        if execution_delay > 0:
            time.sleep(execution_delay)
        
        # Update state
        self.state.speed = 0
        self.state.motor_left_speed = 0
        self.state.motor_right_speed = 0
        self.state.last_command_time = time.time()
        
        result = {
            "success": True,
            "command": "stop",
            "execution_time": time.time() - command_start,
            "device_state": self._get_current_state(),
            "timestamp": command_start
        }
        
        self.logger.info("[SIMULATION] BB-8 stopped")
        return result
    
    def set_raw_motors(self, left_speed: int, right_speed: int, duration: float = None) -> Dict[str, Any]:
        """Simulate raw motor control"""
        command_start = time.time()
        
        # Validate motor speeds
        if not (-255 <= left_speed <= 255) or not (-255 <= right_speed <= 255):
            return {
                "success": False,
                "error": f"Motor speeds must be -255 to 255, got L={left_speed}, R={right_speed}",
                "timestamp": command_start
            }
        
        command = {
            "type": "set_raw_motors",
            "left_speed": left_speed,
            "right_speed": right_speed,
            "duration": duration,
            "timestamp": command_start
        }
        self._add_command_history(command)
        
        execution_delay = self._get_execution_delay("motor")
        if execution_delay > 0:
            time.sleep(execution_delay)
        
        # Update motor state
        self.state.motor_left_speed = left_speed
        self.state.motor_right_speed = right_speed
        self.state.last_command_time = time.time()
        
        # Calculate effective speed and heading from differential
        effective_speed = (abs(left_speed) + abs(right_speed)) // 2
        if left_speed != right_speed:
            # Simulate turning based on speed differential
            turn_rate = (right_speed - left_speed) / 255.0  # Normalized turn rate
            self.state.heading = (self.state.heading + turn_rate * 10) % 360
        
        self.state.speed = effective_speed
        
        result = {
            "success": True,
            "command": "set_raw_motors",
            "parameters": {
                "left_speed": left_speed,
                "right_speed": right_speed,
                "duration": duration
            },
            "execution_time": time.time() - command_start,
            "device_state": self._get_current_state(),
            "timestamp": command_start
        }
        
        self.logger.info(f"[SIMULATION] Raw motors: L={left_speed}, R={right_speed}")
        return result
    
    def get_battery_voltage(self) -> float:
        """Get simulated battery voltage"""
        return self.state.battery_voltage
    
    def get_battery_percentage(self) -> int:
        """Get simulated battery percentage"""
        return self.state.battery_percentage
    
    def get_power_state(self) -> Dict[str, Any]:
        """Get comprehensive power state"""
        return {
            "voltage": self.state.battery_voltage,
            "percentage": self.state.battery_percentage,
            "charging": self.state.charging,
            "temperature": self.state.temperature,
            "state": "charging" if self.state.charging else "discharging"
        }
    
    def disconnect(self):
        """Simulate device disconnection"""
        self.state.connected = False
        self._simulation_active = False
        self.logger.info(f"[SIMULATION] Mock BB-8 '{self.device_name}' disconnected")
    
    def _get_current_state(self) -> Dict[str, Any]:
        """Get complete current device state"""
        return {
            "connected": self.state.connected,
            "position": {"x": self.state.position_x, "y": self.state.position_y},
            "heading": self.state.heading,
            "speed": self.state.speed,
            "motors": {
                "left_speed": self.state.motor_left_speed,
                "right_speed": self.state.motor_right_speed
            },
            "led_color": self.state.led_color,
            "battery": {
                "voltage": self.state.battery_voltage,
                "percentage": self.state.battery_percentage,
                "charging": self.state.charging
            },
            "temperature": self.state.temperature,
            "boost_active": self.state.boost_active,
            "last_command": self.state.last_command_time
        }
    
    def _get_execution_delay(self, command_type: str) -> float:
        """Get realistic execution delay based on simulation mode"""
        if self.simulation_mode == SimulationMode.FAST:
            return 0.0
        elif self.simulation_mode == SimulationMode.REALISTIC:
            delays = {
                "roll": 0.1,
                "led": 0.05,
                "stop": 0.2,
                "motor": 0.08
            }
            return delays.get(command_type, 0.1)
        elif self.simulation_mode == SimulationMode.PERFECT:
            return 0.05  # Minimal but not instant
        else:  # FAILURE mode
            # Simulate occasional slow responses
            return random.uniform(0.1, 1.0)
    
    def _update_position(self, speed: int, heading: float, duration: float):
        """Update simulated position based on movement"""
        # Convert speed and heading to position change
        speed_factor = speed / 255.0  # Normalize speed
        distance = speed_factor * duration * 10  # Arbitrary units
        
        # Convert heading to radians
        import math
        heading_rad = math.radians(heading)
        
        # Update position
        self.state.position_x += distance * math.cos(heading_rad)
        self.state.position_y += distance * math.sin(heading_rad)
    
    def _drain_battery(self, speed: int, duration: float):
        """Simulate realistic battery drain"""
        if speed > 0:
            # Higher speed = more drain
            drain_factor = (speed / 255.0) * self.battery_drain_rate
            drain_amount = drain_factor * (duration / 60.0)  # Convert to minutes
            
            self.state.battery_percentage = max(0, int(self.state.battery_percentage - drain_amount))
            
            # Update voltage based on percentage (simplified)
            voltage_range = 8.4 - 6.0  # Max to min voltage
            voltage_offset = (self.state.battery_percentage / 100.0) * voltage_range
            self.state.battery_voltage = 6.0 + voltage_offset
    
    def _add_command_history(self, command: Dict[str, Any]):
        """Add command to history for debugging"""
        self.command_history.append(command)
        if len(self.command_history) > self.max_history_size:
            self.command_history.pop(0)
    
    def _background_simulation(self):
        """Background thread for ongoing simulation"""
        while self._simulation_active:
            try:
                # Simulate gradual battery drain even when idle
                if self.state.battery_percentage > 0 and not self.state.charging:
                    # Very slow idle drain
                    idle_drain = 0.01  # 0.01% per minute idle
                    self.state.battery_percentage = max(0, int(self.state.battery_percentage - idle_drain))
                
                # Simulate temperature variations
                self.state.temperature += random.uniform(-0.1, 0.1)
                self.state.temperature = max(15.0, min(35.0, self.state.temperature))
                
                # Sleep for simulation update interval
                time.sleep(60)  # Update every minute
                
            except Exception as e:
                self.logger.error(f"Background simulation error: {e}")
                time.sleep(5)

class SimulationAdapter:
    """
    BLE Simulation Adapter that provides complete BLE functionality simulation
    
    Replaces real BLE gateway for development environments while maintaining
    identical API surface for seamless testing.
    """
    
    def __init__(self, simulation_mode: SimulationMode = SimulationMode.REALISTIC):
        self.simulation_mode = simulation_mode
        self.logger = logging.getLogger(f"{__name__}.SimulationAdapter")
        self.mock_device: Optional[MockBB8Device] = None
        self.scan_history = []
        
        self.logger.info(f"BLE Simulation Adapter initialized in {simulation_mode.value} mode")
    
    def scan_for_bb8(self, timeout: int = 10) -> Dict[str, Any]:
        """Simulate BB-8 device scanning"""
        scan_start = time.time()
        
        # Simulate scanning delay
        if self.simulation_mode == SimulationMode.REALISTIC:
            scan_delay = random.uniform(0.5, 2.0)
            time.sleep(scan_delay)
        elif self.simulation_mode == SimulationMode.FAILURE:
            # Simulate scan failures occasionally
            if random.random() < 0.3:  # 30% failure rate
                return {
                    "success": False,
                    "error": "Simulated scan timeout",
                    "devices_found": 0,
                    "scan_duration": time.time() - scan_start
                }
        
        # Create mock device
        self.mock_device = MockBB8Device("BB-8-SIM-001", self.simulation_mode)
        
        scan_result = {
            "success": True,
            "devices_found": 1,
            "device": self.mock_device,
            "device_name": self.mock_device.device_name,
            "scan_duration": time.time() - scan_start,
            "simulation_mode": self.simulation_mode.value,
            "timestamp": scan_start
        }
        
        self.scan_history.append(scan_result)
        self.logger.info(f"[SIMULATION] BB-8 scan completed: found {scan_result['devices_found']} device(s)")
        
        return scan_result
    
    def get_simulation_status(self) -> Dict[str, Any]:
        """Get comprehensive simulation status"""
        status = {
            "adapter_type": "simulation",
            "simulation_mode": self.simulation_mode.value,
            "device_connected": self.mock_device is not None and self.mock_device.state.connected,
            "scans_performed": len(self.scan_history),
            "last_scan": self.scan_history[-1] if self.scan_history else None
        }
        
        if self.mock_device:
            status["device_status"] = self.mock_device._get_current_state()
            status["command_history_size"] = len(self.mock_device.command_history)
        
        return status
    
    def get_command_history(self) -> List[Dict[str, Any]]:
        """Get command execution history for debugging"""
        if self.mock_device:
            return self.mock_device.command_history.copy()
        return []
    
    def reset_simulation(self):
        """Reset simulation state for fresh testing"""
        if self.mock_device:
            self.mock_device.disconnect()
        
        self.mock_device = None
        self.scan_history.clear()
        
        self.logger.info("Simulation adapter reset")

# Convenience functions for integration
def create_simulation_bb8(simulation_mode: SimulationMode = SimulationMode.REALISTIC) -> MockBB8Device:
    """Create a mock BB-8 device for direct testing"""
    return MockBB8Device("BB-8-Direct", simulation_mode)

def get_simulation_adapter(simulation_mode: SimulationMode = SimulationMode.REALISTIC) -> SimulationAdapter:
    """Get a configured simulation adapter"""
    return SimulationAdapter(simulation_mode)

# Testing utilities
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("Testing BLE Simulation Adapter...")
    
    # Test adapter
    adapter = SimulationAdapter(SimulationMode.REALISTIC)
    scan_result = adapter.scan_for_bb8()
    
    if scan_result["success"]:
        device = scan_result["device"]
        
        # Test basic commands
        print("\n--- Testing Commands ---")
        roll_result = device.roll(100, 90, 2.0)
        print(f"Roll result: {roll_result['success']}")
        
        led_result = device.set_main_led(255, 0, 0)
        print(f"LED result: {led_result['success']}")
        
        stop_result = device.stop()
        print(f"Stop result: {stop_result['success']}")
        
        # Show final state
        print(f"\n--- Final Device State ---")
        final_state = device._get_current_state()
        print(json.dumps(final_state, indent=2))
        
        # Show simulation status
        print(f"\n--- Simulation Status ---")
        sim_status = adapter.get_simulation_status()
        print(json.dumps(sim_status, indent=2))
        
        device.disconnect()
    else:
        print(f"Scan failed: {scan_result['error']}")
