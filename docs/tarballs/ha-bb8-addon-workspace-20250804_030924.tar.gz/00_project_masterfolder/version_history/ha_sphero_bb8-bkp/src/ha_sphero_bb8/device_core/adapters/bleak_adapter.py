class BleakAdapter:
    def scan(self): return []
    def connect(self, identifier): return True
    def disconnect(self): return True
    def is_connected(self): return True
    def roll(self, heading, speed): pass
    def set_main_led(self, r, g, b): pass
    def stop(self): pass
    def get_battery_voltage(self): return 7.4
    def get_battery_percentage(self): return 95
