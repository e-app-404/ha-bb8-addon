# motor_utils.py

def roll(heading: int, speed: int):
    """Send roll command to BB-8."""
    raise NotImplementedError

def boost(duration: float):
    """Send boost command for specified duration."""
    raise NotImplementedError

def drive_to(x: float, y: float):
    """Calculate path and move BB-8 to coordinate (x, y)."""
    raise NotImplementedError
