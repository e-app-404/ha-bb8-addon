# run_ble.py

from .ble_gateway import connect_bb8, BLE_ENABLED

def main():
    print(f"[BLE TEST] BLE_ENABLED is set to {BLE_ENABLED}")
    if not BLE_ENABLED:
        print("[ABORT] BLE is disabled. Enable BLE_ENABLED in ble_gateway.py to proceed.")
        return

    try:
        toy = connect_bb8(timeout=10)
        if toy:
            print(f"[SUCCESS] Connected to BB-8: {toy}")
        else:
            print("[TIMEOUT] No BB-8 found — is it powered on and nearby?")
    except Exception as e:
        print(f"[ERROR] Exception occurred: {e}")

if __name__ == "__main__":
    main()
