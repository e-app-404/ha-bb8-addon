# calibration.py

def start_calibration():
    """Start BB-8 orientation calibration."""
    raise NotImplementedError

def stop_calibration():
    """Stop calibration and fix heading."""
    raise NotImplementedError
