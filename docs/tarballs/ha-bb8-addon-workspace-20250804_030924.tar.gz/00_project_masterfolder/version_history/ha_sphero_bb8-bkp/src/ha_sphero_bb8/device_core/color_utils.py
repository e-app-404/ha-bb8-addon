# color_utils.py

def set_led(r: int, g: int, b: int):
    """Set BB-8's main LED color."""
    raise NotImplementedError

def pulse_color(color: tuple):
    """Pulse LED with specified RGB color."""
    raise NotImplementedError

def rainbow_cycle():
    """Cycle through colors in rainbow pattern."""
    raise NotImplementedError
