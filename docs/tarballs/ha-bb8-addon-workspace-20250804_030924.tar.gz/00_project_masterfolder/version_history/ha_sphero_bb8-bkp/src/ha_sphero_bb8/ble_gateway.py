# ble_gateway.py — HESTIA α-tier compliant with adapter injection and runtime diagnostics

import os
import platform
import logging
import time
import traceback
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

# Graceful import handling for BLE dependencies
try:
    from spherov2.scanner import find_BB8
    from spherov2.toy.bb8 import BB8
    SPHEROV2_AVAILABLE = True
except ImportError as e:
    SPHEROV2_AVAILABLE = False
    BB8 = None
    logging.getLogger(__name__).warning(f"spherov2 not available: {e}")

try:
    import bleak
    BLEAK_AVAILABLE = True
except ImportError as e:
    BLEAK_AVAILABLE = False
    logging.getLogger(__name__).warning(f"bleak not available: {e}")

from .device_core.adapters.bleak_adapter import BleakAdapter
from .device_core.adapters.mock_adapter import MockBLEAdapter

logger = logging.getLogger(__name__)

class BLEStatus(Enum):
    """BLE connection status enumeration"""
    UNKNOWN = "unknown"
    DISABLED = "disabled"
    SCANNING = "scanning"
    CONNECTED = "connected"
    FAILED = "failed"
    TIMEOUT = "timeout"
    PERMISSION_DENIED = "permission_denied"
    SIMULATION = "simulation"

@dataclass
class BLEScanResult:
    """BLE scan operation result with comprehensive diagnostics"""
    status: BLEStatus
    devices_found: int = 0
    scan_duration_ms: float = 0.0
    error_message: Optional[str] = None
    trace_id: Optional[str] = None
    adapter_type: str = "unknown"
    platform_info: str = platform.platform()

USE_SIMULATION = os.getenv("BB8_BLE_MODE", "real").lower() != "real"
Adapter = MockBLEAdapter if USE_SIMULATION else BleakAdapter
adapter = Adapter()

logger.info(f"BLE Gateway initialized with adapter: {'Mock' if USE_SIMULATION else 'Bleak'}")

def scan_devices() -> BLEScanResult:
    """Perform a BLE scan and return a diagnostic result object"""
    start = time.perf_counter()
    trace_id = f"scan-{int(start * 1000)}"
    try:
        devices = adapter.scan()
        return BLEScanResult(
            status=BLEStatus.SCANNING,
            devices_found=len(devices),
            scan_duration_ms=(time.perf_counter() - start) * 1000,
            trace_id=trace_id,
            adapter_type='mock' if USE_SIMULATION else 'bleak'
        )
    except Exception as e:
        logger.error(f"[BLE] Scan failed: {e}\n{traceback.format_exc()}")
        return BLEScanResult(
            status=BLEStatus.FAILED,
            error_message=str(e),
            trace_id=trace_id,
            scan_duration_ms=(time.perf_counter() - start) * 1000,
            adapter_type='mock' if USE_SIMULATION else 'bleak'
        )

def connect_device(identifier: str) -> bool:
    """Connect to a BLE device by identifier"""
    try:
        return adapter.connect(identifier)
    except Exception as e:
        logger.error(f"[BLE] Connection failed: {e}")
        return False

def disconnect_device():
    """Disconnect the active BLE session if connected"""
    try:
        return adapter.disconnect()
    except Exception as e:
        logger.warning(f"[BLE] Disconnection failed: {e}")
        return False

def is_connected() -> bool:
    """Return whether BLE is currently connected"""
    try:
        return adapter.is_connected()
    except Exception as e:
        logger.debug(f"[BLE] is_connected check failed: {e}")
        return False

def get_ble_status() -> Dict[str, Any]:
    """Expose current BLE status for diagnostics and MQTT reporting"""
    return {
        "mode": "simulation" if USE_SIMULATION else "real",
        "connected": is_connected(),
        "platform": platform.system(),
        "spherov2": SPHEROV2_AVAILABLE,
        "bleak": BLEAK_AVAILABLE
    }

def _check_macos_permissions() -> bool:
    """Stubbed macOS BLE TCC permission check"""
    if platform.system() == "Darwin":
        logger.info("TCC permission check not implemented — assumed granted for dev mode.")
        return True
    return True
