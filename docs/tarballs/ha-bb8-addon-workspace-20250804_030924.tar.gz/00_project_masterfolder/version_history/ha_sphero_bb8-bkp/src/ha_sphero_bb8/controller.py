from typing import Protocol

class BB8Like(Protocol):
    def roll(self, heading: int, speed: int): ...
    def stop(self): ...
    def set_main_led(self, r: int, g: int, b: int): ...
    def get_battery_voltage(self) -> float: ...
    def get_battery_percentage(self) -> int: ...

# src/ha_sphero_bb8/controller.py
"""
Unified BB-8 Controller Integration (β-tier)
Phase 1: Complete integration of BLE, device core, and simulation layers

Provides:
- Unified API abstracting BLE vs simulation modes
- Device core motor and voltage utilities integration
- Comprehensive diagnostics and status reporting
- ζ-tier MQTT preparation with structured payloads

HESTIA Compliance:
- Tier: β (fusion - unified control interface)
- Consumes: α-tier BLE gateway, δ-tier device core utilities
- Exposes: Clean control API to ζ-tier services and CLI
- Abstracts: Hardware complexity behind consistent interface
"""

import logging
import time
from typing import Optional, Dict, Any, Union
from dataclasses import dataclass
from enum import Enum

# Import enhanced Phase 1 components
from .device_core.motor_utils import EnhancedMotorControl, MotorCommandResult
from .device_core.voltage_diagnostics import VoltageMonitor, PowerDiagnostics
from .simulation_adapter import SimulationAdapter, SimulationMode, MockBB8Device

logger = logging.getLogger(__name__)

class ControllerMode(Enum):
    """Controller operation modes"""
    HARDWARE = "hardware"       # Live BLE hardware
    SIMULATION = "simulation"   # Complete simulation
    HYBRID = "hybrid"           # Hardware with simulation fallback
    OFFLINE = "offline"         # No device control

@dataclass
class ControllerStatus:
    """Complete controller status information"""
    mode: ControllerMode
    device_connected: bool
    ble_status: str
    last_command: Optional[str] = None
    command_count: int = 0
    error_count: int = 0
    uptime: float = 0.0
    features_available: Dict[str, bool] = None

class BB8Controller:
    """
    Unified BB-8 Controller
    
    Provides a single, consistent interface for BB-8 control that abstracts
    hardware vs simulation modes and integrates all device capabilities.
    """
    
    def __init__(self, 
                 mode: ControllerMode = ControllerMode.HYBRID,
                 simulation_mode: SimulationMode = SimulationMode.REALISTIC):
        
        self.mode = mode
        self.simulation_mode = simulation_mode
        self.logger = logging.getLogger(f"{__name__}.BB8Controller")
        
        # Core components
        self.ble_gateway: Optional[BleGateway] = None
        self.simulation_adapter: Optional[SimulationAdapter] = None
        self.device = None  # Current active device (real or simulated)
        
        # Enhanced capabilities
        self.motor_control: Optional[EnhancedMotorControl] = None
        self.voltage_monitor: Optional[VoltageMonitor] = None
        
        # Status tracking
        self.start_time = time.time()
        self.command_count = 0
        self.error_count = 0
        self.last_command = None
        self.device_connected = False
        
        # Initialize based on mode
        self._initialize_controller()
    
    def _initialize_controller(self):
        """Initialize controller based on operation mode"""
        self.logger.info(f"Initializing BB8Controller in {self.mode.value} mode")
        
        if self.mode in [ControllerMode.HARDWARE, ControllerMode.HYBRID]:
            # Initialize BLE gateway
            self.ble_gateway = BleGateway(simulation_mode=False)
        
        if self.mode in [ControllerMode.SIMULATION, ControllerMode.HYBRID]:
            # Initialize simulation adapter
            self.simulation_adapter = SimulationAdapter(self.simulation_mode)
        
        self.logger.info("BB8Controller initialization complete")
    
    def connect(self, timeout: int = 10) -> Dict[str, Any]:
        """
        Connect to BB-8 device using appropriate method
        
        Args:
            timeout: Connection timeout in seconds
            
        Returns:
            Connection result with status and diagnostics
        """
        connection_start = time.time()
        
        if self.mode == ControllerMode.OFFLINE:
            return {
                "success": False,
                "mode": self.mode.value,
                "error": "Controller in offline mode"
            }
        
        # Try hardware connection first in HARDWARE or HYBRID mode
        if self.mode in [ControllerMode.HARDWARE, ControllerMode.HYBRID]:
            hardware_result = self._connect_hardware(timeout)
            
            if hardware_result["success"]:
                self.device_connected = True
                self._initialize_device_capabilities(hardware_result["device"])
                
                return {
                    "success": True,
                    "mode": "hardware",
                    "device": hardware_result["device"],
                    "connection_time": time.time() - connection_start,
                    "ble_diagnostics": hardware_result
                }
        
        # Fall back to simulation in HYBRID or SIMULATION mode
        if self.mode in [ControllerMode.SIMULATION, ControllerMode.HYBRID]:
            sim_result = self._connect_simulation()
            
            if sim_result["success"]:
                self.device_connected = True
                self._initialize_device_capabilities(sim_result["device"], simulation=True)
                
                return {
                    "success": True,
                    "mode": "simulation",
                    "device": sim_result["device"],
                    "connection_time": time.time() - connection_start,
                    "simulation_status": sim_result
                }
        
        # Connection failed
        self.error_count += 1
        return {
            "success": False,
            "mode": self.mode.value,
            "error": "All connection methods failed",
            "connection_time": time.time() - connection_start
        }
    
    def _connect_hardware(self, timeout: int) -> Dict[str, Any]:
        """Attempt hardware BLE connection"""
        if not self.ble_gateway:
            return {"success": False, "error": "BLE gateway not initialized"}
        
        ble_result = self.ble_gateway.scan_for_bb8(timeout)
        
        if ble_result.status == BleStatus.CONNECTED:
            self.device = ble_result.device
            return {
                "success": True,
                "device": ble_result.device,
                "ble_result": ble_result
            }
        else:
            return {
                "success": False,
                "error": ble_result.error_message,
                "status": ble_result.status.value
            }
    
    def _connect_simulation(self) -> Dict[str, Any]:
        """Connect to simulation device"""
        if not self.simulation_adapter:
            return {"success": False, "error": "Simulation adapter not initialized"}
        
        sim_result = self.simulation_adapter.scan_for_bb8()
        
        if sim_result["success"]:
            self.device = sim_result["device"]
            return {
                "success": True,
                "device": sim_result["device"],
                "simulation_result": sim_result
            }
        else:
            return {
                "success": False,
                "error": sim_result.get("error", "Simulation connection failed")
            }
    
    def _initialize_device_capabilities(self, device, simulation: bool = False):
        """Initialize enhanced device capabilities"""
        try:
            # Initialize enhanced motor control
            self.motor_control = EnhancedMotorControl(device, simulation_mode=simulation)
            
            # Initialize voltage monitoring
            self.voltage_monitor = VoltageMonitor(device, simulation_mode=simulation)
            
            self.logger.info(f"Device capabilities initialized (simulation={simulation})")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize device capabilities: {e}")
            self.error_count += 1
    
    def roll(self, speed: int, heading: int, timeout: Optional[float] = None, boost: bool = False) -> Dict[str, Any]:
        """
        Enhanced roll command with device core capabilities
        
        Args:
            speed: Motor speed (0-255)
            heading: Direction in degrees (0-359)
            timeout: Optional timeout in seconds
            boost: Enable boost mode
            
        Returns:
            Command result with diagnostics
        """
        if not self.device_connected:
            return self._create_error_result("roll", "Device not connected")
        
        self.command_count += 1
        self.last_command = "roll"
        
        try:
            if self.motor_control:
                # Use enhanced motor control
                result = self.motor_control.enhanced_roll(speed, heading, timeout, boost)
                return self._format_command_result(result)
            else:
                # Fall back to basic device control
                if hasattr(self.device, 'roll'):
                    device_result = self.device.roll(speed, heading, timeout)
                    return {
                        "success": True,
                        "command": "roll",
                        "result": device_result,
                        "enhanced": False
                    }
                else:
                    return self._create_error_result("roll", "No roll capability available")
                    
        except Exception as e:
            self.error_count += 1
            self.logger.error(f"Roll command failed: {e}")
            return self._create_error_result("roll", str(e))
    
    def set_led(self, r: int, g: int, b: int) -> Dict[str, Any]:
        """Set main LED color"""
        if not self.device_connected:
            return self._create_error_result("set_led", "Device not connected")
        
        self.command_count += 1
        self.last_command = "set_led"
        
        try:
            if hasattr(self.device, 'set_main_led'):
                result = self.device.set_main_led(r, g, b)
                return {
                    "success": True,
                    "command": "set_led",
                    "parameters": {"r": r, "g": g, "b": b},
                    "result": result
                }
            else:
                return self._create_error_result("set_led", "LED control not available")
                
        except Exception as e:
            self.error_count += 1
            self.logger.error(f"LED command failed: {e}")
            return self._create_error_result("set_led", str(e))
    
    def stop(self) -> Dict[str, Any]:
        """Emergency stop command"""
        if not self.device_connected:
            return self._create_error_result("stop", "Device not connected")
        
        self.command_count += 1
        self.last_command = "stop"
        
        try:
            if self.motor_control:
                # Use enhanced motor control emergency stop
                result = self.motor_control.emergency_stop()
                return self._format_command_result(result)
            elif hasattr(self.device, 'stop'):
                result = self.device.stop()
                return {
                    "success": True,
                    "command": "stop",
                    "result": result
                }
            else:
                return self._create_error_result("stop", "Stop capability not available")
                
        except Exception as e:
            self.error_count += 1
            self.logger.error(f"Stop command failed: {e}")
            return self._create_error_result("stop", str(e))
    
    def get_battery_status(self) -> Dict[str, Any]:
        """Get comprehensive battery status"""
        try:
            if self.voltage_monitor:
                # Use enhanced voltage diagnostics
                diagnostics = self.voltage_monitor.get_comprehensive_diagnostics()
                return {
                    "success": True,
                    "enhanced": True,
                    "battery": {
                        "voltage": diagnostics.voltage,
                        "percentage": diagnostics.percentage,
                        "state": diagnostics.state.value,
                        "health": diagnostics.health.value,
                        "health_score": diagnostics.health_score,
                        "charging": diagnostics.charging,
                        "current_draw": diagnostics.current_draw,
                        "time_remaining": diagnostics.time_remaining
                    }
                }
            elif hasattr(self.device, 'get_power_state'):
                # Fall back to basic power state
                power_state = self.device.get_power_state()
                return {
                    "success": True,
                    "enhanced": False,
                    "battery": power_state
                }
            else:
                return {
                    "success": False,
                    "error": "Battery status not available"
                }
                
        except Exception as e:
            self.logger.error(f"Battery status failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_controller_status(self) -> ControllerStatus:
        """Get comprehensive controller status"""
        uptime = time.time() - self.start_time
        
        # Determine BLE status
        ble_status = "unknown"
        if self.ble_gateway:
            ble_info = self.ble_gateway.get_ble_status()
            if self.device_connected and not self.ble_gateway.simulation_mode:
                ble_status = "connected"
            elif self.ble_gateway.simulation_mode:
                ble_status = "simulation"
            else:
                ble_status = "disconnected"
        
        # Check available features
        features = {
            "enhanced_motor_control": self.motor_control is not None,
            "voltage_diagnostics": self.voltage_monitor is not None,
            "ble_gateway": self.ble_gateway is not None,
            "simulation_adapter": self.simulation_adapter is not None
        }
        
        return ControllerStatus(
            mode=self.mode,
            device_connected=self.device_connected,
            ble_status=ble_status,
            last_command=self.last_command,
            command_count=self.command_count,
            error_count=self.error_count,
            uptime=uptime,
            features_available=features
        )
    
    def get_diagnostics_for_mqtt(self) -> Dict[str, Any]:
        """
        Get complete diagnostics formatted for MQTT/HA integration
        
        Returns:
            Comprehensive diagnostics payload ready for ζ-tier MQTT handler
        """
        status = self# removed: .get_controller_status()
        
        payload = {
            "controller": {
                "mode": status.mode.value,
                "connected": status.device_connected,
                "ble_status": status.ble_status,
                "uptime": status.uptime,
                "commands_executed": status.command_count,
                "errors": status.error_count,
                "last_command": status.last_command,
                "features": status.features_available
            },
            "timestamp": time.time()
        }
        
        # Add battery diagnostics if available
        battery_status = self.get_battery_status()
        if battery_status["success"]:
            payload["battery"] = battery_status["battery"]
        
        # Add motor diagnostics if available
        if self.motor_control:
            motor_diag = self.motor_control.get_motor_diagnostics()
            payload["motor"] = motor_diag
        
        # Add BLE diagnostics if available
        if self.ble_gateway:
            ble_status = self.ble_gateway.get_ble_status()
            payload["ble"] = ble_status
        
        return payload
    
    def simulate(self) -> Dict[str, Any]:
        """Legacy simulate method for backward compatibility"""
        return {
            "success": True,
            "message": "[SIMULATION] BB-8 would execute commands in simulation mode",
            "controller_mode": self.mode.value,
            "simulation_available": self.simulation_adapter is not None
        }
    
    def disconnect(self):
        """Disconnect from device and cleanup resources"""
        try:
            if self.device and hasattr(self.device, 'disconnect'):
                self.device# removed: .disconnect()
            
            self.device = None
            self.device_connected = False
            self.motor_control = None
            self.voltage_monitor = None
            
            self.logger.info("Controller disconnected and cleaned up")
            
        except Exception as e:
            self.logger.error(f"Disconnect error: {e}")
    
    # Helper methods
    def _create_error_result(self, command: str, error: str) -> Dict[str, Any]:
        """Create standardized error result"""
        return {
            "success": False,
            "command": command,
            "error": error,
            "timestamp": time.time()
        }
    
    def _format_command_result(self, motor_result: MotorCommandResult) -> Dict[str, Any]:
        """Format enhanced motor command result for API consistency"""
        return {
            "success": motor_result.success,
            "command": motor_result.command,
            "enhanced": True,
            "execution_time": motor_result.duration,
            "motor_state": {
                "left_speed": motor_result.motor_state.left_speed,
                "right_speed": motor_result.motor_state.right_speed,
                "heading": motor_result.motor_state.heading,
                "boost_active": motor_result.motor_state.boost_active
            },
            "error": motor_result.error_message,
            "trace_id": motor_result.trace_id,
            "timestamp": time.time()
        }

# Legacy compatibility function
def Bb8Controller() -> BB8Controller:
    """Legacy constructor for backward compatibility"""
    return BB8Controller(mode=ControllerMode.HYBRID)


# === Canonical BB8Controller Control Surface ===
class BB8Controller:
    def __init__(self, device):
        self.device = device

    def roll(self, heading: int, speed: int):
        """Roll the BB-8 in a specified heading and speed."""
        return self.device.roll(heading, speed)

    def stop(self):
        """Stop all motion."""
        return self.device.stop()

    def set_led(self, r: int, g: int, b: int):
        """Set the main LED color."""
        return self.device.set_main_led(r, g, b)

    def get_status(self):
        """Return current battery and connection diagnostics."""
        return {
            'battery_voltage': getattr(self.device, 'get_battery_voltage', lambda: None)(),
            'battery_percent': getattr(self.device, 'get_battery_percentage', lambda: None)(),
            'connected': True
        }

# === CLI entrypoints ===
import argparse

def main_roll():
    parser = argparse.ArgumentParser(description="Roll BB-8 in a direction")
    parser.add_argument("heading", type=int, help="Heading in degrees")
    parser.add_argument("speed", type=int, help="Speed from 0 to 255")
    args = parser.parse_args()
    from ha_sphero_bb8.ble_gateway import adapter
    controller = BB8Controller(adapter)
    controller.roll(args.heading, args.speed)

def main_led():
    parser = argparse.ArgumentParser(description="Set BB-8 LED color")
    parser.add_argument("r", type=int, help="Red 0–255")
    parser.add_argument("g", type=int, help="Green 0–255")
    parser.add_argument("b", type=int, help="Blue 0–255")
    args = parser.parse_args()
    from ha_sphero_bb8.ble_gateway import adapter
    controller = BB8Controller(adapter)
    controller.set_led(args.r, args.g, args.b)

def main_status():
    from ha_sphero_bb8.ble_gateway import adapter
    controller = BB8Controller(adapter)
    print(controller.get_status())



class BB8Controller:
    def __init__(self, device):
        self.device = device

    def roll(self, heading: int, speed: int):
        return self.device.roll(heading, speed)

    def stop(self):
        return self.device.stop()

    def set_led(self, r: int, g: int, b: int):
        return self.device.set_main_led(r, g, b)

    def get_status(self):
        return {
            'battery_voltage': getattr(self.device, 'get_battery_voltage', lambda: None)(),
            'battery_percent': getattr(self.device, 'get_battery_percentage', lambda: None)(),
            'connected': getattr(self.device, 'is_connected', lambda: None)()
        }
