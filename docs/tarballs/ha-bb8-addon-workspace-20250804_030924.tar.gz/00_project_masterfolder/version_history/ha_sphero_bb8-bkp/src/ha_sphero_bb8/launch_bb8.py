# src/ha_sphero_bb8/launch_bb8.py
"""
Updated BB-8 Launch Script with Phase 1 Integration
Enhanced with unified controller, BLE diagnostics, and simulation support

Phase 1 Features:
- Unified controller with hardware/simulation modes
- Enhanced BLE scanning and diagnostics
- Device core motor and voltage capabilities
- Comprehensive error handling and fallback logic
- MQTT diagnostics preparation

HESTIA Compliance:
- Tier: ζ (services - user interface)
- Consumes: β-tier unified controller
- Exposes: CLI interface and diagnostic outputs
- Prepares: ζ-tier MQTT service integration
"""

import argparse
import logging
import json
import sys
import time
from typing import Dict, Any

from .controller import BB8Controller, ControllerMode
from .simulation_adapter import SimulationMode

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_argument_parser() -> argparse.ArgumentParser:
    """Create command line argument parser"""
    parser = argparse.ArgumentParser(
        description="Sphero BB-8 Control Launcher - Phase 1 Enhanced",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --noop                    # Dry run simulation
  %(prog)s --mode hardware           # Force hardware mode
  %(prog)s --mode simulation         # Force simulation mode
  %(prog)s --diagnostics             # Show diagnostics and exit
  %(prog)s --ble-scan                # Scan for BB-8 devices
  %(prog)s --demo                    # Run demonstration sequence
        """
    )

    parser.add_argument(
        "--noop", "--dry-run",
        action="store_true",
        help="Run in test/noop mode without device interaction"
    )

    parser.add_argument(
        "--mode",
        choices=["hardware", "simulation", "hybrid", "offline"],
        default="hybrid",
        help="Controller operation mode (default: hybrid)"
    )

    parser.add_argument(
        "--simulation-mode",
        choices=["realistic", "fast", "failure", "perfect"],
        default="realistic",
        help="Simulation behavior mode (default: realistic)"
    )

    parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Connection timeout in seconds (default: 10)"
    )

    parser.add_argument(
        "--diagnostics",
        action="store_true",
        help="Show comprehensive diagnostics and exit"
    )

    parser.add_argument(
        "--ble-scan",
        action="store_true",
        help="Perform BLE scan for BB-8 devices and exit"
    )

    parser.add_argument(
        "--demo",
        action="store_true",
        help="Run demonstration sequence"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )

    parser.add_argument(
        "--json-output",
        action="store_true",
        help="Output results in JSON format"
    )

    return parser

def setup_logging(verbose: bool = False):
    """Configure logging based on verbosity"""
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logging.getLogger('ha_sphero_bb8').setLevel(logging.DEBUG)
    else:
        logging.getLogger().setLevel(logging.INFO)
        # Reduce noise from external libraries
        logging.getLogger('bleak').setLevel(logging.WARNING)
        logging.getLogger('spherov2').setLevel(logging.WARNING)

def run_diagnostics(json_output: bool = False) -> Dict[str, Any]:
    """Run comprehensive system diagnostics"""
    logger.info("Running Phase 1 system diagnostics...")

    diagnostics = {
        "phase": "1",
        "system": "ha-sphero-bb8",
        "version": "0.2.1",
        "timestamp": time.time()
    }

    # Test controller initialization
    try:
        controller = BB8Controller(mode=ControllerMode.HYBRID)
        status = controller.get_controller_status()

        diagnostics["controller"] = {
            "initialization": "success",
            "mode": status.mode.value,
            "features_available": status.features_available,
            "uptime": status.uptime
        }

        # Get MQTT-ready diagnostics
        mqtt_diagnostics = controller.get_diagnostics_for_mqtt()
        diagnostics["mqtt_payload"] = mqtt_diagnostics

        controller.disconnect()

    except Exception as e:
        diagnostics["controller"] = {
            "initialization": "failed",
            "error": str(e)
        }

    # Test BLE environment
    try:
        from .ble_gateway import BleGateway
        ble_gateway = BleGateway(simulation_mode=True)
        ble_status = ble_gateway.get_ble_status()

        diagnostics["ble"] = ble_status

    except Exception as e:
        diagnostics["ble"] = {
            "status": "error",
            "error": str(e)
        }

    # Test simulation capabilities
    try:
        from .simulation_adapter import SimulationAdapter
        sim_adapter = SimulationAdapter()
        sim_status = sim_adapter.get_simulation_status()

        diagnostics["simulation"] = sim_status

    except Exception as e:
        diagnostics["simulation"] = {
            "status": "error",
            "error": str(e)
        }

    if json_output:
        print(json.dumps(diagnostics, indent=2))
    else:
        print("=== Phase 1 System Diagnostics ===")
        print(f"System: {diagnostics['system']} v{diagnostics['version']}")
        print(f"Controller: {diagnostics['controller'].get('initialization', 'unknown')}")

        if 'features_available' in diagnostics['controller']:
            features = diagnostics['controller']['features_available']
            print("Available Features:")
            for feature, available in features.items():
                status = "✅" if available else "❌"
                print(f"  {status} {feature}")

        print(f"BLE Status: {diagnostics['ble'].get('status', 'unknown')}")
        print(f"Simulation: {diagnostics['simulation'].get('adapter_type', 'unknown')}")

    return diagnostics

def run_ble_scan(timeout: int = 10, json_output: bool = False) -> Dict[str, Any]:
    """Perform BLE scan for BB-8 devices"""
    logger.info(f"Scanning for BB-8 devices (timeout: {timeout}s)...")

    scan_result = {
        "operation": "ble_scan",
        "timeout": timeout,
        "timestamp": time.time()
    }

    try:
        from .ble_gateway import BleGateway
        ble_gateway = BleGateway(simulation_mode=False)
        result = ble_gateway.scan_for_bb8(timeout)

        scan_result.update({
            "success": result.status.name == "CONNECTED",
            "status": result.status.value,
            "scan_duration": result.scan_duration,
            "device_count": result.device_count,
            "error_message": result.error_message,
            "trace_id": result.trace_id
        })

        if result.macos_tcc_check:
            scan_result["macos_tcc_status"] = result.macos_tcc_check

    except Exception as e:
        scan_result.update({
            "success": False,
            "error": str(e)
        })

    if json_output:
        print(json.dumps(scan_result, indent=2))
    else:
        print("=== BLE Scan Results ===")
        print(f"Status: {scan_result.get('status', 'unknown')}")
        print(f"Duration: {scan_result.get('scan_duration', 0):.2f}s")
        print(f"Devices found: {scan_result.get('device_count', 0)}")

        if scan_result.get("error_message"):
            print(f"Error: {scan_result['error_message']}")

        if scan_result.get("success"):
            print("✅ BB-8 device connection successful!")
        else:
            print("❌ No BB-8 devices found or connection failed")
            print("\nTroubleshooting:")
            print("1. Ensure BB-8 is powered on and nearby")
            print("2. Check macOS Bluetooth permissions")
            print("3. Try running with --mode simulation for testing")

    return scan_result

def run_demo_sequence(controller: BB8Controller, json_output: bool = False) -> Dict[str, Any]:
    """Run demonstration sequence showcasing Phase 1 capabilities"""
    logger.info("Running Phase 1 demonstration sequence...")

    demo_result = {
        "operation": "demo_sequence",
        "timestamp": time.time(),
        "commands": []
    }

    try:
        # Connect to device
        connection_result = controller.connect()
        demo_result["connection"] = connection_result

        if not connection_result["success"]:
            demo_result["success"] = False
            demo_result["error"] = "Failed to connect to device"
            return demo_result

        # Demonstrate LED control
        logger.info("Demo: LED color sequence")
        led_commands = [
            (255, 0, 0),    # Red
            (0, 255, 0),    # Green
            (0, 0, 255),    # Blue
            (255, 255, 0),  # Yellow
            (0, 0, 0)       # Off
        ]

        for r, g, b in led_commands:
            result = controller.set_led(r, g, b)
            demo_result["commands"].append({
                "command": "set_led",
                "parameters": {"r": r, "g": g, "b": b},
                "result": result
            })
            time.sleep(0.5)

        # Demonstrate movement
        logger.info("Demo: Movement sequence")
        movement_commands = [
            (50, 0),    # Forward
            (50, 90),   # Right
            (50, 180),  # Backward
            (50, 270),  # Left
            (0, 0)      # Stop
        ]

        for speed, heading in movement_commands:
            if speed > 0:
                result = controller.roll(speed, heading, timeout=1.0)
            else:
                result = controller.stop()

            demo_result["commands"].append({
                "command": "roll" if speed > 0 else "stop",
                "parameters": {"speed": speed, "heading": heading},
                "result": result
            })
            time.sleep(1.0)

        # Get final diagnostics
        final_diagnostics = controller.get_diagnostics_for_mqtt()
        demo_result["final_diagnostics"] = final_diagnostics
        demo_result["success"] = True

    except Exception as e:
        logger.error(f"Demo sequence failed: {e}")
        demo_result["success"] = False
        demo_result["error"] = str(e)

    if json_output:
        print(json.dumps(demo_result, indent=2))
    else:
        print("=== Demo Sequence Results ===")
        print(f"Status: {'✅ Success' if demo_result.get('success') else '❌ Failed'}")
        print(f"Commands executed: {len(demo_result['commands'])}")

        if demo_result.get("connection"):
            conn = demo_result["connection"]
            print(f"Connection mode: {conn.get('mode', 'unknown')}")

        if demo_result.get("error"):
            print(f"Error: {demo_result['error']}")

    return demo_result

def run_noop_mode(json_output: bool = False) -> Dict[str, Any]:
    """Run in noop/dry-run mode"""
    logger.info("Running in noop/dry-run mode...")

    noop_result = {
        "operation": "noop",
        "timestamp": time.time(),
        "simulation": True
    }

    try:
        # Initialize controller in simulation mode
        controller = BB8Controller(mode=ControllerMode.SIMULATION)

        # Get status
        status = controller.get_controller_status()
        noop_result["controller_status"] = {
            "mode": status.mode.value,
            "features_available": status.features_available
        }

        # Simulate some commands
        simulate_result = controller.simulate()
        noop_result["simulate_result"] = simulate_result

        # Get diagnostics
        diagnostics = controller.get_diagnostics_for_mqtt()
        noop_result["diagnostics"] = diagnostics

        controller.disconnect()
        noop_result["success"] = True

    except Exception as e:
        logger.error(f"Noop mode failed: {e}")
        noop_result["success"] = False
        noop_result["error"] = str(e)

    if json_output:
        print(json.dumps(noop_result, indent=2))
    else:
        print("=== Noop Mode Results ===")
        print("[SIMULATION] BB-8 would execute commands in simulation mode")
        print(f"Controller mode: {noop_result.get('controller_status', {}).get('mode', 'unknown')}")

        features = noop_result.get('controller_status', {}).get('features_available', {})
        if features:
            print("Available features:")
            for feature, available in features.items():
                status = "✅" if available else "❌"
                print(f"  {status} {feature}")

    return noop_result

def main():
    """Main entry point for BB-8 launcher"""
    parser = create_argument_parser()
    args = parser.parse_args()

    # Setup logging
    setup_logging(args.verbose)

    logger.info("BB-8 Control Launcher - Phase 1 Enhanced")
    logger.info(f"Mode: {args.mode}, Simulation: {args.simulation_mode}")

    try:
        # Handle special operations
        if args.diagnostics:
            run_diagnostics(args.json_output)
            return 0

        if args.ble_scan:
            result = run_ble_scan(args.timeout, args.json_output)
            return 0 if result.get("success") else 1

        if args.noop:
            result = run_noop_mode(args.json_output)
            return 0 if result.get("success") else 1

        # Normal operation mode
        controller_mode = ControllerMode(args.mode)
        simulation_mode = SimulationMode(args.simulation_mode)

        controller = BB8Controller(
            mode=controller_mode,
            simulation_mode=simulation_mode
        )

        if args.demo:
            result = run_demo_sequence(controller, args.json_output)
            return_code = 0 if result.get("success") else 1
        else:
            # Default behavior - connect and show status
            logger.info("Connecting to BB-8...")
            connection_result = controller.connect(args.timeout)

            if connection_result["success"]:
                logger.info(f"✅ Connected in {connection_result['mode']} mode")

                # Show diagnostics
                diagnostics = controller.get_diagnostics_for_mqtt()

                if args.json_output:
                    print(json.dumps(diagnostics, indent=2))
                else:
                    print("\n=== BB-8 Status ===")
                    print(f"Mode: {connection_result['mode']}")
                    print(f"Battery: {diagnostics.get('battery', {}).get('percentage', 'unknown')}%")
                    print(f"Connection time: {connection_result.get('connection_time', 0):.2f}s")

                return_code = 0
            else:
                logger.error(f"❌ Connection failed: {connection_result.get('error')}")
                return_code = 1

        controller.disconnect()
        return return_code

    except KeyboardInterrupt:
        logger.info("Operation cancelled by user")
        return 130
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
