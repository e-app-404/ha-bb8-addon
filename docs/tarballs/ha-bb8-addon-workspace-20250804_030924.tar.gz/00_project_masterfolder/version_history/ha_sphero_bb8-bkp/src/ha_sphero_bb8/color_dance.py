# src/ha_sphero_bb8/color_dance.py

from ha_sphero_bb8.ble_gateway import connect_bb8
from spherov2.sphero_edu import SpheroEduAPI
import time

toy = connect_bb8()
if toy:
    with SpheroEduAPI(toy) as api:
        for r, g, b in [(255, 0, 0), (0, 255, 0), (0, 0, 255)]:
            api.set_main_led(r, g, b)
            api.roll(0, 50, 1.5)
            api.stop()
            time.sleep(1)
