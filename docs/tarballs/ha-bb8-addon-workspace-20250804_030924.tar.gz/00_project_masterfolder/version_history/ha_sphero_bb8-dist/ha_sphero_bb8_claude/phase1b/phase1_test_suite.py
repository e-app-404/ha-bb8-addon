#!/usr/bin/env python3
"""
Phase 1 BLE Integration Test Suite
Comprehensive testing of enhanced BLE capabilities and device core integration

Tests:
- Enhanced BLE gateway functionality
- Device core motor and voltage utilities
- Simulation adapter parity
- Unified controller integration
- macOS compatibility and permission handling

HESTIA Compliance:
- Validates α-tier BLE gateway
- Tests δ-tier device core capabilities
- Verifies β-tier controller integration
- Prepares ζ-tier service validation
"""

import pytest
import time
import platform
from unittest.mock import patch, MagicMock
from typing import Dict, Any

# Import Phase 1 components
from ha_sphero_bb8.controller import BB8Controller, ControllerMode
from ha_sphero_bb8.ble_gateway import BleGateway, BleStatus
from ha_sphero_bb8.simulation_adapter import SimulationAdapter, SimulationMode
from ha_sphero_bb8.device_core.motor_utils import EnhancedMotorControl
from ha_sphero_bb8.device_core.voltage_diag import VoltageMonitor


class TestBleGateway:
    """Test enhanced BLE gateway functionality"""
    
    def test_ble_gateway_initialization(self):
        """Test BLE gateway initializes correctly"""
        gateway = BleGateway(simulation_mode=True)
        assert gateway.simulation_mode == True
        
        status = gateway.get_ble_status()
        assert "ble_enabled" in status
        assert "simulation_mode" in status
        assert "dependencies" in status

    def test_ble_scan_simulation_mode(self):
        """Test BLE scanning in simulation mode"""
        gateway = BleGateway(simulation_mode=True)
        result = gateway.scan_for_bb8(timeout=5)
        
        assert result.status == BleStatus.SIMULATION
        assert result.scan_duration > 0
        assert result.trace_id is not None
        assert result.device_count == 1

    def test_ble_status_reporting(self):
        """Test comprehensive BLE status reporting"""
        gateway = BleGateway(simulation_mode=True)
        status = gateway.get_ble_status()
        
        required_fields = [
            "ble_enabled",
            "simulation_mode", 
            "dependencies",
            "platform"
        ]
        
        for field in required_fields:
            assert field in status, f"Missing required field: {field}"

    @pytest.mark.skipif(platform.system() != "Darwin", reason="macOS-specific test")
    def test_macos_tcc_check(self):
        """Test macOS TCC permission checking"""
        gateway = BleGateway(simulation_mode=True)
        tcc_status = gateway._check_macos_permissions()
        
        assert tcc_status in ["tcc_required_macos15+", "legacy_permissions", "version_unknown"]

    def test_ble_connection_validation(self):
        """Test BLE connection validation"""
        gateway = BleGateway(simulation_mode=True)
        
        # Test with None device
        assert gateway.validate_connection(None) == True  # Simulation mode returns True
        
        # Test with mock device
        mock_device = MagicMock()
        assert gateway.validate_connection(mock_device) == True

class TestSimulationAdapter:
    """Test BLE simulation adapter functionality"""
    
    def test_simulation_adapter_initialization(self):
        """Test simulation adapter initializes correctly"""
        adapter = SimulationAdapter(SimulationMode.REALISTIC)
        assert adapter.simulation_mode == SimulationMode.REALISTIC
        assert adapter.mock_device is None

    def test_simulation_bb8_scan(self):
        """Test simulated BB-8 device scanning"""
        adapter = SimulationAdapter(SimulationMode.FAST)
        result = adapter.scan_for_bb8()
        
        assert result["success"] == True
        assert result["devices_found"] == 1
        assert "device" in result
        assert adapter.mock_device is not None

    def test_simulation_device_commands(self):
        """Test simulated device command execution"""
        adapter = SimulationAdapter(SimulationMode.FAST)
        scan_result = adapter.scan_for_bb8()
        device = scan_result["device"]
        
        # Test roll command
        roll_result = device.roll(100, 90, 1.0)
        assert roll_result["success"] == True
        assert roll_result["command"] == "roll"
        assert "device_state" in roll_result

        # Test LED command
        led_result = device.set_main_led(255, 0, 0)
        assert led_result["success"] == True
        assert led_result["command"] == "set_main_led"
        
        # Test stop command
        stop_result = device.stop()
        assert stop_result["success"] == True
        assert stop_result["command"] == "stop"

    def test_simulation_battery_simulation(self):
        """Test simulated battery behavior"""
        adapter = SimulationAdapter(SimulationMode.REALISTIC)
        scan_result = adapter.scan_for_bb8()
        device = scan_result["device"]
        
        # Test battery status
        voltage = device.get_battery_voltage()
        assert isinstance(voltage, float)
        assert 6.0 <= voltage <= 8.4  # Realistic BB-8 voltage range
        
        percentage = device.get_battery_percentage()
        assert isinstance(percentage, int)
        assert 0 <= percentage <= 100

    def test_simulation_modes(self):
        """Test different simulation modes"""
        modes = [SimulationMode.REALISTIC, SimulationMode.FAST, SimulationMode.PERFECT]
        
        for mode in modes:
            adapter = SimulationAdapter(mode)
            result = adapter.scan_for_bb8()
            assert result["success"] == True
            assert result["simulation_mode"] == mode.value

class TestDeviceCore:
    """Test device core motor and voltage utilities"""
    
    def test_enhanced_motor_control_initialization(self):
        """Test enhanced motor control initialization"""
        mock_device = MagicMock()
        motor_control = EnhancedMotorControl(mock_device, simulation_mode=True)
        
        assert motor_control.simulation_mode == True
        assert motor_control.device == mock_device
        assert motor_control.capabilities is not None

    def test_enhanced_roll_command(self):
        """Test enhanced roll command with timeout and boost"""
        mock_device = MagicMock()
        motor_control = EnhancedMotorControl(mock_device, simulation_mode=True)
        
        result = motor_control.enhanced_roll(100, 90, timeout=2.0, boost=True)
        
        assert result.success == True
        assert result.command == "enhanced_roll"
        assert result.motor_state.boost_active == True
        assert result.duration > 0

    def test_raw_motor_control(self):
        """Test raw motor control functionality"""
        mock_device = MagicMock()
        motor_control = EnhancedMotorControl(mock_device, simulation_mode=True)
        
        result = motor_control.set_raw_motors(150, -150, duration=1.0)
        
        assert result.success == True
        assert result.command == "set_raw_motors"
        assert result.motor_state.left_speed == 150
        assert result.motor_state.right_speed == -150

    def test_motor_diagnostics(self):
        """Test motor diagnostics reporting"""
        mock_device = MagicMock()
        motor_control = EnhancedMotorControl(mock_device, simulation_mode=True)
        
        diagnostics = motor_control.get_motor_diagnostics()
        
        required_fields = ["capabilities", "current_state", "system_status"]
        for field in required_fields:
            assert field in diagnostics

    def test_voltage_monitor_initialization(self):
        """Test voltage monitor initialization"""
        mock_device = MagicMock()
        voltage_monitor = VoltageMonitor(mock_device, simulation_mode=True)
        
        assert voltage_monitor.simulation_mode == True
        assert voltage_monitor.device == mock_device

    def test_voltage_reading(self):
        """Test voltage reading functionality"""
        mock_device = MagicMock()
        voltage_monitor = VoltageMonitor(mock_device, simulation_mode=True)
        
        reading = voltage_monitor.get_battery_voltage()
        
        assert hasattr(reading, 'voltage')
        assert hasattr(reading, 'timestamp')
        assert hasattr(reading, 'calibrated')
        assert 6.0 <= reading.voltage <= 8.4

    def test_power_diagnostics(self):
        """Test comprehensive power diagnostics"""
        mock_device = MagicMock()
        voltage_monitor = VoltageMonitor(mock_device, simulation_mode=True)
        
        diagnostics = voltage_monitor.get_comprehensive_diagnostics()
        
        assert diagnostics.voltage > 0
        assert 0 <= diagnostics.percentage <= 100
        assert diagnostics.state is not None
        assert diagnostics.health is not None

    def test_mqtt_diagnostics_format(self):
        """Test MQTT-formatted diagnostics"""
        mock_device = MagicMock()
        voltage_monitor = VoltageMonitor(mock_device, simulation_mode=True)
        
        mqtt_data = voltage_monitor.get_diagnostics_for_mqtt()
        
        required_sections = ["battery", "charging", "power", "system"]
        for section in required_sections:
            assert section in mqtt_data

class TestUnifiedController:
    """Test unified BB-8 controller integration"""
    
    def test_controller_initialization(self):
        """Test controller initialization in different modes"""
        modes = [ControllerMode.SIMULATION, ControllerMode.HYBRID, ControllerMode.OFFLINE]
        
        for mode in modes:
            controller = BB8Controller(mode=mode)
            assert controller.mode == mode
            status = controller.get_controller_status()
            assert status.mode == mode

    def test_controller_simulation_connection(self):
        """Test controller connection in simulation mode"""
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        
        connection_result = controller.connect()
        
        assert connection_result["success"] == True
        assert connection_result["mode"] == "simulation"
        assert controller.device_connected == True

    def test_controller_command_execution(self):
        """Test command execution through unified controller"""
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        controller.connect()
        
        # Test roll command
        roll_result = controller.roll(100, 90)
        assert roll_result["success"] == True
        assert controller.command_count > 0
        
        # Test LED command
        led_result = controller.set_led(255, 0, 0)
        assert led_result["success"] == True
        
        # Test stop command
        stop_result = controller.stop()
        assert stop_result["success"] == True

    def test_controller_battery_status(self):
        """Test battery status reporting through controller"""
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        controller.connect()
        
        battery_status = controller.get_battery_status()
        
        assert battery_status["success"] == True
        assert "battery" in battery_status
        
        battery_data = battery_status["battery"]
        required_fields = ["voltage", "percentage", "state"]
        for field in required_fields:
            assert field in battery_data

    def test_controller_mqtt_diagnostics(self):
        """Test MQTT diagnostics generation"""
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        controller.connect()
        
        mqtt_diagnostics = controller.get_diagnostics_for_mqtt()
        
        required_sections = ["controller", "timestamp"]
        for section in required_sections:
            assert section in mqtt_diagnostics
        
        controller_data = mqtt_diagnostics["controller"]
        required_fields = ["mode", "connected", "uptime", "commands_executed"]
        for field in required_fields:
            assert field in controller_data

    def test_controller_error_handling(self):
        """Test controller error handling"""
        controller = BB8Controller(mode=ControllerMode.OFFLINE)
        
        # Commands should fail gracefully in offline mode
        roll_result = controller.roll(100, 90)
        assert roll_result["success"] == False
        assert "error" in roll_result

    def test_controller_legacy_compatibility(self):
        """Test legacy compatibility functions"""
        from ha_sphero_bb8.controller import Bb8Controller
        
        # Legacy constructor should work
        legacy_controller = Bb8Controller()
        assert isinstance(legacy_controller, BB8Controller)
        assert legacy_controller.mode == ControllerMode.HYBRID

    def test_controller_cleanup(self):
        """Test controller cleanup and disconnect"""
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        controller.connect()
        
        assert controller.device_connected == True
        
        controller.disconnect()
        
        assert controller.device == None
        assert controller.device_connected == False

class TestPhase1Integration:
    """Test Phase 1 integration and CLI functionality"""
    
    def test_launch_script_noop_mode(self):
        """Test launch script in noop mode"""
        from ha_sphero_bb8.launch_bb8 import run_noop_mode
        
        result = run_noop_mode(json_output=True)
        
        assert result["success"] == True
        assert result["operation"] == "noop"
        assert result["simulation"] == True

    def test_launch_script_diagnostics(self):
        """Test launch script diagnostics mode"""
        from ha_sphero_bb8.launch_bb8 import run_diagnostics
        
        result = run_diagnostics(json_output=True)
        
        assert "phase" in result
        assert result["phase"] == "1"
        assert "controller" in result
        assert "ble" in result
        assert "simulation" in result

    def test_phase1_feature_availability(self):
        """Test that all Phase 1 features are available"""
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        status = controller.get_controller_status()
        
        expected_features = [
            "enhanced_motor_control",
            "voltage_diagnostics", 
            "simulation_adapter"
        ]
        
        for feature in expected_features:
            assert feature in status.features_available
            assert status.features_available[feature] == True

    @pytest.mark.ble
    def test_hardware_ble_scan(self):
        """Test actual BLE hardware scanning (requires BB-8)"""
        pytest.skip("Hardware BLE test - requires actual BB-8 device")
        
        # This test would be run manually with actual hardware
        from ha_sphero_bb8.launch_bb8 import run_ble_scan
        
        result = run_ble_scan(timeout=5)
        # Results would depend on hardware availability

class TestMacOSCompatibility:
    """Test macOS-specific functionality"""
    
    @pytest.mark.skipif(platform.system() != "Darwin", reason="macOS-specific test")
    def test_macos_app_config_validation(self):
        """Test macOS app configuration validation"""
        from ha_sphero_bb8 import setup_macos
        
        validation = setup_macos.validate_macos_environment()
        
        assert validation["platform"] == "Darwin"
        assert "macos_version" in validation
        assert "python_version" in validation

    @pytest.mark.skipif(platform.system() != "Darwin", reason="macOS-specific test") 
    def test_ble_permission_check(self):
        """Test BLE permission checking on macOS"""
        from ha_sphero_bb8 import setup_macos
        
        # This should not raise an exception
        setup_macos.check_ble_permissions()

# Test markers and configuration
pytestmark = [
    pytest.mark.phase1,
    pytest.mark.integration
]

# Test fixtures
@pytest.fixture
def simulation_controller():
    """Fixture providing a simulation-mode controller"""
    controller = BB8Controller(mode=ControllerMode.SIMULATION)
    yield controller
    controller.disconnect()

@pytest.fixture
def mock_ble_device():
    """Fixture providing a mock BLE device"""
    device = MagicMock()
    device.name = "BB-8-TEST"
    device.address = "00:11:22:33:44:55"
    return device

# Performance tests
class TestPhase1Performance:
    """Test Phase 1 performance characteristics"""
    
    def test_controller_initialization_time(self):
        """Test controller initialization performance"""
        start_time = time.time()
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        init_time = time.time() - start_time
        
        # Initialization should be fast
        assert init_time < 1.0
        controller.disconnect()

    def test_simulation_command_latency(self):
        """Test simulation command execution latency"""
        controller = BB8Controller(mode=ControllerMode.SIMULATION)
        controller.connect()
        
        start_time = time.time()
        result = controller.roll(100, 90)
        command_time = time.time() - start_time
        
        assert result["success"] == True
        # Simulation commands should be fast
        assert command_time < 0.5
        
        controller.disconnect()

if __name__ == "__main__":
    # Run tests directly
    pytest.main([__file__, "-v", "--tb=short"])
