# src/ha_sphero_bb8/ble_gateway.py
"""
Enhanced BLE Gateway with Runtime Diagnostics (α-tier)
Phase 1: Active BLE scanning, connection validation, and diagnostic tracing

Provides:
- Live BLE scanning with timeout control
- Connection diagnostics and trace logging
- Fallback adapter for simulation/development
- macOS TCC permission validation
- Runtime BLE status for ζ-tier MQTT propagation

HESTIA Compliance:
- Tier: α (gateway - hardware interface)
- Exposes: BB-8 device connection to β-tier controller
- Consumes: bleak BLE adapter, spherov2 scanner
"""

import logging
import time
import platform
from typing import Optional, Dict, Any, TYPE_CHECKING
from dataclasses import dataclass
from enum import Enum
import traceback

# Conditional imports for graceful fallback
try:
    from spherov2.scanner import find_BB8
    from spherov2.toy.bb8 import BB8
    SPHEROV2_AVAILABLE = True
except ImportError:
    SPHEROV2_AVAILABLE = False
    BB8 = None

try:
    import bleak
    BLEAK_AVAILABLE = True
except ImportError:
    BLEAK_AVAILABLE = False

if TYPE_CHECKING:
    from spherov2.toy.bb8 import BB8

logger = logging.getLogger(__name__)

# 🔒 Phase 1: BLE activation with safety controls
BLE_ENABLED = True
BLE_SIMULATION_MODE = False  # Set to True for development without hardware

class BleStatus(Enum):
    """BLE connection status enumeration"""
    UNKNOWN = "unknown"
    DISABLED = "disabled"
    SCANNING = "scanning"
    CONNECTED = "connected"
    FAILED = "failed"
    TIMEOUT = "timeout"
    PERMISSION_DENIED = "permission_denied"
    SIMULATION = "simulation"

@dataclass
class BleConnectionResult:
    """BLE connection attempt result with diagnostics"""
    status: BleStatus
    device: Optional["BB8"] = None
    scan_duration: float = 0.0
    device_count: int = 0
    error_message: Optional[str] = None
    trace_id: Optional[str] = None
    macos_tcc_check: Optional[bool] = None

class BleGateway:
    """
    Enhanced BLE Gateway with comprehensive diagnostics
    
    Handles BB-8 device discovery, connection, and status monitoring
    with graceful fallback for development environments.
    """
    
    def __init__(self, simulation_mode: bool = None):
        self.simulation_mode = simulation_mode if simulation_mode is not None else BLE_SIMULATION_MODE
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self._last_connection_result: Optional[BleConnectionResult] = None
        
        # Validate runtime environment
        self._validate_environment()
    
    def _validate_environment(self) -> Dict[str, Any]:
        """Validate BLE runtime environment and dependencies"""
        validation = {
            "platform": platform.system(),
            "bleak_available": BLEAK_AVAILABLE,
            "spherov2_available": SPHEROV2_AVAILABLE,
            "ble_enabled": BLE_ENABLED,
            "simulation_mode": self.simulation_mode
        }
        
        if platform.system() == "Darwin":
            validation["macos_version"] = platform.mac_ver()[0]
            validation["tcc_warning"] = self._check_macos_permissions()
        
        self.logger.info(f"BLE Environment: {validation}")
        return validation
    
    def _check_macos_permissions(self) -> str:
        """Check macOS BLE permissions and TCC status"""
        if platform.system() != "Darwin":
            return "not_applicable"
        
        try:
            mac_version = tuple(map(int, platform.mac_ver()[0].split('.')))
            if mac_version >= (15, 0):
                return "tcc_required_macos15+"
            else:
                return "legacy_permissions"
        except Exception:
            return "version_unknown"
    
    def scan_for_bb8(self, timeout: int = 10) -> BleConnectionResult:
        """
        Scan for BB-8 device with comprehensive diagnostics
        
        Args:
            timeout: Scan timeout in seconds
            
        Returns:
            BleConnectionResult with connection status and diagnostics
        """
        trace_id = f"ble_scan_{int(time.time())}"
        start_time = time.time()
        
        self.logger.info(f"[{trace_id}] Starting BB-8 scan (timeout: {timeout}s)")
        
        # Simulation mode override
        if self.simulation_mode:
            return self._simulate_connection(trace_id, start_time)
        
        # Safety checks
        if not BLE_ENABLED:
            return BleConnectionResult(
                status=BleStatus.DISABLED,
                scan_duration=time.time() - start_time,
                error_message="BLE_ENABLED is False",
                trace_id=trace_id
            )
        
        if not BLEAK_AVAILABLE:
            return BleConnectionResult(
                status=BleStatus.FAILED,
                scan_duration=time.time() - start_time,
                error_message="bleak dependency not available",
                trace_id=trace_id
            )
        
        if not SPHEROV2_AVAILABLE:
            return BleConnectionResult(
                status=BleStatus.FAILED,
                scan_duration=time.time() - start_time,
                error_message="spherov2 dependency not available", 
                trace_id=trace_id
            )
        
        # Attempt BB-8 connection
        try:
            self.logger.info(f"[{trace_id}] Scanning for BB-8 devices...")
            
            device = find_BB8(timeout=timeout)
            scan_duration = time.time() - start_time
            
            if device:
                self.logger.info(f"[{trace_id}] BB-8 connected: {device}")
                result = BleConnectionResult(
                    status=BleStatus.CONNECTED,
                    device=device,
                    scan_duration=scan_duration,
                    device_count=1,
                    trace_id=trace_id,
                    macos_tcc_check=self._check_macos_permissions() if platform.system() == "Darwin" else None
                )
            else:
                self.logger.warning(f"[{trace_id}] No BB-8 devices found")
                result = BleConnectionResult(
                    status=BleStatus.TIMEOUT,
                    scan_duration=scan_duration,
                    device_count=0,
                    error_message="No BB-8 devices discovered",
                    trace_id=trace_id
                )
        
        except PermissionError as e:
            result = BleConnectionResult(
                status=BleStatus.PERMISSION_DENIED,
                scan_duration=time.time() - start_time,
                error_message=f"BLE permission denied: {e}",
                trace_id=trace_id,
                macos_tcc_check=True
            )
            self.logger.error(f"[{trace_id}] BLE permission denied: {e}")
        
        except Exception as e:
            result = BleConnectionResult(
                status=BleStatus.FAILED,
                scan_duration=time.time() - start_time,
                error_message=f"BLE scan failed: {e}",
                trace_id=trace_id
            )
            self.logger.error(f"[{trace_id}] BLE scan failed: {e}")
            self.logger.debug(f"[{trace_id}] Full traceback: {traceback.format_exc()}")
        
        self._last_connection_result = result
        return result
    
    def _simulate_connection(self, trace_id: str, start_time: float) -> BleConnectionResult:
        """Simulate BB-8 connection for development/testing"""
        self.logger.info(f"[{trace_id}] SIMULATION MODE: Simulating BB-8 connection")
        
        # Simulate realistic scan time
        import time
        time.sleep(0.5)
        
        return BleConnectionResult(
            status=BleStatus.SIMULATION,
            device=None,  # No actual device in simulation
            scan_duration=time.time() - start_time,
            device_count=1,
            error_message=None,
            trace_id=trace_id,
            macos_tcc_check=False
        )
    
    def get_ble_status(self) -> Dict[str, Any]:
        """
        Get comprehensive BLE status for diagnostics and MQTT propagation
        
        Returns:
            Complete BLE status including last connection attempt
        """
        status = {
            "ble_enabled": BLE_ENABLED,
            "simulation_mode": self.simulation_mode,
            "dependencies": {
                "bleak_available": BLEAK_AVAILABLE,
                "spherov2_available": SPHEROV2_AVAILABLE
            },
            "platform": {
                "system": platform.system(),
                "version": platform.version()
            }
        }
        
        if self._last_connection_result:
            status["last_connection"] = {
                "status": self._last_connection_result.status.value,
                "scan_duration": self._last_connection_result.scan_duration,
                "device_count": self._last_connection_result.device_count,
                "trace_id": self._last_connection_result.trace_id,
                "error_message": self._last_connection_result.error_message,
                "connected": self._last_connection_result.device is not None
            }
        
        if platform.system() == "Darwin":
            status["macos"] = {
                "tcc_check": self._check_macos_permissions(),
                "version": platform.mac_ver()[0]
            }
        
        return status
    
    def validate_connection(self, device: Optional["BB8"]) -> bool:
        """Validate BB-8 device connection is active"""
        if self.simulation_mode:
            return True
        
        if not device:
            return False
        
        try:
            # Basic connectivity check - ping or version query
            # This would use actual spherov2 API calls
            return True  # Placeholder - implement actual validation
        except Exception as e:
            self.logger.error(f"Connection validation failed: {e}")
            return False

# Legacy function compatibility
def connect_bb8(timeout: int = 10) -> Optional["BB8"]:
    """
    Legacy compatibility function for connect_bb8()
    
    Returns BB8 device or None, maintains existing API
    """
    gateway = BleGateway()
    result = gateway.scan_for_bb8(timeout)
    
    if result.status == BleStatus.CONNECTED:
        return result.device
    elif result.status == BleStatus.SIMULATION:
        # Return a mock device for simulation
        return None  # Caller should handle simulation mode
    else:
        logger.warning(f"BB-8 connection failed: {result.error_message}")
        return None

# Main execution for testing
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print(f"[BLE GATEWAY] BLE_ENABLED: {BLE_ENABLED}")
    print(f"[BLE GATEWAY] Simulation Mode: {BLE_SIMULATION_MODE}")
    
    if not BLE_ENABLED:
        print("[ABORT] BLE is disabled. Enable BLE_ENABLED to proceed.")
    else:
        gateway = BleGateway()
        result = gateway.scan_for_bb8(timeout=10)
        
        print(f"[RESULT] Status: {result.status.value}")
        print(f"[RESULT] Duration: {result.scan_duration:.2f}s")
        
        if result.device:
            print(f"[SUCCESS] Connected to BB-8: {result.device}")
        elif result.status == BleStatus.SIMULATION:
            print("[SIMULATION] BB-8 connection simulated successfully")
        else:
            print(f"[FAILED] {result.error_message}")
            
        # Print full status for diagnostics
        import json
        status = gateway.get_ble_status()
        print(f"[STATUS] {json.dumps(status, indent=2)}")
