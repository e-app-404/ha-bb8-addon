# src/ha_sphero_bb8/mqtt_handler.py
"""
MQTT Handler for Home Assistant Integration (ζ-tier)
Phase 1 Preparation: MQTT service scaffolding for Phase 2 HA integration

Provides:
- MQTT client configuration and connection management
- BB-8 command routing from Home Assistant
- Status publishing for HA entity integration
- Structured payload handling for device discovery

HESTIA Compliance:
- Tier: ζ (services - Home Assistant integration)
- Consumes: β-tier unified controller diagnostics
- Exposes: MQTT topics for HA device integration
- Prepares: Phase 2 full HA service implementation
"""

import logging
import json
import time
import threading
from typing import Dict, Any, Optional, Callable
from dataclasses import dataclass
from enum import Enum

try:
    import paho.mqtt.client as mqtt
    MQTT_AVAILABLE = True
except ImportError:
    MQTT_AVAILABLE = False
    mqtt = None

from .controller import BB8Controller, ControllerMode

logger = logging.getLogger(__name__)

class MqttConnectionState(Enum):
    """MQTT connection state enumeration"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"

@dataclass
class MqttConfig:
    """MQTT configuration for Home Assistant integration"""
    host: str = "localhost"
    port: int = 1883
    username: Optional[str] = None
    password: Optional[str] = None
    client_id: str = "ha-sphero-bb8"
    keepalive: int = 60
    
    # Home Assistant MQTT Discovery
    discovery_prefix: str = "homeassistant"
    device_name: str = "Sphero BB-8"
    device_id: str = "sphero_bb8"
    
    # Topic structure
    base_topic: str = "ha_sphero_bb8"
    command_topic: str = "ha_sphero_bb8/command"
    status_topic: str = "ha_sphero_bb8/status"
    diagnostics_topic: str = "ha_sphero_bb8/diagnostics"

class MqttHandler:
    """
    MQTT Handler for Home Assistant Integration
    
    Phase 1 Preparation: Provides MQTT scaffolding and message routing
    for full Home Assistant device integration in Phase 2.
    """
    
    def __init__(self, 
                 config: MqttConfig,
                 controller: Optional[BB8Controller] = None,
                 simulation_mode: bool = True):
        
        self.config = config
        self.controller = controller
        self.simulation_mode = simulation_mode
        self.logger = logging.getLogger(f"{__name__}.MqttHandler")
        
        # MQTT client and state
        self.client: Optional[mqtt.Client] = None
        self.connection_state = MqttConnectionState.DISCONNECTED
        self.last_status_update = 0.0
        self.status_update_interval = 30.0  # seconds
        
        # Message handlers
        self.command_handlers: Dict[str, Callable] = {}
        self.status_callbacks: list = []
        
        # Statistics
        self.messages_received = 0
        self.messages_sent = 0
        self.commands_executed = 0
        self.errors = 0
        
        # Background thread for status updates
        self._status_thread: Optional[threading.Thread] = None
        self._stop_status_thread = False
        
        self._initialize_mqtt()
        self._register_command_handlers()
    
    def _initialize_mqtt(self):
        """Initialize MQTT client and configuration"""
        if not MQTT_AVAILABLE:
            self.logger.warning("paho-mqtt not available - MQTT functionality disabled")
            return
        
        if self.simulation_mode:
            self.logger.info("MQTT handler initialized in simulation mode")
            return
        
        try:
            self.client = mqtt.Client(self.config.client_id)
            
            # Set authentication if provided
            if self.config.username and self.config.password:
                self.client.username_pw_set(self.config.username, self.config.password)
            
            # Set callbacks
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client.on_message = self._on_message
            self.client.on_subscribe = self._on_subscribe
            self.client.on_publish = self._on_publish
            
            self.logger.info("MQTT client initialized")
            
        except Exception as e:
            self.logger.error(f"MQTT initialization failed: {e}")
            self.connection_state = MqttConnectionState.ERROR
    
    def _register_command_handlers(self):
        """Register MQTT command handlers"""
        self.command_handlers = {
            "roll": self._handle_roll_command,
            "stop": self._handle_stop_command,
            "set_led": self._handle_led_command,
            "get_status": self._handle_status_request,
            "get_diagnostics": self._handle_diagnostics_request,
            "emergency_stop": self._handle_emergency_stop
        }
        
        self.logger.info(f"Registered {len(self.command_handlers)} command handlers")
    
    def connect(self) -> bool:
        """Connect to MQTT broker"""
        if self.simulation_mode:
            self.connection_state = MqttConnectionState.CONNECTED
            self.logger.info("[SIMULATION] MQTT connected")
            self._start_status_thread()
            return True
        
        if not MQTT_AVAILABLE or not self.client:
            self.logger.error("MQTT client not available")
            return False
        
        try:
            self.connection_state = MqttConnectionState.CONNECTING
            self.logger.info(f"Connecting to MQTT broker at {self.config.host}:{self.config.port}")
            
            result = self.client.connect(
                self.config.host, 
                self.config.port, 
                self.config.keepalive
            )
            
            if result == mqtt.MQTT_ERR_SUCCESS:
                self.client.loop_start()
                return True
            else:
                self.logger.error(f"MQTT connection failed with code: {result}")
                self.connection_state = MqttConnectionState.ERROR
                return False
                
        except Exception as e:
            self.logger.error(f"MQTT connection error: {e}")
            self.connection_state = MqttConnectionState.ERROR
            return False
    
    def disconnect(self):
        """Disconnect from MQTT broker"""
        self._stop_status_thread = True
        
        if self._status_thread and self._status_thread.is_alive():
            self._status_thread.join(timeout=5.0)
        
        if self.simulation_mode:
            self.connection_state = MqttConnectionState.DISCONNECTED
            self.logger.info("[SIMULATION] MQTT disconnected")
            return
        
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
            self.connection_state = MqttConnectionState.DISCONNECTED
            self.logger.info("MQTT disconnected")
    
    def publish_status(self, force: bool = False) -> bool:
        """Publish BB-8 status to MQTT"""
        current_time = time.time()
        
        if not force and (current_time - self.last_status_update) < self.status_update_interval:
            return True  # Skip if too soon
        
        try:
            if not self.controller:
                status_payload = {
                    "controller": "not_initialized",
                    "timestamp": current_time
                }
            else:
                status_payload = self.controller.get_diagnostics_for_mqtt()
            
            # Add MQTT handler metadata
            status_payload["mqtt"] = {
                "connection_state": self.connection_state.value,
                "messages_received": self.messages_received,
                "messages_sent": self.messages_sent,
                "commands_executed": self.commands_executed,
                "errors": self.errors,
                "simulation_mode": self.simulation_mode
            }
            
            success = self._publish_message(self.config.status_topic, status_payload)
            
            if success:
                self.last_status_update = current_time
                self.logger.debug("Status published to MQTT")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Status publish failed: {e}")
            self.errors += 1
            return False
    
    def publish_discovery_config(self) -> bool:
        """Publish Home Assistant MQTT discovery configuration"""
        if self.simulation_mode:
            self.logger.info("[SIMULATION] Would publish HA discovery config")
            return True
        
        try:
            # Device configuration for HA discovery
            device_config = {
                "identifiers": [self.config.device_id],
                "name": self.config.device_name,
                "model": "BB-8",
                "manufacturer": "Sphero",
                "sw_version": "ha-sphero-bb8-0.2.1"
            }
            
            # Battery sensor discovery
            battery_config = {
                "name": f"{self.config.device_name} Battery",
                "unique_id": f"{self.config.device_id}_battery",
                "state_topic": self.config.status_topic,
                "value_template": "{{ value_json.battery.percentage }}",
                "unit_of_measurement": "%",
                "device_class": "battery",
                "device": device_config
            }
            
            battery_topic = f"{self.config.discovery_prefix}/sensor/{self.config.device_id}/battery/config"
            self._publish_message(battery_topic, battery_config, retain=True)
            
            # Connection status binary sensor
            connection_config = {
                "name": f"{self.config.device_name} Connection",
                "unique_id": f"{self.config.device_id}_connection",
                "state_topic": self.config.status_topic,
                "value_template": "{{ 'ON' if value_json.controller.connected else 'OFF' }}",
                "device_class": "connectivity",
                "device": device_config
            }
            
            connection_topic = f"{self.config.discovery_prefix}/binary_sensor/{self.config.device_id}/connection/config"
            self._publish_message(connection_topic, connection_config, retain=True)
            
            self.logger.info("HA discovery configuration published")
            return True
            
        except Exception as e:
            self.logger.error(f"Discovery config publish failed: {e}")
            self.errors += 1
            return False
    
    def _publish_message(self, topic: str, payload: Dict[str, Any], retain: bool = False) -> bool:
        """Publish message to MQTT topic"""
        if self.simulation_mode:
            self.logger.debug(f"[SIMULATION] Publish to {topic}: {json.dumps(payload, indent=2)}")
            self.messages_sent += 1
            return True
        
        if not self.client or self.connection_state != MqttConnectionState.CONNECTED:
            self.logger.warning("Cannot publish - MQTT not connected")
            return False
        
        try:
            json_payload = json.dumps(payload)
            result = self.client.publish(topic, json_payload, retain=retain)
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                self.messages_sent += 1
                return True
            else:
                self.logger.error(f"Publish failed with code: {result.rc}")
                return False
                
        except Exception as e:
            self.logger.error(f"Publish error: {e}")
            self.errors += 1
            return False
    
    def _start_status_thread(self):
        """Start background thread for periodic status updates"""
        if self._status_thread and self._status_thread.is_alive():
            return
        
        self._stop_status_thread = False
        self._status_thread = threading.Thread(target=self._status_update_loop, daemon=True)
        self._status_thread.start()
        self.logger.info("Status update thread started")
    
    def _status_update_loop(self):
        """Background loop for periodic status updates"""
        while not self._stop_status_thread:
            try:
                self.publish_status()
                time.sleep(self.status_update_interval)
            except Exception as e:
                self.logger.error(f"Status update loop error: {e}")
                time.sleep(5.0)
    
    # MQTT callback handlers
    def _on_connect(self, client, userdata, flags, rc):
        """Handle MQTT connection"""
        if rc == 0:
            self.connection_state = MqttConnectionState.CONNECTED
            self.logger.info("MQTT connected successfully")
            
            # Subscribe to command topic
            client.subscribe(self.config.command_topic)
            self.logger.info(f"Subscribed to {self.config.command_topic}")
            
            # Publish discovery configuration
            self.publish_discovery_config()
            
            # Start status updates
            self._start_status_thread()
            
        else:
            self.connection_state = MqttConnectionState.ERROR
            self.logger.error(f"MQTT connection failed with code: {rc}")
    
    def _on_disconnect(self, client, userdata, rc):
        """Handle MQTT disconnection"""
        self.connection_state = MqttConnectionState.DISCONNECTED
        self.logger.warning(f"MQTT disconnected with code: {rc}")
    
    def _on_message(self, client, userdata, msg):
        """Handle incoming MQTT message"""
        try:
            self.messages_received += 1
            
            topic = msg.topic
            payload = json.loads(msg.payload.decode())
            
            self.logger.info(f"Received message on {topic}: {payload}")
            
            if topic == self.config.command_topic:
                self._handle_command_message(payload)
            else:
                self.logger.warning(f"Unexpected message topic: {topic}")
                
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in message: {e}")
            self.errors += 1
        except Exception as e:
            self.logger.error(f"Message handling error: {e}")
            self.errors += 1
    
    def _on_subscribe(self, client, userdata, mid, granted_qos):
        """Handle subscription confirmation"""
        self.logger.debug(f"Subscription confirmed with QoS: {granted_qos}")
    
    def _on_publish(self, client, userdata, mid):
        """Handle publish confirmation"""
        self.logger.debug(f"Message published with ID: {mid}")
    
    def _handle_command_message(self, payload: Dict[str, Any]):
        """Handle command message from MQTT"""
        try:
            command = payload.get("command")
            if not command:
                self.logger.error("No command specified in message")
                return
            
            if command not in self.command_handlers:
                self.logger.error(f"Unknown command: {command}")
                return
            
            # Execute command handler
            handler = self.command_handlers[command]
            result = handler(payload)
            
            # Publish command result
            response_payload = {
                "command": command,
                "result": result,
                "timestamp": time.time()
            }
            
            response_topic = f"{self.config.base_topic}/response"
            self._publish_message(response_topic, response_payload)
            
            self.commands_executed += 1
            
        except Exception as e:
            self.logger.error(f"Command handling error: {e}")
            self.errors += 1
    
    # Command handlers
    def _handle_roll_command(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle roll command"""
        if not self.controller:
            return {"success": False, "error": "Controller not available"}
        
        speed = payload.get("speed", 0)
        heading = payload.get("heading", 0)
        timeout = payload.get("timeout")
        boost = payload.get("boost", False)
        
        return self.controller.roll(speed, heading, timeout, boost)
    
    def _handle_stop_command(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle stop command"""
        if not self.controller:
            return {"success": False, "error": "Controller not available"}
        
        return self.controller.stop()
    
    def _handle_led_command(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle LED command"""
        if not self.controller:
            return {"success": False, "error": "Controller not available"}
        
        r = payload.get("r", 0)
        g = payload.get("g", 0)
        b = payload.get("b", 0)
        
        return self.controller.set_led(r, g, b)
    
    def _handle_status_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle status request"""
        self.publish_status(force=True)
        return {"success": True, "message": "Status published"}
    
    def _handle_diagnostics_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle diagnostics request"""
        if not self.controller:
            return {"success": False, "error": "Controller not available"}
        
        diagnostics = self.controller.get_diagnostics_for_mqtt()
        
        diag_topic = self.config.diagnostics_topic
        self._publish_message(diag_topic, diagnostics)
        
        return {"success": True, "message": "Diagnostics published"}
    
    def _handle_emergency_stop(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle emergency stop command"""
        if not self.controller:
            return {"success": False, "error": "Controller not available"}
        
        self.logger.warning("Emergency stop command received")
        return self.controller.stop()

# Helper functions for MQTT integration
def create_default_config() -> MqttConfig:
    """Create default MQTT configuration"""
    return MqttConfig()

def create_mqtt_handler(controller: BB8Controller, 
                       config: Optional[MqttConfig] = None,
                       simulation_mode: bool = True) -> MqttHandler:
    """Create MQTT handler with controller"""
    if config is None:
        config = create_default_config()
    
    return MqttHandler(config, controller, simulation_mode)

# Phase 2 preparation note
def prepare_phase2_integration() -> Dict[str, Any]:
    """Prepare Phase 2 HA integration checklist"""
    return {
        "phase2_requirements": {
            "mqtt_broker": "Home Assistant MQTT broker or external broker",
            "ha_discovery": "MQTT Discovery enabled in Home Assistant",
            "device_integration": "Custom integration or MQTT device setup",
            "entity_mapping": "Map BB-8 capabilities to HA entities"
        },
        "entities_planned": {
            "sensor.bb8_battery": "Battery percentage sensor",
            "binary_sensor.bb8_connection": "Connection status",
            "button.bb8_emergency_stop": "Emergency stop button",
            "light.bb8_led": "LED color control",
            "device_tracker.bb8": "Position tracking (if applicable)"
        },
        "services_planned": {
            "bb8.roll": "Roll command service",
            "bb8.set_led": "LED control service",
            "bb8.stop": "Stop command service"
        },
        "implementation_notes": [
            "MQTT handler provides Phase 2 foundation",
            "Discovery configuration ready for HA integration",
            "Command routing established and tested",
            "Status publishing aligned with HA expectations"
        ]
    }

if __name__ == "__main__":
    # Test MQTT handler in simulation mode
    logging.basicConfig(level=logging.INFO)
    
    print("Testing MQTT Handler (Simulation Mode)")
    
    # Create controller and MQTT handler
    controller = BB8Controller(mode=ControllerMode.SIMULATION)
    controller.connect()
    
    mqtt_handler = MqttHandler(
        config=create_default_config(),
        controller=controller,
        simulation_mode=True
    )
    
    # Test connection and status publishing
    mqtt_handler.connect()
    mqtt_handler.publish_status(force=True)
    mqtt_handler.publish_discovery_config()
    
    # Test command simulation
    test_command = {
        "command": "roll",
        "speed": 100,
        "heading": 90
    }
    
    mqtt_handler._handle_command_message(test_command)
    
    # Cleanup
    mqtt_handler.disconnect()
    controller.disconnect()
    
    print("MQTT handler test completed")
