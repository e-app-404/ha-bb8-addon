#!/usr/bin/env python3
"""
Real test implementation for ha-sphero-bb8 CLI noop functionality
Phase 0 requirement: Validate dry-run path works correctly

Tests the actual CLI behavior, not aspirational behavior.
"""

import subprocess
import sys
import pytest
from unittest.mock import patch, MagicMock
from io import StringIO
import importlib.util


class TestCliNoop:
    """Test suite for CLI --noop functionality"""

    def test_module_imports_cleanly(self):
        """Test that core modules can be imported without BLE dependencies"""
        try:
            import ha_sphero_bb8
            import ha_sphero_bb8.launch_bb8
            import ha_sphero_bb8.integration_stub
        except ImportError as e:
            if "bleak" in str(e).lower():
                pytest.skip("BLE dependency not installed - expected in development")
            else:
                pytest.fail(f"Unexpected import error: {e}")

    def test_launch_bb8_main_exists(self):
        """Verify the main entry point function exists"""
        try:
            from ha_sphero_bb8.launch_bb8 import main
            assert callable(main), "main() should be a callable function"
        except ImportError:
            pytest.skip("Module not available for import")

    def test_cli_noop_subprocess(self):
        """Test CLI --noop flag via subprocess execution"""
        try:
            # Test the actual console script if installed
            result = subprocess.run([
                "bb8-control", "--noop"
            ], capture_output=True, text=True, timeout=10)
            
            if result.returncode != 0:
                # Fall back to module execution if console script not installed
                result = subprocess.run([
                    sys.executable, "-m", "ha_sphero_bb8.launch_bb8", "--noop"
                ], capture_output=True, text=True, timeout=10)
            
            # Basic validation - should not crash
            assert result.returncode == 0, f"CLI failed with code {result.returncode}: {result.stderr}"
            
            # Check for simulation output (actual content from the code)
            output = result.stdout + result.stderr
            assert len(output) > 0, "CLI should produce some output"
            
            # Look for expected patterns based on actual bb8_control.py implementation
            simulation_indicators = [
                "SIMULATION",
                "would",
                "simulate",
                "noop",
                "dry"
            ]
            
            found_simulation = any(indicator.lower() in output.lower() 
                                 for indicator in simulation_indicators)
            assert found_simulation, f"Expected simulation output, got: {output}"
            
        except subprocess.TimeoutExpired:
            pytest.fail("CLI command timed out - possible BLE blocking")
        except FileNotFoundError:
            pytest.skip("CLI command not found - package not installed")

    def test_bb8_controller_simulate_method(self):
        """Test Bb8Controller.simulate() method directly"""
        try:
            from ha_sphero_bb8.bb8_control import Bb8Controller
            
            # Capture stdout to verify simulation output
            with patch('sys.stdout', new_callable=StringIO) as mock_stdout:
                controller = Bb8Controller()
                controller.simulate()
                
                output = mock_stdout.getvalue()
                assert len(output) > 0, "simulate() should produce output"
                assert "simulation" in output.lower() or "would" in output.lower(), \
                    f"Expected simulation language, got: {output}"
                    
        except ImportError:
            pytest.skip("Bb8Controller not available for import")

    def test_integration_stub_noop(self):
        """Test integration stub noop functionality"""
        try:
            from ha_sphero_bb8.integration_stub import BB8ServiceStub
            
            stub = BB8ServiceStub()
            result = stub.noop()
            
            # Validate the actual return structure
            assert isinstance(result, dict), "noop() should return a dictionary"
            assert "status" in result, "Result should contain status field"
            assert result["status"] == "noop", f"Expected status 'noop', got {result['status']}"
            
        except ImportError:
            pytest.skip("Integration stub not available for import")

    def test_ble_gateway_safety_toggle(self):
        """Test that BLE gateway has safety toggle mechanism"""
        try:
            from ha_sphero_bb8.ble_gateway import BLE_ENABLED
            
            # BLE_ENABLED should be a boolean
            assert isinstance(BLE_ENABLED, bool), "BLE_ENABLED should be a boolean flag"
            
            # Should be True by default based on the code
            assert BLE_ENABLED is True, "BLE_ENABLED should be True by default"
            
        except ImportError:
            pytest.skip("BLE gateway not available for import")

    def test_console_script_entry_point(self):
        """Test that console script entry point is properly configured"""
        # This test validates the packaging, not runtime behavior
        try:
            import pkg_resources
            
            # Check if our console script is registered
            entry_points = list(pkg_resources.iter_entry_points('console_scripts', 'bb8-control'))
            
            if len(entry_points) == 0:
                pytest.skip("Console script not installed - run pip install -e .")
            
            ep = entry_points[0]
            assert ep.module_name == 'ha_sphero_bb8.launch_bb8'
            assert ep.attrs == ('main',)
            
        except ImportError:
            pytest.skip("pkg_resources not available")

    @patch('ha_sphero_bb8.ble_gateway.BLE_ENABLED', False)
    def test_ble_disabled_fallback(self):
        """Test behavior when BLE is disabled"""
        try:
            from ha_sphero_bb8.ble_gateway import connect_bb8
            
            # When BLE is disabled, connect_bb8 should return None safely
            result = connect_bb8()
            assert result is None, "connect_bb8() should return None when BLE disabled"
            
        except ImportError:
            pytest.skip("BLE gateway not available for import")


class TestPhase0Readiness:
    """Tests specifically for Phase 0 completion criteria"""

    def test_package_structure_exists(self):
        """Verify expected package structure exists"""
        expected_modules = [
            'ha_sphero_bb8',
            'ha_sphero_bb8.launch_bb8',
            'ha_sphero_bb8.bb8_control', 
            'ha_sphero_bb8.ble_gateway',
            'ha_sphero_bb8.integration_stub'
        ]
        
        missing_modules = []
        for module_name in expected_modules:
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                missing_modules.append(module_name)
        
        if missing_modules:
            pytest.skip(f"Missing modules: {missing_modules} - package not properly installed")

    def test_no_live_ble_required(self):
        """Ensure Phase 0 tests don't require live BLE hardware"""
        # This test passes if we get here - validates that our test suite
        # doesn't require actual BB-8 hardware for Phase 0 validation
        assert True, "Phase 0 tests should not require live BLE hardware"


if __name__ == "__main__":
    # Allow running tests directly
    pytest.main([__file__, "-v"])
