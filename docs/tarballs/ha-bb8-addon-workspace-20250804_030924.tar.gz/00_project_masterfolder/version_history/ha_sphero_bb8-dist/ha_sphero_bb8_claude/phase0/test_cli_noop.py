#!/usr/bin/env python3
"""
Test suite for ha-sphero-bb8 CLI noop functionality
Phase 0 requirement: Validate dry-run path emits expected output
"""

import subprocess
import sys
import pytest
from unittest.mock import patch, MagicMock
from io import StringIO

# Test the CLI entrypoint directly
def test_cli_noop_via_subprocess():
    """Test CLI --noop flag via subprocess call"""
    try:
        result = subprocess.run([
            sys.executable, '-m', 'ha_sphero_bb8.launch_bb8', '--noop'
        ], capture_output=True, text=True, timeout=10)
        
        # Validate exit code
        assert result.returncode == 0, f"CLI exited with code {result.returncode}"
        
        # Validate expected output patterns
        expected_patterns = [
            "[SIMULATION]",
            "BB-8 would roll",
            "stop"
        ]
        
        output = result.stdout + result.stderr
        for pattern in expected_patterns:
            assert pattern in output, f"Missing expected pattern: {pattern}"
            
        print(f"✅ CLI noop test passed. Output: {output}")
        
    except subprocess.TimeoutExpired:
        pytest.fail("CLI command timed out - possible BLE blocking")
    except FileNotFoundError:
        pytest.fail("Module not installed or not in path")

def test_bb8_controller_simulate():
    """Test Bb8Controller.simulate() method directly"""
    from ha_sphero_bb8.bb8_control import Bb8Controller
    
    # Capture stdout to verify simulation output
    with patch('sys.stdout', new_callable=StringIO) as mock_stdout:
        controller = Bb8Controller()
        controller.simulate()
        
        output = mock_stdout.getvalue()
        assert "[SIMULATION]" in output
        assert "BB-8 would roll" in output or "would" in output.lower()

def test_no_ble_initialization_in_noop():
    """Ensure BLE gateway is not initialized during noop mode"""
    from ha_sphero_bb8.ble_gateway import BLE_ENABLED
    
    # BLE should be togglable but not auto-activated in tests
    if not BLE_ENABLED:
        print("✅ BLE safely disabled for testing")
    else:
        print("⚠️  BLE enabled - ensure test environment can handle BLE calls")

def test_integration_stub_noop():
    """Test integration stub noop functionality"""
    from ha_sphero_bb8.integration_stub import BB8ServiceStub
    
    stub = BB8ServiceStub()
    result = stub.noop()
    
    assert result == {"status": "noop"}
    assert "[STUB] Noop triggered" in str(result) or result["status"] == "noop"

def test_module_imports_without_ble():
    """Ensure core modules import successfully even if BLE unavailable"""
    try:
        from ha_sphero_bb8 import bb8_control, integration_stub, launch_bb8
        print("✅ Core modules import successfully")
    except ImportError as e:
        if "bleak" in str(e).lower():
            pytest.skip("BLE dependency not installed - expected in Phase 0")
        else:
            pytest.fail(f"Unexpected import error: {e}")

# Phase 0 packaging validation
def test_console_script_registration():
    """Test that bb8-control console script is properly registered"""
    import pkg_resources
    
    try:
        # Check if entrypoint is registered
        entry_points = list(pkg_resources.iter_entry_points('console_scripts', 'bb8-control'))
        assert len(entry_points) > 0, "bb8-control console script not registered"
        
        # Validate it points to correct module
        ep = entry_points[0]
        assert ep.module_name == 'ha_sphero_bb8.launch_bb8'
        assert ep.attrs == ('main',)
        
        print("✅ Console script properly registered")
        
    except Exception as e:
        pytest.skip(f"Package not installed or entry point issue: {e}")

if __name__ == "__main__":
    # Run tests directly for CLI validation
    test_cli_noop_via_subprocess()
    test_bb8_controller_simulate()
    test_no_ble_initialization_in_noop()
    test_integration_stub_noop()
    test_module_imports_without_ble()
    print("🎯 All Phase 0 CLI validation tests passed!")
