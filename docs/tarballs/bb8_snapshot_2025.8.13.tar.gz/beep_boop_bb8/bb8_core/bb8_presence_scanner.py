# Step 3: Extended Discovery Publisher
def publish_extended_discovery(client, base, device_id, device_block):
    """
    Publish extended Home Assistant discovery configs for LED, sleep, drive, heading, speed.
    Topics and payloads match those in discovery_publish.py for compatibility.
    """
    avail = {
        "availability_topic": "bb8/status",
        "payload_available": "online",
        "payload_not_available": "offline",
    }
    # LED (light)
    led = {
        "name": "BB-8 LED",
        "unique_id": f"{device_id}_led",
        "schema": "json",
        "command_topic": f"{base}/cmd/led_set",
        "state_topic": f"{base}/state/led",
        "supported_color_modes": ["rgb"],
        **avail,
        "device": device_block,
    }
    client.publish(f"homeassistant/light/bb8_{device_id}_led/config", json.dumps(led), qos=1, retain=True)

    # Sleep button
    sleep = {
        "name": "BB-8 Sleep",
        "unique_id": f"{device_id}_sleep",
        "command_topic": f"{base}/cmd/sleep",
        "state_topic": f"{base}/state/stop",
        **avail,
        "entity_category": "config",
        "device": device_block,
    }
    client.publish(f"homeassistant/button/bb8_{device_id}_sleep/config", json.dumps(sleep), qos=1, retain=True)

    # Drive button
    drive = {
        "name": "BB-8 Drive",
        "unique_id": f"{device_id}_drive",
        "command_topic": f"{base}/cmd/drive",
        "state_topic": f"{base}/state/drive",
        **avail,
        "device": device_block,
    }
    client.publish(f"homeassistant/button/bb8_{device_id}_drive/config", json.dumps(drive), qos=1, retain=True)

    # Heading number
    heading = {
        "name": "BB-8 Heading",
        "unique_id": f"{device_id}_heading",
        "command_topic": f"{base}/cmd/heading_set",
        "state_topic": f"{base}/state/heading",
        **avail,
        "min": 0, "max": 359, "step": 1, "mode": "slider",
        "device": device_block,
    }
    client.publish(f"homeassistant/number/bb8_{device_id}_heading/config", json.dumps(heading), qos=1, retain=True)

    # Speed number
    speed = {
        "name": "BB-8 Speed",
        "unique_id": f"{device_id}_speed",
        "command_topic": f"{base}/cmd/speed_set",
        "state_topic": f"{base}/state/speed",
        **avail,
        "min": 0, "max": 255, "step": 1, "mode": "slider",
        "device": device_block,
    }
    client.publish(f"homeassistant/number/bb8_{device_id}_speed/config", json.dumps(speed), qos=1, retain=True)

    logger.info("Published extended HA discovery for device_id=%s", device_id)
# Step 2: Device Identity Helpers
def make_device_id(mac: str) -> str:
    """
    Normalize MAC to lowercase hex without colons (e.g., 'AA:BB:CC:DD:EE:FF' -> 'aabbccddeeff').
    """
    return (mac or '').replace(':', '').lower()

def make_base(device_id: str) -> str:
    """
    Produce base MQTT topic for this device (e.g., 'bb8/aabbccddeeff').
    """
    return f"bb8/{device_id}"
"""
bb8_presence_scanner.py
Daemon: Periodically scans for BB-8 (Sphero) and publishes presence/RSSI to MQTT.
Implements Home Assistant MQTT Discovery, explicit birth/LWT, and a rich device block.
"""

import argparse
import asyncio
import json
import logging
import os
import time
from pathlib import Path

import yaml
from bleak import BleakScanner
import paho.mqtt.client as mqtt
from paho.mqtt.enums import CallbackAPIVersion

# -----------------------------------------------------------------------------
# Add-on / configuration helpers
# -----------------------------------------------------------------------------

CONFIG_PATH = Path("/addons/local/beep_boop_bb8/config.yaml")

def _load_addon_version() -> str:
    v = os.getenv("BB8_ADDON_VERSION")
    if v:
        return str(v)
    try:
        with open(CONFIG_PATH, "r") as fh:
            cfg = yaml.safe_load(fh) or {}
            # Accept 'version' either at root or under 'options'
            return str(cfg.get("version") or (cfg.get("options", {}) or {}).get("version") or "unknown")
    except Exception:
        return "unknown"

ADDON_VERSION = _load_addon_version()

def _load_mqtt_config() -> dict:
    cfg = {}
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH, "r") as fh:
                cfg = yaml.safe_load(fh) or {}
    except Exception:
        cfg = {}
    return {
        "host": os.getenv("MQTT_HOST", cfg.get("mqtt_host", "localhost")),
        "port": int(os.getenv("MQTT_PORT", cfg.get("mqtt_port", 1883))),
        "user": os.getenv("MQTT_USER", cfg.get("mqtt_user", "")),
        "password": os.getenv("MQTT_PASSWORD", cfg.get("mqtt_password", "")),
    }

_MQTT = _load_mqtt_config()

# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------

parser = argparse.ArgumentParser(description="BB-8 BLE presence scanner and MQTT publisher")
parser.add_argument("--bb8_name", default=os.getenv("BB8_NAME", "BB-8"), help="BB-8 BLE name")
parser.add_argument("--scan_interval", type=int, default=int(os.getenv("BB8_SCAN_INTERVAL", "10")), help="Scan interval in seconds")
parser.add_argument("--mqtt_host", default=_MQTT["host"], help="MQTT broker host")
parser.add_argument("--mqtt_port", type=int, default=_MQTT["port"], help="MQTT broker port")
parser.add_argument("--mqtt_user", default=_MQTT["user"], help="MQTT username")
parser.add_argument("--mqtt_password", default=_MQTT["password"], help="MQTT password")
parser.add_argument("--print", action="store_true", help="Print discovery payloads and exit")
parser.add_argument("--once", action="store_true", help="Run one scan cycle and exit")
parser.add_argument("--json", action="store_true", help="Emit JSON on one-shot runs")
parser.add_argument("--verbose", "-v", action="store_true", help="Verbose not-found ticks")
parser.add_argument("--quiet", "-q", action="store_true", help="No periodic tick output")
parser.add_argument("--extended", dest="extended", action="store_true", help="Enable extended Home Assistant entities (LED, drive, sleep, heading, speed)")
parser.add_argument("--no-extended", dest="extended", action="store_false", help="Disable extended Home Assistant entities")
parser.set_defaults(extended=None)

args = parser.parse_args()

# Step 1: Resolve EXTENDED_ENABLED from CLI flag or env var (default: True)
def _env_bool(val, default=True):
    if val is None:
        return default
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        return val.strip().lower() in ("1", "true", "yes", "on")
    return bool(val)

if args.extended is not None:
    EXTENDED_ENABLED = args.extended
else:
    EXTENDED_ENABLED = _env_bool(os.getenv("BB8_EXTENDED", None), default=True)

def _resolve_arg(val, fallback):
    return val if val not in (None, "", "None") else fallback

BB8_NAME = _resolve_arg(args.bb8_name, "BB-8")
SCAN_INTERVAL = int(_resolve_arg(args.scan_interval, 10))
MQTT_HOST = _resolve_arg(args.mqtt_host, _MQTT["host"])
MQTT_PORT = int(_resolve_arg(args.mqtt_port, _MQTT["port"]))
MQTT_USER = _resolve_arg(args.mqtt_user, _MQTT["user"])
MQTT_PASSWORD = _resolve_arg(args.mqtt_password, _MQTT["password"])

print("[DEBUG] Loaded configuration:")
print(f"  BB8_NAME={BB8_NAME!r}")
print(f"  SCAN_INTERVAL={SCAN_INTERVAL}")
print(f"  MQTT_HOST={MQTT_HOST!r}")
print(f"  MQTT_PORT={MQTT_PORT}")
print(f"  MQTT_USER={MQTT_USER!r}")
print(f"  MQTT_PASSWORD={'***' if MQTT_PASSWORD else None}")
print(f"  Config path: {CONFIG_PATH}")
print(f"  Add-on version: {ADDON_VERSION}")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bb8_presence_scanner")

# -----------------------------------------------------------------------------
# MQTT client with birth/LWT
# -----------------------------------------------------------------------------

AVAIL_TOPIC = "bb8/status"
AVAIL_ON = "online"
AVAIL_OFF = "offline"

# Use Paho v2 callback API to avoid deprecation warnings
mqtt_client = mqtt.Client(
    CallbackAPIVersion.VERSION2,
    client_id="bb8_presence_scanner",
    protocol=mqtt.MQTTv311,
)
if MQTT_USER and MQTT_PASSWORD:
    mqtt_client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
mqtt_client.will_set(AVAIL_TOPIC, payload=AVAIL_OFF, qos=1, retain=True)

# v2 signature: (client, userdata, flags, reason_code, properties)

def _on_connect(client, userdata, flags, reason_code, properties):
    client.publish(AVAIL_TOPIC, payload=AVAIL_ON, qos=1, retain=True)  # Birth message
    logger.info("MQTT connected. Birth message published. reason_code=%s", reason_code)

    # Step 4: Subscribe to extended command topics if enabled
    if EXTENDED_ENABLED:
        # These will be set after MAC is known, but subscribe to all possible topics for now
        for topic in [
            "bb8/+/cmd/led_set",
            "bb8/+/cmd/sleep",
            "bb8/+/cmd/heading_set",
            "bb8/+/cmd/speed_set",
            "bb8/+/cmd/drive",
        ]:
            client.subscribe(topic, qos=1)

        client.on_message = _on_message_ext


# Step 4: Extended command handler
def _on_message_ext(client, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode("utf-8", "ignore").strip()
    logger.info({"event": "ext_cmd", "topic": topic, "payload": payload})
    # Parse device_id from topic (bb8/{device_id}/cmd/xxx)
    import re
    m = re.match(r"bb8/([^/]+)/cmd/(led_set|sleep|heading_set|speed_set|drive)", topic)
    if not m:
        return
    device_id, cmd = m.group(1), m.group(2)
    base = f"bb8/{device_id}"

    if cmd == "led_set":
        try:
            if payload.upper() == "OFF":
                state = {"state": "OFF"}
            else:
                d = json.loads(payload) if payload else {}
                if "hex" in d:
                    hx = d["hex"].lstrip("#")
                    state = {"r": int(hx[0:2],16), "g": int(hx[2:4],16), "b": int(hx[4:6],16)}
                elif {"r","g","b"}.issubset(d.keys()):
                    state = {"r": int(d["r"]), "g": int(d["g"]), "b": int(d["b"])}
                else:
                    return
            client.publish(f"{base}/state/led", json.dumps(state), qos=1, retain=True)
            logger.info({"event": "led_state_ext", "value": state})
        except Exception as e:
            logger.warning({"event": "led_set_error_ext", "error": repr(e)})
    elif cmd == "sleep":
        try:
            client.publish(f"{base}/state/stop", "pressed", qos=1, retain=False)
            time.sleep(0.2)
            client.publish(f"{base}/state/stop", "idle", qos=1, retain=False)
            logger.info({"event": "sleep_pressed_ext"})
        except Exception as e:
            logger.warning({"event": "sleep_pressed_error_ext", "error": repr(e)})
    elif cmd == "heading_set":
        try:
            val = int(payload)
            val = max(0, min(359, val))
            client.publish(f"{base}/state/heading", str(val), qos=1, retain=True)
            logger.info({"event": "heading_set_ext", "value": val})
        except Exception as e:
            logger.warning({"event": "heading_set_error_ext", "error": repr(e)})
    elif cmd == "speed_set":
        try:
            val = int(payload)
            val = max(0, min(255, val))
            client.publish(f"{base}/state/speed", str(val), qos=1, retain=True)
            logger.info({"event": "speed_set_ext", "value": val})
        except Exception as e:
            logger.warning({"event": "speed_set_error_ext", "error": repr(e)})
    elif cmd == "drive":
        try:
            d = json.loads(payload) if payload else {}
            # Optionally validate keys: heading_deg, speed, duration_ms
            logger.info({"event": "drive_cmd_ext", "value": d})
            # Optionally publish transient feedback
            client.publish(f"{base}/state/drive", json.dumps({"ack": True, **d}), qos=1, retain=False)
        except Exception as e:
            logger.warning({"event": "drive_cmd_error_ext", "error": repr(e)})

mqtt_client.on_connect = _on_connect

def _connect_mqtt():
    mqtt_client.connect(MQTT_HOST, MQTT_PORT, keepalive=60)
    mqtt_client.loop_start()

# --------------------------------------------------
#  H1: Flat-namespace command wiring (façade-only)
# --------------------------------------------------
BASE = os.environ.get("MQTT_BASE", "bb8")

def _pub(topic, payload, qos=1, retain=False):
    if isinstance(payload, (dict, list)):
        payload = json.dumps(payload, ensure_ascii=False)
    mqtt_client.publish(topic, payload, qos=qos, retain=retain)

# -- POWER ---------------------------------------------------
def _on_power_set(_c, _u, msg):
    try:
        val = (msg.payload.decode("utf-8", "ignore").strip().upper())
        if val not in ("ON", "OFF"):
            return
        # Immediate façade echo; device-level echo (source="device") may follow from bridge
        _pub(f"{BASE}/power/state", {"value": val, "source": "facade"}, qos=1, retain=True)
        logger.info({"event":"power_ack_facade", "value":val})
    except Exception as e:
        logger.warning({"event":"power_ack_error", "error":repr(e)})

mqtt_client.message_callback_add(f"{BASE}/power/set", _on_power_set)
mqtt_client.subscribe([(f"{BASE}/power/set", 1)])

# -- STOP -----------------------------------------------------------------
def _on_stop_press(_c, _u, msg):
    try:
        _pub(f"{BASE}/stop/state", "pressed", qos=1, retain=False)
        logger.info({"event":"stop_pressed_facade"})
    except Exception as e:
        logger.warning({"event":"stop_pressed_error", "error":repr(e)})

mqtt_client.message_callback_add(f"{BASE}/stop/press", _on_stop_press)
mqtt_client.subscribe([(f"{BASE}/stop/press", 1)])

# LED ------------------------------------------------------------------
def _on_led_set(_c, _u, msg):
    try:
        raw = msg.payload.decode("utf-8", "ignore").strip()
        rgb = None
        # accept {"r":..,"g":..,"b":..} | {"hex":"#RRGGBB"} | "OFF"
        try:
            d = json.loads(raw) if raw else {}
            if "hex" in d:
                hx = d["hex"].lstrip("#")
                rgb = {"r": int(hx[0:2],16), "g": int(hx[2:4],16), "b": int(hx[4:6],16)}
            elif {"r","g","b"}.issubset(d.keys()):
                rgb = {"r": int(d["r"]), "g": int(d["g"]), "b": int(d["b"])}
        except Exception:
            if raw.upper() == "OFF":
                rgb = {"state":"OFF"}
        if rgb is None:
            return
        _pub(f"{BASE}/led/state", rgb, qos=1, retain=True)
        logger.info({"event":"led_state_facade", "value":rgb})
    except Exception as e:
        logger.warning({"event":"led_set_error", "error":repr(e)})

mqtt_client.message_callback_add(f"{BASE}/led/set", _on_led_set)
mqtt_client.subscribe([(f"{BASE}/led/set", 1)])


# -----------------------------------------------------------------------------
# BLE helpers
# -----------------------------------------------------------------------------

def _extract_mac_and_dbus(device):
    """
    Return (MAC, D-Bus object path) from a Bleak BLEDevice, when possible.
    """
    details = getattr(device, "details", {}) or {}
    props = details.get("props", {}) or {}
    mac = (props.get("Address") or getattr(device, "address", "") or "").upper()
    if not mac and getattr(device, "address", ""):
        mac = device.address.upper()
    dbus_path = details.get("path") or (f"/org/bluez/hci0/dev_{mac.replace(':','_')}" if mac else None)
    return mac or None, dbus_path

def build_device_block(mac: str, dbus_path: str, model: str, name: str = "BB-8") -> dict:
    """
    Build a Home Assistant-compliant 'device' block for MQTT Discovery.
    """
    mac_norm = mac.upper()
    slug = "bb8-" + mac_norm.replace(":", "").lower()
    return {
        "identifiers": [
            f"ble:{mac_norm}",
            "uuid:0000fe07-0000-1000-8000-00805f9b34fb",
            f"mqtt:{slug}",
        ],
        "connections": [
            ["mac", mac_norm],
            ["dbus", dbus_path],
        ],
        "manufacturer": "Sphero",
        "model": model,
        "name": name,
        "sw_version": f"addon:{ADDON_VERSION}",
    }

def publish_discovery(client: mqtt.Client, mac: str, dbus_path: str, model: str = "S33 BB84 LE", name: str = "BB-8"):
    """
    Publish Home Assistant discovery for Presence and RSSI with full device block.
    """
    base = "bb8"
    device = build_device_block(mac, dbus_path, model=model, name=name)
    uid_suffix = mac.replace(":", "").lower()
    availability = {
        "availability_topic": AVAIL_TOPIC,
        "payload_available": AVAIL_ON,
        "payload_not_available": AVAIL_OFF,
    }
    presence_disc = {
        "name": f"{name} Presence",
        "unique_id": f"bb8_presence_{uid_suffix}",
        "state_topic": f"{base}/sensor/presence",
        "payload_on": "on",
        "payload_off": "off",
        "device_class": "connectivity",
        **availability,
        "device": device,
    }
    rssi_disc = {
        "name": f"{name} RSSI",
        "unique_id": f"bb8_rssi_{uid_suffix}",
        "state_topic": f"{base}/sensor/rssi",
        "unit_of_measurement": "dBm",
        "state_class": "measurement",
        "device_class": "signal_strength",
        **availability,
        "device": device,
    }
    client.publish("homeassistant/binary_sensor/bb8_presence/config", json.dumps(presence_disc), qos=1, retain=True)
    client.publish("homeassistant/sensor/bb8_rssi/config", json.dumps(rssi_disc), qos=1, retain=True)
    logger.info("Published HA discovery for MAC=%s", mac)

# -----------------------------------------------------------------------------
# Logging helpers
# -----------------------------------------------------------------------------

def tick_log(found: bool, name: str, addr: str | None, rssi):
    ts = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    if args.quiet:
        return
    if args.json:
        print(json.dumps({"ts": int(time.time()), "found": found, "name": name, "address": addr, "rssi": rssi}))
    else:
        if found:
            print(f"[{ts}] found name={name} addr={addr} rssi={rssi}")
        elif args.verbose:
            print(f"[{ts}] not_found name={name}")

# -----------------------------------------------------------------------------
# Main loop
# -----------------------------------------------------------------------------

async def scan_and_publish():
    """
    Scan loop: find BB-8, publish presence/RSSI (retained), publish discovery once per MAC.
    """
    published_discovery_for = None  # last MAC we advertised
    model_hint = "S33 BB84 LE"

    while True:
        try:
            devices = await BleakScanner.discover()
            found = False
            rssi = None
            mac = None
            dbus_path = None

            for d in devices:
                if BB8_NAME.lower() in (d.name or "").lower():
                    found = True
                    rssi = getattr(d, "rssi", None)
                    if rssi is None:
                        rssi = ((getattr(d, "details", {}) or {}).get("props", {}) or {}).get("RSSI")
                    mac, dbus_path = _extract_mac_and_dbus(d)
                    logger.info("Found BB-8: %s [%s] RSSI: %s UUIDs: %s",
                                d.name, mac, rssi,
                                ((getattr(d, 'details', {}) or {}).get('props', {}) or {}).get('UUIDs'))
                    break


            # Publish discovery (once per MAC) after we know identifiers
            if found and mac and dbus_path and published_discovery_for != mac:
                # Minimal discovery (presence/RSSI)
                publish_discovery(mqtt_client, mac, dbus_path, model=model_hint, name="BB-8")
                # Extended discovery (if enabled)
                if EXTENDED_ENABLED:
                    device_id = make_device_id(mac)
                    base = make_base(device_id)
                    device_block = build_device_block(mac, dbus_path, model=model_hint, name="BB-8")
                    publish_extended_discovery(mqtt_client, base, device_id, device_block)
                published_discovery_for = mac

            # Telemetry (retained)
            mqtt_client.publish("bb8/sensor/presence", "on" if found else "off", qos=1, retain=True)
            mqtt_client.publish("bb8/sensor/rssi", "" if rssi is None else str(int(rssi)), qos=1, retain=True)

            tick_log(found, BB8_NAME, mac, rssi)

        except Exception as e:
            logger.error("Presence scan error: %s", e)

        await asyncio.sleep(SCAN_INTERVAL)

# -----------------------------------------------------------------------------
# Entrypoint
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    if args.print:
        # Discovery is emitted lazily after MAC/DBus are known; nothing to print upfront
        print("# discovery will be published after a successful scan when MAC/DBus are known")
        raise SystemExit(0)

    if args.once:
        async def _once():
            devices = await BleakScanner.discover()
            res = {"found": False, "name": BB8_NAME, "address": None, "rssi": None}
            for d in devices:
                if BB8_NAME.lower() in (d.name or "").lower():
                    res = {"found": True, "name": d.name or BB8_NAME, "address": getattr(d, "address", None),
                           "rssi": getattr(d, "rssi", None)}
                    break
            if args.json:
                print(json.dumps(res))
            else:
                tick_log(res["found"], res["name"], res["address"], res["rssi"])
        asyncio.run(_once())
    else:
        _connect_mqtt()
        asyncio.run(scan_and_publish())
