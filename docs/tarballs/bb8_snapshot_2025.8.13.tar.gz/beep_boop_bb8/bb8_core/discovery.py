# Deprecated: functionality moved into bb8_presence_scanner.py:publish_discovery(...)
from .bb8_presence_scanner import publish_discovery  # noqa: F401
