from __future__ import annotations
import threading
import time
from .logging_setup import logger

class TelemetryLoop:
    def __init__(self, bridge, interval_s: int = 20):
        self.bridge = bridge
        self.interval_s = interval_s
        self._stop = threading.Event()
        self._t = None

    def start(self):
        if self._t and self._t.is_alive():
            return
        self._stop.clear()
        self._t = threading.Thread(target=self._run, daemon=True)
        self._t.start()
        logger.info({"event": "telemetry_start", "interval_s": self.interval_s})

    def stop(self):
        self._stop.set()
        if self._t:
            self._t.join(timeout=2)
        logger.info({"event": "telemetry_stop"})

    def _run(self):
        while not self._stop.is_set():
            try:
                # presence: consider “connected” as online; adapt if you have a richer signal
                online = True if getattr(self.bridge, "is_connected", lambda: True)() else False
                if hasattr(self.bridge, "publish_presence"):
                    self.bridge.publish_presence(online)

                # rssi: adapt to your gateway/bridge API
                get_rssi = getattr(self.bridge, "get_rssi", None)
                if callable(get_rssi):
                    dbm = get_rssi()
                    if hasattr(self.bridge, "publish_rssi"):
                        if isinstance(dbm, (int, float, str)):
                            self.bridge.publish_rssi(int(dbm))
                        else:
                            logger.warning({"event": "telemetry_invalid_rssi", "dbm": repr(dbm)})
            except Exception as e:
                logger.warning({"event": "telemetry_error", "error": repr(e)})
            finally:
                time.sleep(self.interval_s)
