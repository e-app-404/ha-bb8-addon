
import os
import json
from bb8_core.logging_setup import logger
from .discovery import discovery_payloads

PROFILE = os.environ.get("BB8_DISCOVERY_PROFILE", "extended")  # "minimal" | "extended"

def _json(obj):
    return json.dumps(obj, separators=(",", ":"))

def publish_discovery(client, base_topic, availability_topic="bb8/status", qos=1, retain=True, device=None):
    published = 0
    # Core entities
    published += _publish_presence_sensor(client, base_topic, availability_topic, qos, retain, device)
    published += _publish_rssi_sensor(client, base_topic, availability_topic, qos, retain, device)
    # Extended profile adds: sleep button, drive button, heading number, speed number
    if PROFILE != "minimal":
        published += _publish_sleep_button(client, base_topic, availability_topic, qos, retain, device)
        published += _publish_drive_button(client, base_topic, availability_topic, qos, retain, device)
        published += _publish_heading_number(client, base_topic, availability_topic, qos, retain, device)
        published += _publish_speed_number(client, base_topic, availability_topic, qos, retain, device)
    logger.info({"event": "discovery_published", "count": published, "profile": PROFILE})
    return published

# ---------- extended entities ----------
def _publish_sleep_button(client, base, avail, qos, retain, device):
    obj = {
        "name": "BB-8 Sleep",
        "unique_id": f"{base}_sleep",
        "command_topic": f"{base}/sleep/press",
        "state_topic": f"{base}/sleep/state",
        "availability_topic": avail,
        "entity_category": "config",
        "device": device or {},
    }
    topic = f"homeassistant/button/{base.replace('/','_')}_sleep/config"
    client.publish(topic, payload=_json(obj), qos=qos, retain=True)
    logger.info(f"discovery: published {topic}")
    return 1

def _publish_drive_button(client, base, avail, qos, retain, device):
    obj = {
        "name": "BB-8 Drive",
        "unique_id": f"{base}_drive",
        "command_topic": f"{base}/drive/press",
        "state_topic": f"{base}/drive/state",
        "availability_topic": avail,
        "device": device or {},
    }
    topic = f"homeassistant/button/{base.replace('/','_')}_drive/config"
    client.publish(topic, payload=_json(obj), qos=qos, retain=True)
    logger.info(f"discovery: published {topic}")
    return 1

def _publish_heading_number(client, base, avail, qos, retain, device):
    obj = {
        "name": "BB-8 Heading",
        "unique_id": f"{base}_heading",
        "command_topic": f"{base}/heading/set",
        "state_topic": f"{base}/heading/state",
        "availability_topic": avail,
        "min": 0, "max": 359, "step": 1,
        "mode": "slider",
        "device": device or {},
    }
    topic = f"homeassistant/number/{base.replace('/','_')}_heading/config"
    client.publish(topic, payload=_json(obj), qos=qos, retain=True)
    logger.info(f"discovery: published {topic}")
    return 1

def _publish_speed_number(client, base, avail, qos, retain, device):
    obj = {
        "name": "BB-8 Speed",
        "unique_id": f"{base}_speed",
        "command_topic": f"{base}/speed/set",
        "state_topic": f"{base}/speed/state",
        "availability_topic": avail,
        "min": 0, "max": 255, "step": 1,
        "mode": "slider",
        "device": device or {},
    }
    topic = f"homeassistant/number/{base.replace('/','_')}_speed/config"
    client.publish(topic, payload=_json(obj), qos=qos, retain=True)
    logger.info(f"discovery: published {topic}")
    return 1

def _publish_presence_sensor(client, base, avail, qos, retain, device):
    obj = {
        "name": "BB-8 Presence",
        "unique_id": f"{base}_presence",
        "state_topic": f"{base}/presence/state",
        "availability_topic": avail,
        "payload_on": "ON",
        "payload_off": "OFF",
        "device_class": "presence",
        "device": device or {},
    }
    topic = f"homeassistant/sensor/{base.replace('/','_')}_presence/config"
    client.publish(topic, payload=_json(obj), qos=qos, retain=True)
    logger.info(f"discovery: published {topic}")
    return 1

def _publish_rssi_sensor(client, base, avail, qos, retain, device):
    obj = {
        "name": "BB-8 RSSI",
        "unique_id": f"{base}_rssi",
        "state_topic": f"{base}/rssi/state",
        "availability_topic": avail,
        "unit_of_measurement": "dBm",
        "state_class": "measurement",
        "device_class": "signal_strength",
        "device": device or {},
    }
    topic = f"homeassistant/sensor/{base.replace('/','_')}_rssi/config"
    client.publish(topic, payload=_json(obj), qos=qos, retain=True)
    logger.info(f"discovery: published {topic}")
    return 1
