#
"""
mqtt_dispatcher.py

Connects to the MQTT broker, subscribes to command topics, dispatches commands to the BLE bridge/controller, and publishes status and discovery information for Home Assistant.
"""
# Finalized for Home Assistant runtime (2025-08-04)

from __future__ import annotations
from typing import Optional, Any
import socket
import os
import json
import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish  # uncommented because publish.single is used
from .logging_setup import logger

REASONS = {
    0: "success",
    1: "unacceptable_protocol_version",
    2: "identifier_rejected",
    3: "server_unavailable",
    4: "bad_username_or_password",
    5: "not_authorized",
}

# Placeholder for BLE bridge import
try:
    from bb8_core.ble_bridge import BLEBridge
except ImportError:
    BLEBridge = None

def start_mqtt_dispatcher(
    mqtt_host: str,
    mqtt_port: int,
    mqtt_topic: str,
    username: Optional[str] = None,
    password: Optional[str] = None,
    controller: Any = None,
    client_id: str = "bb8-addon",
    keepalive: int = 60,
    qos: int = 1,
    retain: bool = True,
    status_topic: str = "bb8/status",
    # gateway: Optional[BleGateway] = None,  # Remove BLE-specific API from dispatcher
    tls: bool = False,
    # Back-compat aliases (deprecated; prefer username/password)
    mqtt_user: Optional[str] = None,
    mqtt_password: Optional[str] = None,
) -> mqtt.Client:
    """
    Single entry-point used by bridge_controller via the compat shim.
    Explicit arg names (mqtt_host/mqtt_port/mqtt_topic) remove ambiguity.

    - Publishes LWT: status_topic=offline (retain)
    - On connect: status_topic=online (retain), hands the client to controller
    - Reason-logged connect/disconnect
    - Optional TLS (default False)
    """
    # Back-compat aliasing
    if (username is None or username == "") and mqtt_user:
        username = mqtt_user
    if (password is None or password == "") and mqtt_password is not None:
        password = mqtt_password
    try:
        if mqtt_user is not None or mqtt_password is not None:
            logger.warning({"event": "dispatcher_param_deprecated",
                            "hint": "Use username/password instead of mqtt_user/mqtt_password"})
    except Exception:
        pass

    resolved = None
    try:
        resolved = socket.gethostbyname(mqtt_host)
    except Exception:
        resolved = "unresolved"

    logger.info({
        "event": "mqtt_connect_attempt",
        "host": mqtt_host,
        "port": mqtt_port,
        "resolved": resolved,
        "client_id": client_id,
        "user": bool(username),
        "tls": tls,
        "topic": mqtt_topic,
        "status_topic": status_topic,
    })

    # Paho v2 API (compatible with our version); v311 is fine for HA
    client = mqtt.Client(client_id=client_id, protocol=mqtt.MQTTv311, clean_session=True)

    # Auth
    if username is not None:
        client.username_pw_set(username=username, password=(password or ""))

    # TLS (optional)
    if tls:
        client.tls_set()           # customize CA/cert paths if needed
        # client.tls_insecure_set(True)  # only if you accept self-signed risk

    # LWT/availability
    client.will_set(status_topic, payload="offline", qos=qos, retain=True)

    # Reconnect backoff (let paho handle retries)
    client.reconnect_delay_set(min_delay=1, max_delay=30)

    # ---- Callbacks ----
    def _on_connect(c, u, flags, rc, properties=None):
        reason = REASONS.get(rc, f"unknown_{rc}")
        if rc == 0:
            logger.info({"event": "mqtt_connected", "rc": rc, "reason": reason})
            # mark online
            c.publish(status_topic, payload="online", qos=qos, retain=True)

            # Hand the client to the BB-8 controller (subscribe/publish wiring)
            # Expected to implement: attach_mqtt(client, topic, qos, retain)
            if hasattr(controller, "attach_mqtt"):
                try:
                    controller.attach_mqtt(c, mqtt_topic, qos=qos, retain=retain)
                except Exception as e:
                    logger.error({"event": "controller_attach_mqtt_error", "error": repr(e)})
        else:
            logger.error({"event": "mqtt_connect_failed", "rc": rc, "reason": reason})

    def _on_disconnect(c, u, rc, properties=None):
        # rc==0 = clean; >0 = unexpected
        logger.warning({"event": "mqtt_disconnected", "rc": rc})

    client.on_connect = _on_connect
    client.on_disconnect = _on_disconnect

    # Async connect + network loop
    client.connect_async(mqtt_host, mqtt_port, keepalive)
    client.loop_start()

    return client


    # Discovery is published by facade.attach_mqtt(). Avoid duplicates here.


def turn_on_bb8():
    logger.info("[BB-8] Scanning for device...")
    # Lazy import to localize BLE/Sphero dependencies
    from spherov2.scanner import find_toys
    from spherov2.toy.bb8 import BB8
    from spherov2.adapter.bleak_adapter import BleakAdapter
    from spherov2.sphero_edu import SpheroEduAPI
    from spherov2.types import Color
    devices = find_toys()
    for toy in devices:
        if isinstance(toy, BB8):
            logger.info(f"[BB-8] Connecting to {toy.address} ...")
            bb8 = BB8(toy.address, adapter_cls=BleakAdapter)
            with SpheroEduAPI(bb8) as edu:
                edu.set_main_led(Color(255, 100, 0))
                edu.roll(0, 30, 2)  # heading=0, speed=30, duration=2s
                edu.set_main_led(Color(0, 0, 0))
            logger.info("[BB-8] ON command sent.")
            return True
    logger.warning("[BB-8] No BB-8 found.")
    return False


def turn_off_bb8():
    logger.info("[BB-8] Scanning for device to sleep...")
    # Lazy import to localize BLE/Sphero dependencies
    from spherov2.scanner import find_toys
    from spherov2.toy.bb8 import BB8
    from spherov2.adapter.bleak_adapter import BleakAdapter
    from spherov2.commands.core import IntervalOptions
    devices = find_toys()
    for toy in devices:
        if isinstance(toy, BB8):
            bb8 = BB8(toy.address, adapter_cls=BleakAdapter)
            # Ensure correct enum type for sleep
            bb8.sleep(IntervalOptions(IntervalOptions.NONE), 0, 0, 0)  # type: ignore
            logger.info("[BB-8] OFF (sleep) command sent.")
            return True
    logger.warning("[BB-8] No BB-8 found for sleep.")
    return False


def main():
    # Obtain gateway from config/env or instantiate default
    mqtt_host = os.environ.get("MQTT_HOST", "localhost")
    mqtt_port = int(os.environ.get("MQTT_PORT", "1883"))
    mqtt_topic = os.environ.get("MQTT_TOPIC", "bb8/command/#")
    mqtt_user = os.environ.get("MQTT_USER")
    mqtt_password = os.environ.get("MQTT_PASSWORD")
    status_topic = os.environ.get("STATUS_TOPIC", "bb8/status")

    start_mqtt_dispatcher(
        mqtt_host=mqtt_host,
        mqtt_port=mqtt_port,
        mqtt_topic=mqtt_topic,
        username=mqtt_user,
        password=mqtt_password,
        status_topic=status_topic,
    )


# Call this at container startup

