


#!/usr/bin/with-contenv bash
set -euo pipefail
export PYTHONUNBUFFERED=1
export PYTHONPATH=/app:${PYTHONPATH:-}
cd /app

log(){ echo "$(date -Is) [BB-8] $*"; }



pwd  # debug: print current working directory
log "Starting bridge controller…"

# optional log path override (if jq exists and value set)
if command -v jq >/dev/null 2>&1; then
	LP="$(jq -r '.log_path // empty' /data/options.json 2>/dev/null || true)"
	if [ -n "$LP" ] ; then export BB8_LOG_PATH="$LP"; fi
fi

# Start the Python service
exec /opt/venv/bin/python3 -m bb8_core.bridge_controller
