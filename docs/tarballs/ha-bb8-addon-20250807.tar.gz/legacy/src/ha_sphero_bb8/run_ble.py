#!/usr/bin/env python3
"""
MODULE PURPOSE: Legacy entrypoint for BLE-based BB-8 control. Now delegates to launch_bb8.main().
STATUS: legacy/redirect
MAIN ENTRYPOINTS: main()
DEPENDENCIES: launch_bb8.py
LAST VALIDATED: 2025-06-18
NOTES:
- Use launch_bb8.py for all new CLI launches.
- This script is retained for backward compatibility.
"""

# run_ble.py

import sys
import os
# Find the absolute path to the _vendor directory
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '..', '..'))  # Adjust as needed
vendor_parent = os.path.join(project_root, '_vendor')
if vendor_parent not in sys.path:
    sys.path.insert(0, vendor_parent)
import spherov2  # type: ignore
print("spherov2 loaded from:", spherov2.__file__)

from .launch_bb8 import main as launch_main

BLE_ENABLED = True  # Conservative default; BLE_ENABLED not defined in ble_gateway

__all__: list[str] = []

def main():
    print("[INFO] run_ble.py now delegates to launch_bb8.main() for canonical CLI entry.")
    launch_main()

if __name__ == "__main__":
    main()
