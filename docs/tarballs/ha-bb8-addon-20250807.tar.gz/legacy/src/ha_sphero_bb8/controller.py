"""
MODULE PURPOSE: Main BB-8 controller. Implements device command logic for movement, rotation, diagnostics,
and LED control. All MQTT commands are ultimately routed here via handlers.
STATUS: production
MAIN ENTRYPOINTS: BB8Controller class, handle_command, move_forward, rotate, stop, get_diagnostics
DEPENDENCIES: Called by mqtt_handler.py. Uses device_core/adapter(s), supports dependency injection for simulation.
LAST VALIDATED: 2025-06-18
NOTES:
- Methods should wrap hardware/sim interactions with result wrappers and log failures.
- Update dependency injection paths when simulation/hardware adapters change.
"""

# Do not import run_mqtt.py (entrypoint script) in library code to avoid circular imports.

# src/ha_sphero_bb8/controller.py

from typing import Optional, Dict, Any, runtime_checkable, Protocol
from dataclasses import dataclass
from enum import Enum
from ha_sphero_bb8.ble_gateway import BleGateway, BLEStatus
from ha_sphero_bb8.bb8_protocol import BB8Like

# Import enhanced Phase 1 components
from ha_sphero_bb8.device_core.utils.motor_utils import EnhancedMotorControl, MotorCommandResult
from ha_sphero_bb8.device_core.voltage_diagnostics import VoltageMonitor
from ha_sphero_bb8.device_core.utils.safe_utils import (
    safe_ping,
    safe_set_main_led,
    safe_get_voltage,
    safe_get_percentage
)
from ha_sphero_bb8.ping import heartbeat_loop

"""
Unified BB-8 Controller Integration (β-tier)
Phase 1: Complete integration of BLE, device core, and simulation layers

Provides:
- Unified API abstracting BLE vs simulation modes
- Device core motor and voltage utilities integration
- Comprehensive diagnostics and status reporting
- ζ-tier MQTT preparation with structured payloads

HESTIA Compliance:
- Tier: β (fusion - unified control interface)
- Consumes: α-tier BLE gateway, δ-tier device core utilities
- Exposes: Clean control API to ζ-tier services and CLI
- Abstracts: Hardware complexity behind consistent interface
"""

import logging
import time
import asyncio

logger = logging.getLogger(__name__)

class ControllerMode(Enum):
    """Controller operation modes"""
    HARDWARE = "hardware"       # Live BLE hardware
    OFFLINE = "offline"         # No device control

@dataclass
class ControllerStatus:
    """Complete controller status information"""
    mode: ControllerMode
    device_connected: bool
    ble_status: str
    last_command: Optional[str] = None
    command_count: int = 0
    error_count: int = 0
    uptime: float = 0.0
    features_available: Optional[Dict[str, bool]] = None

"""
Remove DeviceProtocol and all simulation/adapter logic
Remove BB8Adapter class
Remove simulation_adapter, simulation_mode, and related logic
Update ControllerStatus and features_available to only reflect hardware features
"""

class BB8Controller:
    """
    Unified BB-8 Controller (hardware-only, no adapter)

    Provides a single, consistent interface for BB-8 control using the raw device.
    """

    def __init__(self,
                 mode: ControllerMode = ControllerMode.HARDWARE,
                 device=None,
                 mqtt_handler=None):
        self.mode = mode
        self.logger = logging.getLogger(f"{__name__}.BB8Controller")
        self.logger.info(f"[AUDIT] BB8Controller initialized in hardware-only mode")
        self.device = device
        self.ble_gateway = None
        self.motor_control = None
        self.voltage_monitor = None
        self.start_time = time.time()
        self.command_count = 0
        self.error_count = 0
        self.last_command = None
        self.device_connected = True if device is not None else False
        self._heartbeat_task = None
        self._heartbeat_interval = 10  # seconds, configurable
        self._heartbeat_failure_threshold = 3  # configurable
        self._heartbeat_running = False
        self.mqtt_handler = mqtt_handler

    def on_heartbeat_status(self, connected, last_ping_success, consecutive_failures, error):
        self.device_connected = connected
        if self.mqtt_handler:
            self.mqtt_handler.publish_heartbeat(connected, last_ping_success, consecutive_failures, error)

    def start_heartbeat(self, interval: int = 10, failure_threshold: int = 3):
        """Start the periodic heartbeat task using ping.py utility."""
        self._heartbeat_interval = interval
        self._heartbeat_failure_threshold = failure_threshold
        if self._heartbeat_task is None or self._heartbeat_task.done():
            self._heartbeat_task = asyncio.create_task(
                heartbeat_loop(
                    self.device,
                    safe_ping,
                    self._heartbeat_interval,
                    self._heartbeat_failure_threshold,
                    self.on_heartbeat_status,
                    self.logger
                )
            )
            self.logger.info(f"Heartbeat started (interval={interval}s, threshold={failure_threshold})")

    def stop_heartbeat(self):
        """Stop the periodic heartbeat task."""
        self._heartbeat_running = False
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            self.logger.info("Heartbeat stopped.")

    async def _maybe_async(self, func):
        """Helper to call sync or async functions transparently."""
        if asyncio.iscoroutinefunction(func):
            return func
        else:
            async def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
            return wrapper

    def roll(self, speed: int, heading: int, timeout: float = 2.0, roll_mode: int = 0, reverse_flag: bool = False) -> dict:
        self.logger.info(f"Adapter/device repr: {repr(self.device)}")
        if self.device is None:
            return self._create_error_result("roll", "No device present")
        is_connected = getattr(self.device, "is_connected", None)
        connected = True
        if callable(is_connected):
            connected = is_connected()
        elif isinstance(is_connected, bool):
            connected = is_connected
        if not self.device_connected or not connected:
            self.logger.error("BB-8 not connected; roll command aborted")
            return self._create_error_result("roll", "Device not connected")
        self.command_count += 1
        self.last_command = "roll"
        self.logger.info(f"Attempting to roll: speed={speed}, heading={heading}, timeout={timeout}, roll_mode={roll_mode}, reverse_flag={reverse_flag}")
        try:
            import inspect
            if self.motor_control:
                sig = inspect.signature(self.motor_control.roll)
                kwargs = {"speed": speed, "heading": heading, "timeout": timeout, "boost": False}
                if "roll_mode" in sig.parameters:
                    kwargs["roll_mode"] = roll_mode
                if "reverse_flag" in sig.parameters:
                    kwargs["reverse_flag"] = reverse_flag
                result = self.motor_control.roll(**kwargs)
                self.logger.info(f"roll result: {result}")
                if isinstance(result, dict) and result.get("success"):
                    self.logger.info("Roll confirmed on hardware")
                else:
                    self.logger.error("Roll command failed to confirm")
                if isinstance(result, MotorCommandResult):
                    return self._format_command_result(result)
                elif isinstance(result, dict):
                    return result
                else:
                    return self._create_error_result("roll", "Unexpected result type from motor_control.roll")
            elif self.device is not None and not isinstance(self.device, BleGateway):
                if hasattr(self.device, "roll") and callable(self.device.roll):
                    sig = inspect.signature(self.device.roll)
                    kwargs = {"speed": speed, "heading": heading, "timeout": timeout, "boost": False}
                    if "roll_mode" in sig.parameters:
                        kwargs["roll_mode"] = roll_mode
                    if "reverse_flag" in sig.parameters:
                        kwargs["reverse_flag"] = reverse_flag
                    result = self.device.roll(**kwargs)
                    self.logger.info(f"roll result: {result}")
                    if isinstance(result, dict) and result.get("success"):
                        self.logger.info("Roll confirmed on hardware")
                    else:
                        self.logger.error("Roll command failed to confirm")
                    if isinstance(result, dict):
                        return result
                    else:
                        return self._create_error_result("roll", "Device roll did not return a dict")
                else:
                    return self._create_error_result("roll", "Device does not support roll")
            else:
                return self._create_error_result("roll", "Roll capability not available")
        except Exception as e:
            self.error_count += 1
            self.logger.error(f"Roll command failed: {e}")
            return self._create_error_result("roll", str(e))

    def rotate(self, angle: int, speed: int = 50, timeout: float = 2.0, roll_mode: int = 0, reverse_flag: bool = False) -> dict:
        self.logger.info(f"Adapter/device repr: {repr(self.device)}")
        if self.device is None:
            return self._create_error_result("rotate", "No device present")
        is_connected = getattr(self.device, "is_connected", None)
        connected = True
        if callable(is_connected):
            connected = is_connected()
        elif isinstance(is_connected, bool):
            connected = is_connected
        if not self.device_connected or not connected:
            self.logger.error("BB-8 not connected; rotate command aborted")
            return self._create_error_result("rotate", "Device not connected")
        self.logger.info(f"Attempting to rotate: angle={angle}, speed={speed}, timeout={timeout}, roll_mode={roll_mode}, reverse_flag={reverse_flag}")
        result = self.roll(speed=speed, heading=angle, timeout=timeout, roll_mode=roll_mode, reverse_flag=reverse_flag)
        self.logger.info(f"rotate result: {result}")
        return result

    def stop(self) -> Dict[str, Any]:
        self.logger.info(f"Adapter/device repr: {repr(self.device)}")
        if self.device is None:
            return self._create_error_result("stop", "No device present")
        is_connected = getattr(self.device, "is_connected", None)
        connected = True
        if callable(is_connected):
            connected = is_connected()
        elif isinstance(is_connected, bool):
            connected = is_connected
        if not self.device_connected or not connected:
            self.logger.error("BB-8 not connected; stop command aborted")
            return self._create_error_result("stop", "Device not connected")
        self.command_count += 1
        self.last_command = "stop"
        self.logger.info(f"Attempting to stop device")
        try:
            if hasattr(self, 'motor_control') and self.motor_control:
                result = self.motor_control.emergency_stop()
                self.logger.info(f"stop result: {result}")
                if isinstance(result, dict) and result.get("success"):
                    self.logger.info("Stop confirmed on hardware")
                else:
                    self.logger.error("Stop command failed to confirm")
                if isinstance(result, MotorCommandResult):
                    return self._format_command_result(result)
                elif isinstance(result, dict):
                    return result
                else:
                    return self._create_error_result("stop", "Unexpected result type from emergency_stop")
            elif self.device is not None and not isinstance(self.device, BleGateway):
                if hasattr(self.device, "stop") and callable(self.device.stop):
                    result = self.device.stop()
                    self.logger.info(f"stop result: {result}")
                    if result is True or result is None:
                        self.logger.info("Stop confirmed on hardware")
                    else:
                        self.logger.error("Stop command failed to confirm")
                    return {
                        "success": bool(result is True or result is None),
                        "command": "stop",
                        "result": result
                    }
                else:
                    return self._create_error_result("stop", "Device does not support stop")
            else:
                return self._create_error_result("stop", "Stop capability not available")
        except Exception as e:
            self.error_count += 1
            self.logger.error(f"Stop command failed: {e}")
            return self._create_error_result("stop", str(e))

    def set_led(self, r: int, g: int, b: int) -> dict:
        import traceback
        try:
            if self.device is None:
                return {"success": False, "command": "set_led", "error": "No device present"}
            is_connected = getattr(self.device, "is_connected", None)
            connected = True
            if callable(is_connected):
                connected = is_connected()
            elif isinstance(is_connected, bool):
                connected = is_connected
            self.logger.info(f"set_led called with r={r}, g={g}, b={b}, connected={connected}")
            if not self.device_connected or not connected:
                self.logger.warning("set_led aborted: device not connected")
                return {"success": False, "command": "set_led", "error": "Device not connected"}
            if hasattr(self.device, "set_led") and callable(self.device.set_led):
                try:
                    result = self.device.set_led(r, g, b)
                    self.logger.info(f"set_led hardware call returned: {result}")
                    return result if isinstance(result, dict) else {"success": result is None, "command": "set_led", "result": result}
                except NotImplementedError:
                    self.logger.info("set_led not supported by this device (NotImplementedError).")
                    return {"success": False, "command": "set_led", "error": "Not supported by this device"}
            else:
                self.logger.info("set_led aborted: device does not support set_led")
                return {"success": False, "command": "set_led", "error": "Not supported by this device"}
        except Exception as e:
            tb = traceback.format_exc()
            self.logger.warning(f"Error in set_led: {e}\n{tb}")
            return {"success": False, "command": "set_led", "error": str(e), "traceback": tb}

    def get_battery_voltage(self):
        if self.device is not None and hasattr(self.device, "get_battery_voltage"):
            try:
                return self.device.get_battery_voltage()
            except NotImplementedError:
                self.logger.info("get_battery_voltage not supported by this device (NotImplementedError).")
                return None
        self.logger.info("get_battery_voltage not supported by current device.")
        return None

    def get_battery_status(self) -> Dict[str, Any]:
        try:
            if self.voltage_monitor:
                diagnostics = self.voltage_monitor.get_comprehensive_diagnostics()
                logger.info(f"Battery voltage (enhanced): {diagnostics.voltage} V, percentage: {diagnostics.percentage}%")
                return {
                    "success": True,
                    "enhanced": True,
                    "battery": {
                        "voltage": diagnostics.voltage,
                        "percentage": diagnostics.percentage,
                        "state": diagnostics.state.value,
                        "health": diagnostics.health.value,
                        "health_score": diagnostics.health_score,
                        "charging": diagnostics.charging,
                        "current_draw": diagnostics.current_draw,
                        "time_remaining": diagnostics.time_remaining
                    }
                }
            elif self.device is not None:
                voltage = None
                percentage = None
                if hasattr(self.device, "get_battery_voltage"):
                    try:
                        voltage = self.get_battery_voltage()
                    except NotImplementedError:
                        self.logger.info("Battery voltage not supported by this device (NotImplementedError).")
                        voltage = None
                else:
                    self.logger.info("Battery voltage not available: device does not support voltage reading.")
                get_percentage = getattr(self.device, "get_battery_percentage", None)
                if callable(get_percentage):
                    try:
                        percentage = get_percentage()
                    except NotImplementedError:
                        self.logger.info("Battery percentage not supported by this device (NotImplementedError).")
                        percentage = None
                logger.info(f"Battery status: voltage={voltage}, percentage={percentage}")
                return {
                    "success": True,
                    "enhanced": False,
                    "battery": {
                        "voltage": voltage,
                        "percentage": percentage
                    }
                }
            else:
                logger.warning("Battery status not available: no device.")
                return {
                    "success": False,
                    "error": "No device available"
                }
        except Exception as e:
            logger.warning(f"Error getting battery status: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    def get_controller_status(self) -> ControllerStatus:
        uptime = time.time() - self.start_time
        ble_status = "unknown"
        if self.ble_gateway:
            from ha_sphero_bb8.ble_gateway import get_ble_status
            ble_info = get_ble_status()
            if self.device_connected:
                ble_status = ble_info.get("mode", "unknown")
            else:
                ble_status = "disconnected"
        features = {
            "enhanced_motor_control": self.motor_control is not None,
            "voltage_diagnostics": self.voltage_monitor is not None,
            "ble_gateway": self.ble_gateway is not None
        }
        return ControllerStatus(
            mode=self.mode,
            device_connected=self.device_connected,
            ble_status=ble_status,
            last_command=self.last_command,
            command_count=self.command_count,
            error_count=self.error_count,
            uptime=uptime,
            features_available=features
        )

    def get_diagnostics_for_mqtt(self) -> Dict[str, Any]:
        """
        Get complete diagnostics formatted for MQTT/HA integration

        Returns:
            Comprehensive diagnostics payload ready for ζ-tier MQTT handler
        """
        status = self.get_controller_status()
        payload = {
            "controller": {
                "mode": status.mode.value,
                "connected": status.device_connected,
                "ble_status": status.ble_status,
                "uptime": status.uptime,
                "commands_executed": status.command_count,
                "errors": status.error_count,
                "last_command": status.last_command,
                "features": status.features_available
            },
            "timestamp": time.time()
        }
        # Add battery diagnostics if available
        battery_status = self.get_battery_status()
        if battery_status.get("success"):
            payload["battery"] = battery_status["battery"]

        # Add motor diagnostics if available
        if self.motor_control:
            motor_diag = self.motor_control.get_motor_diagnostics()
            payload["motor"] = motor_diag

        # Add BLE diagnostics if available
        from ha_sphero_bb8.ble_gateway import get_ble_status
        ble_status = get_ble_status()
        payload["ble"] = ble_status

        return payload

    def disconnect(self):
        """No-op disconnect for controller (for shutdown consistency)."""
        self.logger.info("BB8Controller: disconnect called (no-op)")
        return {"success": True, "message": "BB8Controller: disconnect called"}

    # Helper methods
    def _create_error_result(self, command: str, error: str) -> Dict[str, Any]:
        """Create standardized error result"""
        return {
            "success": False,
            "command": command,
            "error": error,
            "timestamp": time.time()
        }

    def _format_command_result(self, motor_result: MotorCommandResult) -> Dict[str, Any]:
        """Format enhanced motor command result for API consistency"""
        return {
            "success": motor_result.success,
            "command": motor_result.command,
            "enhanced": True,
            "execution_time": motor_result.duration,
            "motor_state": {
                "left_speed": motor_result.motor_state.left_speed,
                "right_speed": motor_result.motor_state.right_speed,
                "heading": motor_result.motor_state.heading,
                "boost_active": motor_result.motor_state.boost_active
            },
            "error": motor_result.error_message,
            "trace_id": motor_result.trace_id,
            "timestamp": time.time()
        }

_battery_voltage_warned = False
_battery_percentage_warned = False

