"""
MODULE PURPOSE: Package initializer for ha_sphero_bb8. Exposes main controller class.
STATUS: production
MAIN ENTRYPOINTS: BB8Controller
DEPENDENCIES: controller.py
LAST VALIDATED: 2025-06-18
NOTES:
- Update __all__ to control public API surface.
- 2025-06-19: Top-level import of BB8Controller removed to break circular import. Import BB8Controller directly from ha_sphero_bb8.controller where needed.
"""

__all__ = [
    # "BB8Controller"  # Import directly from ha_sphero_bb8.controller
]
