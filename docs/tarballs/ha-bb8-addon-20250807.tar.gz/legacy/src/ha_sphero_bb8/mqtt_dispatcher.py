"""
Centralized MQTT topic dispatcher for ha_sphero_bb8.
Routes MQTT topics to the correct controller methods for both real and simulation modes.
dispatch_from_topic is defined only in mqtt_dispatcher.py.
Both mqtt_handler.py and run_mqtt.py import and use this centralized dispatcher.

Do not import run_mqtt.py (entrypoint script) in library code to avoid circular imports.
"""

def dispatch_from_topic(topic: str, payload: dict, controller) -> dict:
    """
    Dispatch MQTT command topic to the correct controller method.
    """
    response = {"topic": topic, "handled": False}

    if topic == "bb8/command/move":
        speed = payload.get("speed", 50)
        heading = payload.get("heading", 0)
        response["result"] = controller.roll(speed, heading)
        response["handled"] = True

    elif topic == "bb8/command/stop":
        response["result"] = controller.stop()
        response["handled"] = True

    elif topic == "bb8/command/rotate":
        angle = payload.get("angle", 90)
        response["result"] = controller.rotate(angle)
        response["handled"] = True

    elif topic == "bb8/command/led":
        r, g, b = payload.get("r", 255), payload.get("g", 255), payload.get("b", 255)
        response["result"] = controller.set_led(r, g, b)
        response["handled"] = True

    elif topic == "bb8/command/diagnostics":
        response["result"] = controller.get_diagnostics_for_mqtt()
        response["handled"] = True

    elif topic == "bb8/command/test":
        response["result"] = controller.simulate() if hasattr(controller, "simulate") else {"error": "No simulate method"}
        response["handled"] = True

    elif topic == "bb8/control":
        import logging
        logging.getLogger("ha_sphero_bb8.mqtt_dispatcher").warning("Topic bb8/control is not handled in current MVP. Use one of the supported bb8/command/* topics.")
        response["error"] = "Topic bb8/control is not handled in current MVP. Use one of the supported bb8/command/* topics."
        response["handled"] = False

    else:
        response["error"] = "Unknown topic"

    return response
