from typing import Protocol
import logging
logger = logging.getLogger(__name__)

class BB8Like(Protocol):
    def set_main_led(self, r: int, g: int, b: int): ...

def led_error_state(device: BB8Like):
    logger.info("Setting BB-8 LED to error state (red)")
    device.set_main_led(255, 0, 0)
    return {"status": "led_error"}

def led_charging_state(device: BB8Like):
    logger.info("Setting BB-8 LED to charging state (blue)")
    device.set_main_led(0, 0, 255)
    return {"status": "led_charging"}

def led_blink(device: BB8Like, cycles=3):
    import time
    for _ in range(cycles):
        device.set_main_led(255, 255, 0)
        time.sleep(0.2)
        device.set_main_led(0, 0, 0)
        time.sleep(0.2)
    logger.info("LED blink pattern executed")
    return {"status": "led_blinked"}

# Context-wrapped sync variant for robust BLE usage
def led_error_state_ctx(device_path: str):
    """Set BB-8 LED to red (error state) using synchronous context."""
    from spherov2.toy.bb8 import BB8
    from spherov2.scanner import find_BB8
    import logging

    logger = logging.getLogger(__name__)

    bb8 = find_BB8(timeout=30)
    if not bb8:
        logger.error("No BB-8 device found.")
        return {"error": "device_not_found"}

    with bb8:
        BB8.set_main_led(bb8, 255, 0, 0)
        logger.info("LED set to error state (red)")
        return {"status": "led_error"}

__all__ = [
    "led_error_state",
    "led_charging_state",
    "led_blink",
    "led_error_state_ctx"
]
