from typing import Protocol
import logging
import time
logger = logging.getLogger(__name__)

class BB8Like(Protocol):
    def get_battery_voltage(self) -> float: ...

def battery_voltage_check(payload: dict, device: BB8Like) -> dict:
    try:
        voltage = getattr(device, "get_battery_voltage", lambda: None)()
        if voltage is None:
            raise RuntimeError("Voltage read unsupported by device")
        logger.info(f"Battery voltage: {voltage}V")
        return {"status": "ok", "voltage": voltage}
    except Exception as e:
        logger.error(f"Voltage check failed: {e}")
        return {"status": "error", "error": str(e)}

def get_battery_voltage(device: BB8Like) -> float:
    voltage = getattr(device, "get_battery_voltage", lambda: None)()
    if voltage is None:
        raise RuntimeError("Voltage read unsupported by device")
    return voltage

def battery_retry_logic(payload: dict, device: BB8Like, retries=3) -> dict:
    for attempt in range(retries):
        result = battery_voltage_check(payload, device)
        if result.get("status") == "ok":
            return result
        time.sleep(0.5)
    return {"status": "error", "error": "voltage read failed after retries"}

__all__ = [
    "battery_voltage_check",
    "battery_retry_logic",
    "get_battery_voltage"
]
