from ha_sphero_bb8.bb8_protocol import BB8Like
import logging
from spherov2.commands.power import Power  # Patched: switched to pip spherov2, not vendor.spherov2

logger = logging.getLogger(__name__)

def vendor_power_state(device: BB8Like):
    """
    Reads the power state (battery voltage) from the given BB8-like device.

    Args:
        device (BB8Like): The device to query.

    Returns:
        dict: A dictionary with the status and voltage if successful, or error information if failed.
    """
    try:
        get_battery_voltage = Power.get_battery_voltage
        voltage = get_battery_voltage(device)
        logger.info(f"Vendor power state read: {voltage}V")
        return {"status": "ok", "voltage": voltage}
    except Exception as e:
        logger.error(f"Vendor power diagnostic failed: {e}")
        return {"status": "error", "error": str(e)}

def vendor_ping(device: BB8Like):
    try:
        ok = device.ping()
        logger.info("Ping response: %s", ok)
        return {"status": "ok" if ok else "unreachable"}
    except Exception as e:
        logger.error(f"Ping test failed: {e}")
        return {"status": "error", "error": str(e)}

__all__ = [
    "vendor_power_state",
    "vendor_ping"
]
