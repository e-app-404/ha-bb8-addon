"""
Battery utility functions for BB-8 (not production).
"""

from typing import Any, Optional


def get_voltage(device: Any) -> Optional[float]:
    """
    Get battery voltage from a BB-8 device using vendor Power command.
    Returns None if not available or on error.
    """
    try:
        from spherov2.commands.power import Power

        return Power.get_battery_voltage(device)
    except Exception as e:
        import logging

        logging.getLogger(__name__).error(f"battery_utils.get_voltage: {e}")
        return None


def get_percentage(device: Any) -> Optional[int]:
    """
    Get battery percentage from a BB-8 device using vendor Power command.
    Returns None if not available or on error.
    """
    try:
        from spherov2.commands.power import Power

        return Power.get_battery_percentage(device)
    except Exception as e:
        import logging

        logging.getLogger(__name__).error(f"battery_utils.get_percentage: {e}")
        return None


__all__ = ["get_voltage", "get_percentage"]
