# Home Assistant as master, with BB-8 as a “peripheral/bridge” device

## 🟦 MVP Context Snapshot (**Strategos Addendum**)

• Project is in MVP closure mode: “It works with real hardware, or it doesn’t count.”
• All documentation, patch logs, and artifacts are mapped to this empirical goal.
• Known issues, API mismatches, and unimplemented commands are acknowledged, logged, and moved to a backlog.
• Empiricism, audit, and evidence are the only criteria for acceptance—simulated/test-only paths are not sufficient for MVP.

## **Context Seed Snapshot** (for re-hydration)

### System State

* **Scenario:** Home Assistant is the master. BB-8 Bridge runs as a subordinate peripheral (MacBook).
* **Objective:** BB-8 robot acts as an event responder and emitter, integrating with Home Assistant automations, triggers, and dashboards.
* **Mosquitto:** Hosted on Home Assistant. All orchestration happens via MQTT topics.
* **BB-8 Bridge:** Listens to and emits MQTT topics, handles BLE connection to BB-8, and logs artifacts.
* **BB-8:** No direct internet/network, controlled only via BLE (from the bridge).

### Key Learnings/Decisions

* BB-8 connection cannot be reliably shared. HA is the “owner”; bridge must be an agent.
* When HA is running, it may block BLE pairing/connection from other hosts.
* All validation for JTBD-02b now focuses on "peripheral" role.

### Open Issues/Blockers

* Must ensure only one BLE connection (HA or bridge, never both).
* BLE connection/locking diagnostics, robust error handling.
* Bridge needs robust “offline mode” detection and re-connect logic.

### Next Steps

* Harden bridge to handle “peripheral/bridge” role: clear logs, CLI flags for bridge mode.
* Clean up CLI/README for new user workflow.
* Prepare for automated MQTT round-trips: Home Assistant → MQTT → BB-8 → MQTT → Home Assistant.

## **README/CLI/Architecture Templates (Peripheral/Bridge Mode)**

### **README Excerpt**

  ```markdown
  # ha-sphero-bb8 — Peripheral/Bridge Mode

  ## Overview

  This mode runs the BB-8 MQTT bridge as a subordinate device. Home Assistant (with Mosquitto) acts as the master controller. All BB-8 actions are triggered by MQTT topics. The bridge handles BLE communication to BB-8 and emits status/events to MQTT for HA to consume.

  ## Quickstart

  1. **Start Home Assistant (with Mosquitto) on your smart home server.**
  2. **Power on your BB-8 robot.**
  3. **On your bridge device (MacBook):**

    ```bash
    python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker <HA_IP> --port 1883 --username <user> --password <pw> --peripheral
    ```
  ```

### **Use HA automations to publish to:**

* `bb8/command/led` `{ "r": 0, "g": 255, "b": 0 }`
* `bb8/command/move` `{ "speed": 80, "heading": 0 }`

### **Monitor BB-8 and review logs in `artifacts/` directory.**

#### CLI Arguments

* `--adapter bleak` — Use BLE hardware adapter
* `--broker <ip>` — MQTT broker address (Home Assistant)
* `--port 1883` — MQTT broker port
* `--username/--password` — MQTT auth (match HA credentials)
* `--peripheral` — Run as peripheral/bridge (disables direct automation)
* `--allow-sim-fallback` — (optional) Simulate BB-8 if BLE fails

#### Example Use Case

* Presence detected in HA → MQTT publish → BB-8 lights up and moves.
* BB-8 detects bump (future work) → MQTT event → HA triggers action.

#### Architecture

see mermaid diagram in docs

#### **CLI Template**

```bash
python -m ha_sphero_bb8.run_mqtt \
    --adapter bleak \
    --broker 192.168.0.129 \
    --port 1883 \
    --username mqtt_bb8 \
    --password mqtt_bb8 \
    --peripheral \
    --allow-sim-fallback
```
