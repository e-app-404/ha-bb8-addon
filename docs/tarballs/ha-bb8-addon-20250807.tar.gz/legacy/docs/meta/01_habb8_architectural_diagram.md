# BB-8 as Home Assistant Peripheral

## 1. Detailed Architectural Diagram

I’ll describe the diagram here in textual form so you can visualize (and I can generate a PlantUML, Mermaid, or graphical version on request):

High-Level Flow

[Home Assistant]
    |
    | 1. MQTT Topic Command (e.g., bb8/command/led, bb8/command/move)
    v
[Mosquitto MQTT Broker]
    |
    | 2. Message Publish/Subscribe
    v
[BB-8 MQTT Adapter/Orchestrator] (running on MacBook/other edge device)
    |
    | 3. Decodes MQTT, translates to BB-8 command
    | 4. Sends via BLE/BLEAK to robot
    v
[Sphero BB-8 Toy]
    |
    | 5. Action (move, set LED, beep, report state)
    v
[Feedback loop: BB-8 status, sensor, or event data]
    |
    | 6. Publishes MQTT topic back to broker (bb8/status, bb8/event, etc.)
    v
[Home Assistant automations]

Components
 • Home Assistant: Master controller, triggers automations, manages MQTT add-on and device entities.
 • Mosquitto Broker: Central message bus, all BB-8 commands/status events pass through here.
 • BB-8 Orchestrator/Adapter: Lightweight Python (or Rust/Go) service running on a host with BLE. Listens to bb8/command/#, handles BLE logic, and emits bb8/status/# or bb8/event/#.
 • Sphero BB-8: Hardware endpoint, only connected to one orchestrator at a time.
 • (Optional): BB-8 Sensor/Presence status can be published as its own MQTT device for automations.

### Mermaid Architecture Diagram

```mermaid
flowchart TD
    subgraph Smart Home Core ["Home Assistant (Master)"]
        HA["Home Assistant<br>+ Mosquitto Broker"]
        AUTOMA["Automations/Sensors/Triggers"]
        UI["HA Dashboard<br>and User Apps"]
    end

    subgraph BB8Bridge ["BB-8 MQTT Bridge (Peripheral, on MacBook)"]
        BB8MQTT["ha-sphero-bb8<br>run_mqtt.py"]
        BB8ADAPTER["BB8Controller<br>& Adapter(s)"]
        BLE["Bluetooth LE<br>Stack"]
        BB8HW["Sphero BB-8 Robot"]
        ARTIFACTS["Logs & Artifacts"]
    end

    subgraph Network ["LAN/WiFi"]
        MQTTTOPIC["MQTT Topics<br>bb8/command/#<br>bb8/status"]
    end

    %% Data Flows
    AUTOMA-->|trigger/publish|MQTTTOPIC
    UI-->|publish/subscribe|MQTTTOPIC
    MQTTTOPIC-->|subscribe|BB8MQTT
    BB8MQTT-->|parse/dispatch|BB8ADAPTER
    BB8ADAPTER-->|BLE control|BLE
    BLE-->|connects via BLE|BB8HW
    BB8HW-->|sensors/events|BB8ADAPTER
    BB8ADAPTER-->|publish|MQTTTOPIC
    BB8MQTT-->|log|ARTIFACTS

    %% Operator visibility
    ARTIFACTS-->|review|UI
```

### Legend

- **🟦 MVP Path**: Only the flows from MQTT command to BB-8 hardware response and feedback back to Home Assistant need to be working for MVP.
- ⚠️ Other features and handler branches shown are for context—if broken or not fully mapped, they are logged for future sprints, not patched for MVP.
- All flows must be hardware-backed for closure.

⸻

## 2. Context Seed Snapshot: “BB-8 Peripheral Mode”

Project Phase: Home Assistant–centric smart home, with BB-8 as an event-driven actuator.

Objectives:
 • All orchestration and automation logic is handled by Home Assistant.
 • BB-8 is a “stateless peripheral” that receives all commands through a single MQTT->BLE bridge.
 • MacBook runs only the adapter/bridge; HA is the “source of truth.”
 • Mosquitto handles all device topics.
 • All other smart home events are “proxied” via HA MQTT automations.

Key Learnings/Risks:
 • Only one client can control BB-8 via BLE at a time—MacBook adapter must hold lock.
 • Any BB-8 status or sensor feedback must be published as MQTT topics and mapped in HA.
 • Device discovery, troubleshooting, and diagnostics now run via the bridge, not via HA directly.
 • Home Assistant UI, Node-RED, or YAML automations drive BB-8 behavior (no manual CLI for daily use).

How To Rehydrate:
 • Ensure the MacBook (or edge device) is always running the MQTT<->BB-8 bridge service and is on the same network as HA/MQTT.
 • BB-8 stays in range and powered.
 • All automation design/experimentation is done in Home Assistant, not the adapter layer.
 • Any new BLE/BLEAK code changes only in the bridge—never in HA.

⸻

## 3. Next Steps / Deliverables

 • Generate PlantUML/Mermaid/PNG as needed.
 • Snapshot context seed as above.
 • Refactor docs/readme and CLI to focus on “adapter bridge” mode only.
 • Remove non-HA orchestration pathways to minimize ambiguity.
 • Add Home Assistant “device discovery” and “event publishing” examples to README.
 • Harden connection resilience (auto-reconnect) in the MacBook adapter.

⸻

## 4. Context Seed Snapshot (for re-hydration)

System State
 • Scenario: Home Assistant is the master. BB-8 Bridge runs as a subordinate peripheral (MacBook).
 • Objective: BB-8 robot acts as an event responder and emitter, integrating with Home Assistant automations, triggers, and dashboards.
 • Mosquitto: Hosted on Home Assistant. All orchestration happens via MQTT topics.
 • BB-8 Bridge: Listens to and emits MQTT topics, handles BLE connection to BB-8, and logs artifacts.
 • BB-8: No direct internet/network, controlled only via BLE (from the bridge).

Key Learnings/Decisions
 • BB-8 connection cannot be reliably shared. HA is the “owner”; bridge must be an agent.
 • When HA is running, it may block BLE pairing/connection from other hosts.
 • All validation for JTBD-02b now focuses on “peripheral” role.

Open Issues/Blockers
 • Must ensure only one BLE connection (HA or bridge, never both).
 • BLE connection/locking diagnostics, robust error handling.
 • Bridge needs robust “offline mode” detection and re-connect logic.

Next Steps
 • Harden bridge to handle “peripheral/bridge” role: clear logs, CLI flags for bridge mode.
 • Clean up CLI/README for new user workflow.
 • Prepare for automated MQTT round-trips: Home Assistant → MQTT → BB-8 → MQTT → Home Assistant.

⸻

## 5. README/CLI/Architecture Templates (Peripheral/Bridge Mode)

From README:

```md
# ha-sphero-bb8 — Peripheral/Bridge Mode

## Overview

This mode runs the BB-8 MQTT bridge as a subordinate device. Home Assistant (with Mosquitto) acts as the master controller. All BB-8 actions are triggered by MQTT topics. The bridge handles BLE communication to BB-8 and emits status/events to MQTT for HA to consume.

## Quickstart

1. **Start Home Assistant (with Mosquitto) on your smart home server.**
2. **Power on your BB-8 robot.**
3. **On your bridge device (MacBook):**

   ```bash
   python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker <HA_IP> --port 1883 --username <user> --password <pw> --peripheral

 4. Use HA automations to publish to:
 • bb8/command/led { "r": 0, "g": 255, "b": 0 }
 • bb8/command/move { "speed": 80, "heading": 0 }
 5. Monitor BB-8 and review logs in artifacts/ directory.

CLI Arguments
 • --adapter bleak — Use BLE hardware adapter
 • --broker <ip> — MQTT broker address (Home Assistant)
 • --port 1883 — MQTT broker port
 • --username/--password — MQTT auth (match HA credentials)
 • --peripheral — Run as peripheral/bridge (disables direct automation)
 • --allow-sim-fallback — (optional) Simulate BB-8 if BLE fails

Example Use Case
 • Presence detected in HA → MQTT publish → BB-8 lights up and moves.
 • BB-8 detects bump (future work) → MQTT event → HA triggers action.

Architecture (see mermaid diagram in docs)

---

## **CLI Template**

```bash
python -m ha_sphero_bb8.run_mqtt \
    --adapter bleak \
    --broker 192.168.0.129 \
    --port 1883 \
    --username mqtt_bb8 \
    --password mqtt_bb8 \
    --peripheral \
    --allow-sim-fallback
```
