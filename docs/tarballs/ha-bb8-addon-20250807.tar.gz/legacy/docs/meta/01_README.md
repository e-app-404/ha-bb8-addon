# ha-bb8 README

## Peripheral/Bridge Mode - Home Assistant Native Integration

## Project Overview

This project provides a robust, MQTT-based bridge between a Sphero BB-8 robot and a Home Assistant (HA) smart home ecosystem, using Mosquitto as the MQTT broker. BB-8 operates as a peripheral/actor, reacting to HA triggers (presence, time, events) and reporting status back for smart automation.

## Key Features

**• Native MQTT integration:** BB-8 receives commands from HA via MQTT, and emits sensor/status/diagnostic info back.
**• Bridge/Peripheral Mode:** All primary orchestration comes from HA; the MacBook tool is for bridging, diagnostics, or one-off manual commands.
**• Extensible:** Add new smart home automations, scenes, or BB-8 actions easily via MQTT topics.

## Project Purpose & MVP Horizon

This project’s immediate goal is to achieve an empirical, evidence-driven MVP for Sphero BB-8 Home Assistant integration.

**MVP Acceptance** = Physical BB-8 device is controlled via MQTT from Home Assistant, with observable round-trip feedback (logs, video, or screenshots).
Every “pass” must be hardware-backed and logged; simulation, theoretical tests, or “green checks” without device proof do not count as acceptance.

Protocol/adapter gaps and handler mismatches are to be logged as known issues/future work, not blocked on for MVP closure.

    The project is now a hardware-in-the-loop, evidence-driven MVP validation, with protocol gaps and handler mismatches logged as future work, not show-stoppers.
    All further work should focus on proving that the integration works in practice, not on chasing theoretical completeness.

### Near-term

 • Close the empirical loop: One end-to-end, artifacted test that proves MQTT → Adapter → BLE → BB-8 → Feedback → MQTT/HA.
 • MVP = Hardware round-trip, not simulation.
 • All blockers and protocol mismatches are valuable learning for the next phase, not things to be “papered over” right now.

### Mid-term

 • Refactor the adapter/controller boundary:
 • Make it easy to extend/maintain by clearly mapping controller APIs to Sphero SDK requirements.
 • Possibly redesign the MQTT topic structure or protocol for clarity and testability.
 • Upgrade test harness:
 • After MVP, extend to more commands, diagnostics, and UI coverage, but only as time allows and as justified by real use-cases.

### Long-term

 • Full Home Assistant integration, HA dashboard widgets, and maybe even extension to other Sphero devices—if there is value and need.

## System Architecture

flowchart TD
    subgraph HomeAssistant Ecosystem
        HA[Home Assistant]
        Mosquitto[MQTT Broker (Mosquitto)]
        HA <--> Mosquitto
    end

    subgraph Edge Device (MacBook or Pi)
        BB8Bridge["ha-sphero-bb8<br/>(MQTT Bridge)"]
        BB8Adapter["BB-8 Adapter<br/>(BLE/MQTT)"]
        BB8[BB-8 Robot]
        BB8Bridge <--> Mosquitto
        BB8Bridge <--> BB8Adapter
        BB8Adapter <--> BB8
    end

    subgraph End Users
        User["Home Occupant<br/>(via HA mobile app, sensors, voice, etc.)"]
        User -- triggers, status --> HA
    end

    Mosquitto <--> BB8Bridge
    HA -- automations --> Mosquitto

⸻

## Typical Smart Home Flow

 1. Trigger: User arrives home; HA presence detection fires.
 2. Automation: HA emits an MQTT command to bb8/command/led or bb8/command/move.
 3. Bridge: BB-8 Bridge receives and relays the command to the BB-8 via BLE.
 4. Act: BB-8 executes action (move, lights, sounds).
 5. Status: BB-8 (or bridge) sends status back to MQTT; HA can use it for follow-up automations.
 6. Diagnostics: MacBook tool can run in parallel for logs, manual testing, or troubleshooting if needed.

⸻

## Getting Started

### Prerequisites

 • Home Assistant with Mosquitto MQTT broker addon enabled.
 • Sphero BB-8 robot, charged and ready.
 • MacBook (or Pi/Linux box) with BLE.
 • Python 3.9+ environment.

### Installation

#### Clone the repo

git clone <https://github.com/YOURORG/ha-sphero-bb8.git>
cd ha-sphero-bb8

#### (Recommended) Create virtualenv

python3 -m venv .venv
source .venv/bin/activate

#### Install dependencies

pip install -r requirements.txt

⸻

#### Configuration

**MQTT Credentials**
 • Set these in Home Assistant Mosquitto addon UI.
 • Pass via CLI or environment variables:

export `MQTT_USER="mqtt_bb8"`
export `MQTT_PW="mqtt_bb8"`

BB-8 BLE MAC Address
 • Find with built-in scanner or Home Assistant logs if paired previously.

⸻

#### Running the Bridge

**Basic:**

    ```py
    python -m ha_sphero_bb8.run_mqtt \
        --adapter bleak \
        --broker 192.168.0.129 \
        --port 1883 \
        --username $MQTT_USER \
        --password $MQTT_PW
    ```
 • Replace --broker with your HA/Mosquitto IP.

**Advanced/Diagnostic:**
 • To allow fallback to simulation if BLE fails (not recommended for prod):

`python -m ha_sphero_bb8.run_mqtt ... --allow-sim-fallback`

 • To run BLE/MQTT diagnostics:

`python -m ha_sphero_bb8.run_mqtt --ble-diagnostics`

⸻

#### MQTT Command Reference

Topic Payload Example Effect
`bb8/command/led` {“r”:255, “g”:140, “b”:0} Set BB-8 LED color
`bb8/command/move` {“speed”:100, “heading”:0} Move BB-8 forward
`bb8/command/stop` {} Stop BB-8
`bb8/command/sound` {“sound”:“bleep”} Play sound (if supported)
`bb8/command/diagnostics` {} Request status/battery

⸻

#### Troubleshooting

 • No hardware response?
 • Ensure BB-8 is not paired/busy with any other app (including Home Assistant integrations!).
 • Power cycle BB-8.
 • Restart BLE adapter and your bridge tool.
 • Check audit logs in artifacts/.
 • Multiple controllers:
 • Only one tool can control BB-8 at a time. HA must not have it paired natively via any Bluetooth integration; the bridge owns BLE.
 • Diagnostics:
 • Use --ble-diagnostics for extra adapter info.

⸻

#### Development & Testing

 • Full diagnostics/trace logs available in artifacts/.
 • Add more MQTT command handlers in mqtt_dispatcher.py.
 • Extend BB-8 features by expanding BB8Adapter.

⸻

#### Roadmap

 • Automatic entity/sensor registration in Home Assistant via MQTT discovery.
 • Support for additional Sphero robot models.
 • More bidirectional feedback (e.g., report low battery).
 • Voice-command routines, e.g., “Hey BB-8, greet me when I get home!”

⸻

## Technical Architecture – Peripheral/Bridge Mode

### Overview

BB-8 acts as a stateless smart home device. Home Assistant is the source of all automation logic; the bridge tool on MacBook acts only as a BLE/MQTT bridge.

**Main Components**
 • Home Assistant (HA): Orchestration, presence detection, automation, UI, entity registry.
 • Mosquitto: MQTT event bus.
 • Bridge (ha-sphero-bb8): Connects MQTT commands to BB-8 via BLE, relays status.
 • BB-8: Peripheral device, executes actions.

### Sequence Diagram

    ```mermaid
    sequenceDiagram
        participant HA as Home Assistant
        participant MQTT as Mosquitto Broker
        participant Bridge as BB-8 MQTT Bridge
        participant BB8 as BB-8 Robot

        HA->>MQTT: Publish bb8/command/led ({"r":0,"g":255,"b":0})
        MQTT->>Bridge: Receives command
        Bridge->>BB8: BLE write (set color)
        BB8-->>Bridge: (Acknowledgement/status)
        Bridge->>MQTT: Publish bb8/status (online, battery)
        MQTT->>HA: Update BB-8 status entity
    ```

⸻

### Directory Layout

    ```txt
    ha-sphero-bb8/
    │
    ├── src/ha_sphero_bb8/
    │   ├── run_mqtt.py           # CLI entrypoint for bridge
    │   ├── mqtt_handler.py       # MQTT logic
    │   ├── mqtt_dispatcher.py    # MQTT -> BB-8 command dispatcher
    │   ├── controller.py         # BB-8 control logic
    │   ├── device_core/
    │   │   └── adapters/         # BLE, simulation adapters
    │   ├── constants.py
    │   └── ...
    ├── requirements.txt
    ├── README.md
    └── artifacts/                # Logs, diagnostics
    ```

⸻

Peripheral/Bridge Mode Best Practices
 • Never pair BB-8 with HA directly: Only the bridge should use BLE; HA interacts over MQTT only.
 • Restart the bridge if BLE connection is lost.
 • Monitor bridge health via MQTT or a process supervisor.
 • Decouple automations: Keep all smart logic in HA; keep bridge code simple and focused.

⸻

## Strategic Decision Brief: BB-8 as Peripheral/Bridge, Home Assistant as System Master

### 1. Summary of Change

 • Previous Model: Dual orchestration—BB-8 could be controlled from either a standalone orchestration tool (e.g., MacBook) or via Home Assistant (HA) through MQTT.
 • New Model: Home Assistant is the sole master. BB-8 becomes a peripheral device, controlled exclusively through HA/MQTT. The orchestration tool acts as a bridge/adapter, exposing BB-8’s capabilities over MQTT and relaying commands from HA.

⸻

### 2. Implications for Development & Technical Effort

a. Codebase Simplification
 • No dual-mode orchestration: All code paths, CLI tools, and runtime logic now focus on one “peripheral/bridge” mode. Reduces maintenance overhead, code complexity, and runtime ambiguity.
 • All MQTT topics, device commands, and status flows are designed around HA as the master controller.

b. Adapter/Bridge Requirements
 • Robust MQTT client: The bridge must handle persistent MQTT connections, reconnect logic, and reliable message delivery to/from HA.
 • State/connection management: The adapter must gracefully handle BLE/BLEAK disconnects, re-pairing, and errors, since HA expects BB-8 to be always online or gracefully unavailable.
 • One-way command flow: Business logic, automation, and routines are all defined in HA; the bridge does not make independent decisions or initiate actions except as a responder.

c. Testing and QA
 • Test matrix shrinks: Only one primary scenario—HA is the master, BB-8 responds.
 • Can focus QA on:
 • End-to-end MQTT command delivery
 • BLE/BLEAK robustness (reconnect, error handling)
 • Edge cases like HA restarts, MQTT reconnects, device offline/online transitions

⸻

### 3. Impact on Timelines & Delivery

a. Short-term
 • Faster closure of JTBD-02b: No need to maintain/test a dual-orchestrator model. Effort is concentrated on ensuring the HA → MQTT → BB-8 bridge is robust.
 • Accelerated development cycles: Code can be simplified, testing focused, and releases shipped more quickly.

b. Medium/Long-term
 • Sustainable maintainability: Fewer bugs, easier upgrades (e.g., switching BLE stacks or MQTT brokers).
 • Scalability: This architecture is scalable—more BB-8s (or other BLE robots) can be added as MQTT peripherals with minimal changes.
 • Extension: Future features (e.g., adding more robot actions, or new HA automations) are developed entirely in HA or as bridge plugins.

⸻

### 4. Risks & Mitigations

 • Single point of orchestration: If HA or the MQTT broker goes down, BB-8 cannot be controlled. (Mitigation: robust reconnect/retry logic, clear error reporting.)
 • Performance: BLE reconnects and MQTT latency must be monitored to avoid missed events.
 • Platform dependency: Requires HA and MQTT to remain stable and properly configured.

⸻

### 5. Next Steps

 • Update project README and technical documentation to reflect the new single-mode bridge architecture.
 • Strip out dual-orchestration logic from codebase and CLI.
 • Harden bridge robustness and logging, focusing on diagnostics relevant to the HA/master mode.
 • Prepare QA artifacts and documentation for final acceptance and closure of JTBD-02b.

⸻
