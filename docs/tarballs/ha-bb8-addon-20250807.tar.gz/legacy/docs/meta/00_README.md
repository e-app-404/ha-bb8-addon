# ha_sphero_bb8

A robust, protocol-compliant Python package for controlling Sphero BB-8 robots via MQTT, supporting both real hardware and simulation modes. Designed for type safety, modularity, and rapid development.

---

## Project Tarball

Executed from `/Users/evertappels/Projects/HABIBI-8/ha-sphero-bb8`

```arduino
tar --exclude='.venv' \
    --exclude='__pycache__' \
    --exclude='.pytest_cache' \
    --exclude='.git' \
    --exclude='*.egg-info' \
    --exclude='*.dist-info' \
    --exclude='*.tar.gz' \
    --exclude='*.whl' \
    --exclude='*.log' \
    --exclude='build' \
    --exclude='dist' \
    --exclude='artifacts' \
    --exclude='.mypy_cache' \
    --exclude='*.pyc' \
    --exclude='*.mov' \
    --exclude='*.mp4' \
    --exclude='get-pip.py' \
    --exclude='.DS_Store' \
    --exclude='*.so' \
    --exclude='*.mat' \
    -czf ha_sphero_bb8_reduced_$(date +"%Y-%m-%d_%H-%M").tar.gz .
```

## MQTT Validation (JTBD-02, JTBD-02b)

```sh
cd /Users/evertappels/Projects/HABIBI-8/ha-sphero-bb8/ && source .venv/bin/activate

python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker 192.168.0.129 --port 1883 --username mqtt_bb8 --password mqtt_bb8

cd /Users/evertappels/Projects/HABIBI-8/ha-sphero-bb8/ && source .venv/bin/activate && python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker 192.168.0.129 --port 1883 --username mqtt_bb8 --password mqtt_bb8
```

Run WITH Fallback (Operator-Explicit)

```bash
python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker 192.168.0.129 --port 1883 --username mqtt_bb8 --password mqtt_bb8 --allow-sim-fallback
```

(Alternative) Use Environment Variable Instead of CLI Flag

```bash
export HASS_BB8_ALLOW_SIM_FALLBACK=1
python -m ha_sphero_bb8.run_mqtt --adapter bleak --broker 192.168.0.129 --port 1883 --username mqtt_bb8 --password mqtt_bb8
```

---

Here’s what running your test_sdk_scan.py test and getting the output means for the project outcome:

output:
`BB-B54A (259ED00E-3026-2568-C410-4590C9A9297C)`

1. What was just validated?
 • BLE Hardware Path Works: Your computer, Python environment, and the Sphero SDK (via spherov2.scanner) can successfully discover and connect to the BB-8 via BLE.
 • BB-8 is Powered and Advertises Correctly: The robot is on and visible to the system.
 • SDK & BLE Stack Are Not Blocked: No low-level platform issues (such as permissions, adapter lock, or missing dependencies) are preventing BLE discovery at the SDK level.

2. What does this mean for the project?
 • Critical Assumptions Are Confirmed:
 • Your BB-8 can be discovered and controlled by basic SDK scripts on your host.
 • The root cause of your end-to-end integration issues is NOT at the hardware or OS/adapter level.
 • You have a known-good baseline: This minimal script is your “empirical anchor.” Any additional code path (run_mqtt, adapters, etc.) should—at minimum—be able to do what this script does, or it’s introducing new blockers.

3. Does this move us forward?

YES—it moves us forward in debugging:
 • If the SDK test succeeds, but your full tool fails:
 • The bug/blocker is almost certainly in the orchestration logic—not in the BLE stack or hardware.
 • Your custom logic (adapter creation, scan config, client instantiation, argument passing) is introducing an incompatibility or error.
 • What it rules out:
 • BLE permissions, adapter lock, device power issues, or host platform bugs are not the root cause.

## What’s the next step?

 • Directly compare the working SDK scan logic (from your test) with your custom code’s scan/connection sequence.
 • Ensure your orchestration uses the exact same arguments, scan method, and connection flow as the working test.
 • If your tool still fails, add detailed logs at every scan/connect step and compare line by line with the successful script.

## Summary Table

Layer/Step SDK Test Full Tool Next Action
BLE Discovery Works Fails Diff code/logs, unify logic
Adapter/Permissions Works Unknown Not root cause
Sphero Device Awake Yes Yes Not a device issue
Custom Logic Not used Used Suspect area: adapter, scan, client wiring

---

## Directory Structure

```arduino
src/ha_sphero_bb8/
├── __init__.py
├── bb8_control.py
├── ble_gateway.py
├── color_dance.py
├── constants.py
├── controller/
│   ├── commands/
│   │   ├── __init__.py
│   │   ├── battery_diagnostics.py
│   │   ├── led_state_variants.py
│   │   ├── roll_profiles.py
│   │   ├── roll_router.py
│   │   └── vendor_diagnostics.py
│   └── safe_utils.py
├── controller.py
├── device_core/
│   ├── __init__.py
│   ├── adapters/
│   │   ├── __init__.py
│   │   ├── bleak_adapter.py
│   │   ├── simulation_adapter.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── battery_utils.py
│   │   ├── calibration.py
│   │   ├── color_utils.py
│   │   ├── integration_stub.py
│   │   ├── motor_utils.py
│   │   └── safe_utils.py
│   └── voltage_diagnostics.py
├── launch_bb8.py
├── mqtt_handler.py
├── run_ble.py
├── run_mqtt.py
└── topics.py
```

---

## Quickstart

### 1. Create and Activate Virtual Environment

```sh
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install Requirements

```sh
pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Build and Install Package (optional)

```sh
python setup.py bdist_wheel
pip install dist/ha_sphero_bb8-*.whl
```

---

## Usage: MQTT CLI Entrypoint

Launch the MQTT bridge for Sphero BB-8:

```sh
python -m ha_sphero_bb8.run_mqtt --adapter real
python -m ha_sphero_bb8.run_mqtt --adapter sim
```

### Options

| Flag             | Description                                                        |
| ---------------- | ------------------------------------------------------------------ |
| `--adapter sim`  | Runs a mock simulation of BB-8 commands with test command payloads |
| `--adapter real` | Connects to MQTT broker and listens to commands on `bb8/command/#` |

- Default broker: `localhost:1883`. Ensure the broker is running before launching.
- CLI subscribes to `bb8/command/*` topics and dispatches actions accordingly.

---

## Battery Status CLI Usage

You can query the BB-8's battery status directly from the command line:

```sh
python -m ha_sphero_bb8.run_mqtt --battery-status
```

This will print a robust, audit-grade battery status report (voltage, percentage, and diagnostics if available) and exit. This works for both hardware and simulation modes.

- If the device is not connected or battery status is unavailable, a clear error will be shown.
- All battery queries are logged for audit and troubleshooting.

---

## Example Output

```py
Battery status: {'success': True, 'enhanced': False, 'battery': {'voltage': 7.4, 'percentage': 95}}
```

---

## BB-8 LED Control via BLE

 • The Sphero BB-8 (and similar Sphero toys) use a proprietary BLE protocol.
 • They do NOT expose a “standard” GATT characteristic for the main LED.
 • Instead, all Sphero command/control packets are sent via a single, writable GATT characteristic.

Sphero Command Service & Characteristic (from spherov2 and open Sphero reverse engineering projects):
 • Service UUID: 00010001-574f-4f20-5370-6865726f2121
 • Characteristic UUID: 00010002-574f-4f20-5370-6865726f2121

(These are found in both the spherov2 project and Sphero packet reverse engineering docs.)

---

## MQTT Battery Status (Planned)

Battery status can be exposed via MQTT topics in future releases. For now, use the CLI for direct diagnostics.

---

## Example MQTT Command Payloads

To control BB-8 via MQTT, use the following command formats:

```sh
# Move BB-8 forward at speed 80, heading 0 (straight ahead)
mosquitto_pub -h 192.168.0.129 -p 1883 -u mqtt_bb8 -P mqtt_bb8 -t "bb8/command/move" -m '{"speed": 80, "heading": 0}'

# Move BB-8 backward at speed 80, heading 180 (reverse)
mosquitto_pub -h 192.168.0.129 -p 1883 -u mqtt_bb8 -P mqtt_bb8 -t "bb8/command/move" -m '{"speed": 80, "heading": 180}'

# Rotate BB-8 by 90 degrees at speed 50
mosquitto_pub -h 192.168.0.129 -p 1883 -u mqtt_bb8 -P mqtt_bb8 -t "bb8/command/rotate" -m '{"angle": 90, "speed": 50}'

# Set BB-8 LED to green
mosquitto_pub -h 192.168.0.129 -p 1883 -u mqtt_bb8 -P mqtt_bb8 -t "bb8/command/led" -m '{"r": 0, "g": 255, "b": 0}'

# Set BB-8 LED to red
mosquitto_pub -h 192.168.0.129 -p 1883 -u mqtt_bb8 -P mqtt_bb8 -t "bb8/command/led" -m '{"r": 255, "g": 0, "b": 0}'

# Emergency stop
mosquitto_pub -h 192.168.0.129 -p 1883 -u mqtt_bb8 -P mqtt_bb8 -t "bb8/command/stop" -m '{}'

# Get diagnostics/status (will return log/artifact)
mosquitto_pub -h 192.168.0.129 -p 1883 -u mqtt_bb8 -P mqtt_bb8 -t "bb8/command/diagnostics" -m '{}'
```

---

## Testing

- Run integration test:

  ```sh
  python -m tests.test_integration_mqtt
  ```

- Publish sample MQTT test commands:

  ```sh
  python mqtt_send_test.py
  ```

- See `tests/` for more unit and integration tests.

---

## Project Constants

All MQTT topics, broker configuration, and adapter modes are defined centrally in `constants.py`:

- Import topic strings, broker info, and mode flags from `ha_sphero_bb8.constants`.
- Both `run_mqtt.py` and `mqtt_handler.py` use these constants for protocol consistency.

---

## Simulation Support (IMPORTANT)

**Only `simulation_adapter.py` is supported for simulation.**

- All other simulation, mock, or dryrun adapters are legacy and must not be used for production or future development.
- This codebase is not production-ready until all hardware adapters pass empirical validation.

---

## Governance & Patching

- All patch logic for handlers and CLI is merged, hardened, and annotated for provenance.
- Single-source-of-truth enforced for all MQTT, adapter, and CLI entrypoints.
- See `logs/` for patch history and provenance.

> **NOTE:** The current multi-topic command structure (`bb8/command/...`) is a technical prototype to unblock MVP and audit closure.
> The production design will consolidate all commands to a single topic (e.g., `bb8/command/#`) with command demuxing in the payload
> for extensibility, auditability, and ease of integration.

---

## Recent Hygiene & Structure Changes (2025-06-19)

- **Test Directory Flattened:**
  - All test scripts moved from `tests/mocks/` to `tests/`.
  - `tests/mocks/` directory and its `__pycache__` removed.
- **Obsolete Files Removed:**
  - Deleted `src/ha_sphero_bb8/device_core/adapters/mock_adapter.py` (empty/legacy).
  - Deleted `src/ha_sphero_bb8/topics.py` (all topics now in `constants.py`).
- **Error Injection Test Added:**
  - Created `tests/test_error_injection.py` as a placeholder for adapter disconnect/error/failover logic.
- **Lint/Type Tools:**
  - Confirmed `mypy` and `pylint` are present in `requirements.txt`.
  - Added `types-paho-mqtt` to `requirements.txt` for type checking.
- **Docstring Coverage:**
  - Added/expanded docstrings for all flagged modules, classes, and functions in `bb8_control.py`, `color_utils.py`, `calibration.py`, and `battery_utils.py`.
- **Patchlogs:**
  - See `logs/2025-06-19_hygiene_structural_copilot.diff` and `logs/docstring_coverage_copilot.diff` for details.

---

## Context Seed: BLE, Vendor, and Import Architecture (2025-06-19)

### Key Changes & Rationale

- **Local Vendor Override:** All entrypoints (run_ble.py, launch_bb8.py, tests) patch `sys.path` to ensure the local `_vendor/spherov2` is used, not the pip package.
- **Flattened Vendor Structure:** The `_vendor/spherov2` directory now contains all SpheroV2 code directly (no nested `spherov2/spherov2/`).
- **No Top-Level Imports in init.py:** To avoid circular imports, `ha_sphero_bb8/__init__.py` does not import `BB8Controller` or other deep dependencies at the top level.
- **BB8Like Protocol:** Defined once in `bb8_protocol.py` and imported everywhere needed to avoid duplication and circular imports.
- **Broken pip spherov2:** The pip version is not used due to import errors; all BLE and hardware features rely on the local vendor copy.
- **Debug Prints:** Temporary debug prints were used to confirm the correct spherov2 is loaded; these can be removed after validation.

### Implications for Future Developers

- **Always patch sys.path** at the top of new entrypoints if you want to use `_vendor` libraries.
- **Do not re-introduce top-level imports** in `__init__.py` that pull in large modules or deep dependencies.
- **If you update or replace _vendor/spherov2,** ensure the structure is flat and all modules are directly under `_vendor/spherov2/`.
- **If you see BLE or import errors,** check that `_vendor/spherov2/__init__.py` exists and is not shadowed by pip.
- **For hardware validation,** confirm the BLE logs show the correct device and that the user witnesses the BB-8 activating.

### Example sys.path Patch

```python
import sys, os
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '..', '..'))
vendor_parent = os.path.join(project_root, '_vendor')
if vendor_parent not in sys.path:
    sys.path.insert(0, vendor_parent)
```

### Example Debug Print

```python
import spherov2
print("spherov2 loaded from:", spherov2.__file__)
```

---

## Version History

- v0.3.2_PHASE5: run_mqtt.py CLI entrypoint, patched README, clean directory, MQTT control logic (real/sim modes)

---

## Credits

- Sphero BB-8 Python integration by project contributors.
- MQTT and BLE libraries: `paho-mqtt`, `bleak`, `spherov2`.

---

For more details, see the code and comments in each module.

---

Based on your codebase and the provided bb8_control.py, here’s a summary of the main BB-8 device interface definitions and their separation:

1. BB8Like (Protocol, in controller.py)
Purpose: Defines the required interface (methods) for any BB-8-compatible device (real, simulated, or adapter).
Methods: roll, stop, set_main_led, wake, ping, get_battery_voltage, get_battery_percentage
Role: Used for type safety and protocol compliance across the codebase.

2. BB8Adapter (Class, in bb8_control.py)
Purpose: Wraps any device (vendor, mock, or otherwise) to ensure it conforms to the BB8Like protocol.
Implements: All BB8Like methods, forwarding to the underlying device, and provides a no-op disconnect.
Role: Used as a compatibility layer to guarantee protocol compliance.

3. Bb8Controller (Class, in bb8_control.py)
Purpose: (Legacy/alternate) controller abstraction, possibly predating the unified controller.
Implements: Likely some orchestration logic, but now mostly replaced by BB8Controller.
Role: May be deprecated or only used in legacy/test code.

4. BB8Controller (Class, in controller.py)
Purpose: The main, unified controller for all BB-8 operations (movement, LED, diagnostics, etc.).
Implements: High-level orchestration, device injection, status tracking, and command handling.
Role: The canonical entrypoint for all BB-8 control logic, used by MQTT handlers and CLI.

5. Simulation/Mock Adapters
SimulationAdapter (in device_core/adapters/simulation_adapter.py): Implements the same interface for simulation/testing.
MockBB8Device (if present): Legacy, now replaced by SimulationAdapter.
Separation and Clarity
Device Protocol: BB8Like defines the contract. All real, simulated, and adapted devices must conform.
Adapter Layer: BB8Adapter ensures any device (even vendor or legacy) can be used safely.
Controller Layer: BB8Controller is the main orchestrator, using dependency injection to work with any BB8Like device.
Simulation: All simulation is now handled by SimulationAdapter, which also conforms to BB8Like.
Conclusion:
The separation is clear and robust:

Protocol (BB8Like) → Adapter (BB8Adapter) → Controller (BB8Controller)
Simulation is unified under SimulationAdapter.
Legacy classes like Bb8Controller can be removed if not needed.

---

Note: paho-mqtt type stubs (types-paho-mqtt) installed, but mypy may not detect these in all environments (see mypy#13152). No runtime errors; proceed as known gap.
