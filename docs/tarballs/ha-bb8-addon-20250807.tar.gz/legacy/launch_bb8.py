#!/usr/bin/env python3
# src/ha_sphero_bb8/launch_bb8.py
"""
MODULE PURPOSE: Launch and initialize BB-8 device with unified controller and BLE diagnostics.
STATUS: production
MAIN ENTRYPOINTS: main() function, CLI argument parsing
DEPENDENCIES: controller.py, ble_gateway.py, device_core, constants.py
LAST VALIDATED: 2025-06-18
NOTES:
- Hardware-only operation. Simulation/adapters/fallback logic removed.
- Provides CLI for device launch and diagnostics.
"""

import sys
import os
# Find the absolute path to the _vendor directory
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '..', '..'))  # Adjust as needed
vendor_parent = os.path.join(project_root, '_vendor')
if vendor_parent not in sys.path:
    sys.path.insert(0, vendor_parent)
import spherov2  # type: ignore
print("spherov2 loaded from:", spherov2.__file__)

import argparse
import logging
import json
import sys
import time
from typing import TYPE_CHECKING, Dict, Any, Optional
if TYPE_CHECKING:
    from ha_sphero_bb8.controller import BB8Like

from ha_sphero_bb8.controller import BB8Controller
from ha_sphero_bb8.ble_gateway import BleGateway
from ha_sphero_bb8.device_core.utils.safe_utils import (
    safe_ping,
    safe_set_main_led,
    safe_get_voltage,
    safe_get_percentage
)

BLE_ENABLED = True
logger = logging.getLogger(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_argument_parser() -> argparse.ArgumentParser:
    """Create command line argument parser"""
    parser = argparse.ArgumentParser(
        description="Sphero BB-8 Control Launcher - Hardware Only",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --mode hardware           # Force hardware mode
  %(prog)s --diagnostics             # Show diagnostics and exit
  %(prog)s --ble-scan                # Scan for BB-8 devices
  %(prog)s --demo                    # Run demonstration sequence
        """
    )

    parser.add_argument(
        "--mode",
        choices=["hardware"],
        default="hardware",
        help="Controller operation mode (hardware only)"
    )

    parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Connection timeout in seconds (default: 10)"
    )

    parser.add_argument(
        "--diagnostics",
        action="store_true",
        help="Show comprehensive diagnostics and exit"
    )

    parser.add_argument(
        "--ble-scan",
        action="store_true",
        help="Perform BLE scan for BB-8 devices and exit"
    )

    parser.add_argument(
        "--demo",
        action="store_true",
        help="Run demonstration sequence"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )

    parser.add_argument(
        "--json-output",
        action="store_true",
        help="Output results in JSON format"
    )

    parser.add_argument(
        "--payload",
        type=str,
        default=None,
        help="JSON string payload for command data"
    )

    return parser

def setup_logging(verbose: bool = False):
    """Configure logging based on verbosity"""
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logging.getLogger('ha_sphero_bb8').setLevel(logging.DEBUG)
    else:
        logging.getLogger().setLevel(logging.INFO)
        # Reduce noise from external libraries
        logging.getLogger('bleak').setLevel(logging.WARNING)
        logging.getLogger('spherov2').setLevel(logging.WARNING)

def run_diagnostics(json_output: bool = False) -> Dict[str, Any]:
    """Run comprehensive system diagnostics"""
    logger.info("Running Phase 1 system diagnostics...")

    diagnostics: Dict[str, Any] = {
        "phase": "1",
        "system": "ha-sphero-bb8",
        "version": "0.2.1",
        "timestamp": time.time()
    }

    # Test controller initialization
    try:
        controller = BB8Controller()
        status = controller.get_controller_status()

        diagnostics["controller"] = {
            "initialization": "success",
            "mode": status.mode.value,
            "features_available": status.features_available,
            "uptime": status.uptime
        }

        # Get MQTT-ready diagnostics
        mqtt_diagnostics = controller.get_diagnostics_for_mqtt()
        diagnostics["mqtt_payload"] = mqtt_diagnostics

        controller.disconnect()

    except Exception as e:
        diagnostics["controller"] = {
            "initialization": "failed",
            "error": str(e)
        }

    # Test BLE environment
    try:
        diagnostics["ble"] = {"status": "skipped"}
    except Exception as e:
        diagnostics["ble"] = {
            "status": "error",
            "error": str(e)
        }

    if json_output:
        print(json.dumps(diagnostics, indent=2))
    else:
        print("=== Phase 1 System Diagnostics ===")
        print(f"System: {diagnostics['system']} v{diagnostics['version']}")
        print(f"Controller: {diagnostics['controller'].get('initialization', 'unknown')}")

        if 'features_available' in diagnostics['controller']:
            features = diagnostics['controller']['features_available']
            print("Available Features:")
            if isinstance(features, dict):
                for feature, available in features.items():
                    status = "✅" if available else "❌"
                    print(f"  {status} {feature}")
            else:
                print(f"  {features}")

        print(f"BLE Status: {diagnostics['ble'].get('status', 'unknown')}")

    return diagnostics

def run_ble_scan(timeout: int = 10, json_output: bool = False) -> Dict[str, Any]:
    """Perform BLE scan for BB-8 devices"""
    logger.info(f"Scanning for BB-8 devices (timeout: {timeout}s)...")

    scan_result: Dict[str, Any] = {
        "operation": "ble_scan",
        "timeout": timeout,
        "timestamp": time.time()
    }

    try:
        from ha_sphero_bb8.ble_gateway import scan_devices
        result = scan_devices()
        scan_result.update({
            "success": result.status.name == "SCANNING",
            "status": result.status.value,
            "scan_duration": result.scan_duration_ms / 1000.0,
            "device_count": result.devices_found,
            "error_message": result.error_message,
            "trace_id": result.trace_id
        })
    except Exception as e:
        scan_result.update({
            "success": False,
            "error": str(e)
        })

    if json_output:
        print(json.dumps(scan_result, indent=2))
    else:
        print("=== BLE Scan Results ===")
        print(f"Status: {scan_result.get('status', 'unknown')}")
        print(f"Duration: {scan_result.get('scan_duration', 0):.2f}s")
        print(f"Devices found: {scan_result.get('device_count', 0)}")

        if scan_result.get("error_message"):
            print(f"Error: {scan_result['error_message']}")

        if scan_result.get("success"):
            print("✅ BB-8 device connection successful!")
        else:
            print("❌ No BB-8 devices found or connection failed")
            print("\nTroubleshooting:")
            print("1. Ensure BB-8 is powered on and nearby")
            print("2. Check macOS Bluetooth permissions")

    return scan_result

def run_demo_sequence(controller: BB8Controller, json_output: bool = False) -> Dict[str, Any]:
    """Run demonstration sequence showcasing Phase 1 capabilities"""
    logger.info("Running Phase 1 demonstration sequence...")

    demo_result: Dict[str, Any] = {
        "operation": "demo_sequence",
        "timestamp": time.time(),
        "commands": []
    }

    try:
        # Assume device is already connected in hardware-only mode
        demo_result["connection"] = {"success": True, "mode": "hardware"}

        # Demonstrate LED control
        logger.info("Demo: LED color sequence")
        led_commands = [
            (255, 0, 0),    # Red
            (0, 255, 0),    # Green
            (0, 0, 255),    # Blue
            (255, 255, 0),  # Yellow
            (0, 0, 0)       # Off
        ]

        for r, g, b in led_commands:
            result = controller.set_led(r, g, b)
            demo_result["commands"].append({
                "command": "set_led",
                "parameters": {"r": r, "g": g, "b": b},
                "result": result
            })
            time.sleep(0.5)

        # Demonstrate movement
        logger.info("Demo: Movement sequence")
        movement_commands = [
            (50, 0),    # Forward
            (50, 90),   # Right
            (50, 180),  # Backward
            (50, 270),  # Left
            (0, 0)      # Stop
        ]

        for speed, heading in movement_commands:
            if speed > 0:
                result = controller.roll(speed, heading, timeout=1.0)
            else:
                result = controller.stop()

            demo_result["commands"].append({
                "command": "roll" if speed > 0 else "stop",
                "parameters": {"speed": speed, "heading": heading},
                "result": result
            })
            time.sleep(1.0)

        # Get final diagnostics
        final_diagnostics = controller.get_diagnostics_for_mqtt()
        demo_result["final_diagnostics"] = final_diagnostics
        demo_result["success"] = True

    except Exception as e:
        logger.error(f"Demo sequence failed: {e}")
        demo_result["success"] = False
        demo_result["error"] = str(e)

    if json_output:
        print(json.dumps(demo_result, indent=2))
    else:
        print("=== Demo Sequence Results ===")
        print(f"Status: {'✅ Success' if demo_result.get('success') else '❌ Failed'}")
        print(f"Commands executed: {len(demo_result['commands'])}")

        if demo_result.get("connection"):
            conn = demo_result["connection"]
            print(f"Connection mode: {conn.get('mode', 'unknown')}")

        if demo_result.get("error"):
            print(f"Error: {demo_result['error']}")

    return demo_result

def main():
    """Main entry point for BB-8 launcher"""
    parser = create_argument_parser()
    args = parser.parse_args()

    # Setup logging
    setup_logging(args.verbose)

    logger.info("Launching BB-8 controller")

    # BLE Gateway lifecycle integration (class-based)
    gateway = BleGateway(mode="bleak")
    device: Optional[Any] = gateway.scan_for_device()
    if device is None:
        logger.error("No BB-8 device found. Exiting.")
        print("\u274c No BB-8 device found. Check BLE connection.")
        sys.exit(1)

    # CLI command dispatch (preserve controller logic)
    if args.payload:
        try:
            payload: dict = json.loads(args.payload)
        except Exception as e:
            logger.error(f"Invalid JSON payload: {e}")
            print(f"\u274c Invalid JSON payload: {e}")
            sys.exit(2)
    else:
        payload: dict = {}

    # Example: handle_roll_command, handle_led_command, etc. (controller logic unchanged)
    # ...existing code for CLI command dispatch...

    # Clean shutdown
    gateway.shutdown()

if __name__ == "__main__":
    sys.exit(main())
