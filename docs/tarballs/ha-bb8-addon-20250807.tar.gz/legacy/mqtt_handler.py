"""
MODULE PURPOSE: Main MQTT event handler for Sphero BB-8. Manages broker connection, topic subscription,
and dispatching inbound MQTT messages to command handlers (hardware only).
STATUS: production
MAIN ENTRYPOINTS: MQTTHandler class, on_connect, on_message, on_disconnect, publish, subscribe
DEPENDENCIES: Used by run_mqtt.py (as main event loop). Imports controller.py, constants.py.
LAST VALIDATED: 2025-08-02
NOTES:
- Every command handler should use try/except for robust error logging.
- Command dispatcher must be updated if new bb8/command/* topics are added.
- Simulation, adapters, and fallback logic have been removed. Hardware-only operation is supported.
"""

# src/ha_sphero_bb8/mqtt_handler.py

# Do not import run_mqtt.py (entrypoint script) in library code to avoid circular imports.

import logging
import json
import time
import threading
from typing import Dict, Any, Optional, Callable, TYPE_CHECKING
from dataclasses import dataclass
from enum import Enum
from ha_sphero_bb8.mqtt_dispatcher import dispatch_from_topic
from .constants import (
    BASE_TOPIC, COMMAND_TOPIC, STATUS_TOPIC, DIAGNOSTICS_TOPIC, DISCOVERY_PREFIX, DEVICE_NAME, DEVICE_ID
)

try:
    import paho.mqtt.client as mqtt
    MQTT_AVAILABLE = True
except ImportError:
    MQTT_AVAILABLE = False
    mqtt = None

from .controller import BB8Controller, ControllerMode

if TYPE_CHECKING:
    from ha_sphero_bb8.controller import BB8Like

logger = logging.getLogger(__name__)

class MqttConnectionState(Enum):
    """MQTT connection state enumeration"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"

@dataclass
class MqttConfig:
    """MQTT configuration for Home Assistant integration"""
    host: str = "192.168.0.129"
    port: int = 1883
    username: Optional[str] = None
    password: Optional[str] = None
    client_id: str = "ha-sphero-bb8"
    keepalive: int = 60

    # Home Assistant MQTT Discovery
    discovery_prefix: str = DISCOVERY_PREFIX
    device_name: str = DEVICE_NAME
    device_id: str = DEVICE_ID

    # Topic structure
    base_topic: str = BASE_TOPIC
    command_topic: str = COMMAND_TOPIC
    status_topic: str = STATUS_TOPIC
    diagnostics_topic: str = DIAGNOSTICS_TOPIC

class MqttHandler:
    """
    MQTT Handler for Home Assistant Integration

    Provides MQTT scaffolding and message routing for full Home Assistant device integration.
    Hardware-only operation. Simulation and fallback logic have been removed.
    """

    def __init__(self,
                 mqtt_client,
                 controller,
                 config: MqttConfig):
        self.mqtt_client = mqtt_client
        self.controller = controller  # Injected controller instance
        self.config = config
        self.logger = logging.getLogger(f"{__name__}.MqttHandler")

        # MQTT client and state
        self.client: Optional[Any] = mqtt_client
        self.connection_state = MqttConnectionState.DISCONNECTED
        self.last_status_update = 0.0
        self.status_update_interval = 30.0  # seconds

        # Message handlers
        self.command_handlers: Dict[str, Callable] = {}
        self.status_callbacks: list = []

        # Statistics
        self.messages_received = 0
        self.messages_sent = 0
        self.commands_executed = 0
        self.errors = 0

        # Background thread for status updates
        self._status_thread: Optional[threading.Thread] = None
        self._stop_status_thread = False

        self._initialize_mqtt()
        self._register_command_handlers()

    def _initialize_mqtt(self):
        """Initialize MQTT client and configuration"""
        if not MQTT_AVAILABLE:
            self.logger.warning("paho-mqtt not available - MQTT functionality disabled")
            return

        try:
            if not MQTT_AVAILABLE or mqtt is None:
                self.logger.error("paho-mqtt is not available, cannot initialize MQTT client")
                self.client = None
                self.connection_state = MqttConnectionState.ERROR
                return

            # Use standard mqtt.Client instantiation
            self.client = mqtt.Client(client_id=self.config.client_id)
            # Set authentication if provided
            if self.client is not None and self.config.username and self.config.password:
                self.client.username_pw_set(self.config.username, self.config.password)
                self.logger.info(f"Using MQTT username: {self.config.username}")

            # Set callbacks (update signatures for VERSION2)
            if self.client is not None:
                self.client.on_connect = self._on_connect
                self.client.on_disconnect = self._on_disconnect
                self.client.on_message = self._on_message
                self.client.on_subscribe = self._on_subscribe
                self.client.on_publish = self._on_publish

            self.logger.info("MQTT client initialized")

        except Exception as e:
            self.logger.error(f"MQTT initialization failed: {e}")
            self.connection_state = MqttConnectionState.ERROR

    def _register_command_handlers(self):
        """Register MQTT command handlers"""
        self.command_handlers = {
            "move": self._handle_move_command,
            "stop": self._handle_stop_command,
            "rotate": self._handle_rotate_command,
            "led": self._handle_led_command,
            "diagnostics": self._handle_diagnostics_command,
            "test": self._handle_test_command
        }

        self.logger.info(f"Registered {len(self.command_handlers)} command handlers")

    def connect(self) -> bool:
        """Connect to MQTT broker (always recreate client to ensure host is set)"""
        self.logger.debug(f"[DEBUG] connect() called with config: host={self.config.host}, port={self.config.port}, client_id={self.config.client_id}, username={self.config.username}")
        # Always recreate the client to ensure host is set for reconnects
        if not MQTT_AVAILABLE or mqtt is None:
            self.logger.error("MQTT client not available")
            return False
        self.logger.debug(f"[DEBUG] Creating new MQTT client for host={self.config.host}")
        self.client = mqtt.Client(client_id=self.config.client_id)
        if self.config.username and self.config.password:
            self.logger.debug(f"[DEBUG] Setting MQTT username: {self.config.username}")
            self.client.username_pw_set(self.config.username, self.config.password)
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        self.client.on_subscribe = self._on_subscribe
        self.client.on_publish = self._on_publish
        self.logger.info("MQTT client initialized (recreated for connect)")
        try:
            self.connection_state = MqttConnectionState.CONNECTING
            self.logger.info(f"Connecting to MQTT broker at {self.config.host}:{self.config.port} (client_id={self.config.client_id})")
            self.logger.debug(f"[DEBUG] About to call self.client.connect() with host={self.config.host}, port={self.config.port}, keepalive={self.config.keepalive}")
            result = self.client.connect(
                self.config.host,
                self.config.port,
                self.config.keepalive
            )
            self.logger.debug(f"[DEBUG] self.client.connect() result: {result}")
            mqtt_success = mqtt.MQTT_ERR_SUCCESS if MQTT_AVAILABLE and mqtt is not None and hasattr(mqtt, "MQTT_ERR_SUCCESS") else 0
            if result == mqtt_success:
                self.logger.info("[DEBUG] MQTT connect() returned success, starting loop thread.")
                self.client.loop_start()
                return True
            else:
                self.logger.error(f"MQTT connection failed with code: {result}")
                self.connection_state = MqttConnectionState.ERROR
                return False
        except Exception as e:
            self.logger.error(f"MQTT connection error: {e}")
            self.logger.debug(f"[DEBUG] Exception details:", exc_info=True)
            self.connection_state = MqttConnectionState.ERROR
            return False

    def disconnect(self):
        """Disconnect from MQTT broker and clear client for robust reconnects"""
        self._stop_status_thread = True
        if self._status_thread and self._status_thread.is_alive():
            self._status_thread.join(timeout=5.0)
        if self.client:
            self.logger.debug(f"[DEBUG] disconnect() called. client._host={getattr(self.client, '_host', None)}, config.host={self.config.host}")
            self.client.loop_stop()
            self.client.disconnect()
            self.connection_state = MqttConnectionState.DISCONNECTED
            self.logger.info("MQTT disconnected")
            self.client = None  # Clear client so connect() will recreate

    def publish_status(self, force: bool = False) -> bool:
        """Publish BB-8 status to MQTT"""
        current_time = time.time()

        if not force and (current_time - self.last_status_update) < self.status_update_interval:
            return True  # Skip if too soon

        try:
            if not self.controller:
                status_payload = {
                    "controller": "not_initialized",
                    "timestamp": current_time
                }
            else:
                status_payload = self.controller.get_diagnostics_for_mqtt()

            # Add MQTT handler metadata
            status_payload["mqtt"] = {
                "connection_state": self.connection_state.value,
                "messages_received": self.messages_received,
                "messages_sent": self.messages_sent,
                "commands_executed": self.commands_executed,
                "errors": self.errors
            }

            success = self._publish_message(self.config.status_topic, status_payload)

            if success:
                self.last_status_update = current_time
                self.logger.debug("Status published to MQTT")

            return success

        except Exception as e:
            self.logger.error(f"Status publish failed: {e}")
            self.errors += 1
            return False

    def publish_discovery_config(self) -> bool:
        """Publish Home Assistant MQTT discovery configuration"""
        try:
            # Device configuration for HA discovery
            device_config = {
                "identifiers": [self.config.device_id],
                "name": self.config.device_name,
                "model": "BB-8",
                "manufacturer": "Sphero",
                "sw_version": "ha-sphero-bb8-0.2.1"
            }

            # Battery sensor discovery
            battery_config = {
                "name": f"{self.config.device_name} Battery",
                "unique_id": f"{self.config.device_id}_battery",
                "state_topic": self.config.status_topic,
                "value_template": "{{ value_json.battery.percentage }}",
                "unit_of_measurement": "%",
                "device_class": "battery",
                "device": device_config
            }

            battery_topic = f"{self.config.discovery_prefix}/sensor/{self.config.device_id}/battery/config"
            self._publish_message(battery_topic, battery_config, retain=True)

            # Connection status binary sensor
            connection_config = {
                "name": f"{self.config.device_name} Connection",
                "unique_id": f"{self.config.device_id}_connection",
                "state_topic": self.config.status_topic,
                "value_template": "{{ 'ON' if value_json.controller.connected else 'OFF' }}",
                "device_class": "connectivity",
                "device": device_config
            }

            connection_topic = f"{self.config.discovery_prefix}/binary_sensor/{self.config.device_id}/connection/config"
            self._publish_message(connection_topic, connection_config, retain=True)

            self.logger.info("HA discovery configuration published")
            return True

        except Exception as e:
            self.logger.error(f"Discovery config publish failed: {e}")
            self.errors += 1
            return False

    def _publish_message(self, topic: str, payload: Dict[str, Any], retain: bool = False) -> bool:
        """Publish message to MQTT topic"""
        if not self.client or self.connection_state != MqttConnectionState.CONNECTED:
            self.logger.warning("Cannot publish - MQTT not connected")
            return False

        try:
            json_payload = json.dumps(payload)
            result = self.client.publish(topic, json_payload, retain=retain)

            # Check if mqtt is available and has MQTT_ERR_SUCCESS
            if MQTT_AVAILABLE and mqtt is not None and hasattr(mqtt, "MQTT_ERR_SUCCESS"):
                mqtt_success = mqtt.MQTT_ERR_SUCCESS
            else:
                mqtt_success = 0  # Default to 0 if not available

            if result.rc == mqtt_success:
                self.messages_sent += 1
                return True
            else:
                self.logger.error(f"Publish failed with code: {result.rc}")
                return False

        except Exception as e:
            self.logger.error(f"Publish error: {e}")
            self.errors += 1
            return False

    def _start_status_thread(self):
        """Start background thread for periodic status updates"""
        # Validate MQTT host before starting status thread
        if not getattr(self.config, "host", None) or self.config.host in ("", None, "0.0.0.0", "invalid", "<unset>"):
            self.logger.error(f"Not starting status thread: Invalid MQTT host '{self.config.host}'")
            return
        if self._status_thread and self._status_thread.is_alive():
            return

        self._stop_status_thread = False
        self._status_thread = threading.Thread(target=self._status_update_loop, daemon=True)
        self._status_thread.start()
        self.logger.info("Status update thread started")

    def _status_update_loop(self):
        """Background loop for periodic status updates"""
        while not self._stop_status_thread:
            try:
                self.publish_status()
                time.sleep(self.status_update_interval)
            except Exception as e:
                self.logger.error(f"Status update loop error: {e}")
                time.sleep(5.0)

    # MQTT callback handlers
    def _on_connect(self, client, userdata, flags, reason_code, properties=None):
        """Handle MQTT connection"""
        if hasattr(reason_code, 'is_failure') and reason_code.is_failure:
            self.connection_state = MqttConnectionState.ERROR
            self.logger.error(f"MQTT connection failed with code: {reason_code}")
            return
        self.connection_state = MqttConnectionState.CONNECTED
        self.logger.info("MQTT connected successfully")

        # Subscribe to command topic
        client.subscribe(self.config.command_topic)
        self.logger.info(f"Subscribed to {self.config.command_topic}")

        # Subscribe to all command subtopics
        client.subscribe("bb8/command/#")
        self.logger.info("Subscribed to bb8/command/#")

        # Publish discovery configuration
        self.publish_discovery_config()

        # Start status updates
        self._start_status_thread()

    def _on_disconnect(self, client, userdata, reason_code, properties=None):
        """Handle MQTT disconnection"""
        self.logger.debug(f"[DEBUG] _on_disconnect called. client._host={getattr(client, '_host', None)}, config.host={self.config.host}, rc={reason_code}")
        self.connection_state = MqttConnectionState.DISCONNECTED
        self.logger.warning(f"MQTT disconnected with code: {reason_code}. Host at disconnect: {self.config.host}")

    def _on_message(self, client, userdata, msg):
        """Handle incoming MQTT message"""
        try:
            self.messages_received += 1
            topic = msg.topic
            payload = json.loads(msg.payload.decode())
            self.logger.info(f"Received message on {topic}: {payload}")

            # Parse command from topic: "bb8/command/led" → "led"
            segments = topic.split("/")
            if len(segments) == 3 and segments[0] == "bb8" and segments[1] == "command":
                command = segments[2]
                handler = self.command_handlers.get(command)
                if handler:
                    result = handler(payload)
                    # Optionally publish a response
                else:
                    self.logger.error(f"Unknown command subtopic: {topic}")
            else:
                self.logger.warning(f"Unexpected message topic: {topic}")

        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in message: {e}")
            self.errors += 1
        except Exception as e:
            self.logger.error(f"Message handling error: {e}")
            self.errors += 1

    def _on_subscribe(self, client, userdata, mid, reason_code_list, properties=None):
        """Handle subscription confirmation"""
        self.logger.debug(f"Subscription confirmed with reason codes: {reason_code_list}")

    def _on_publish(self, client, userdata, mid, reason_code=None, properties=None):
        """Handle publish confirmation"""
        self.logger.debug(f"Message published with ID: {mid}, reason_code: {reason_code}")

    def _handle_command_message(self, payload: Dict[str, Any]):
        """Handle command message from MQTT"""
        try:
            command = payload.get("command")
            if not command:
                self.logger.error("No command specified in message")
                return

            if command not in self.command_handlers:
                self.logger.error(f"Unknown command: {command}")
                return

            # Execute command handler
            handler = self.command_handlers[command]
            result = handler(payload)

            # Publish command result
            response_payload = {
                "command": command,
                "result": result,
                "timestamp": time.time()
            }

            response_topic = f"{self.config.base_topic}/response"
            self._publish_message(response_topic, response_payload)

            self.commands_executed += 1

        except Exception as e:
            self.logger.error(f"Command handling error: {e}")
            self.errors += 1

    # Command handlers
    def _handle_move_command(self, payload: Dict[str, Any]):
        try:
            if not self.controller:
                self.logger.error("Controller not available for move command")
                return {"success": False, "error": "Controller not available"}
            logger.info("[MQTT] Handling move command: %s", payload)
            speed = payload.get("speed", 50)
            heading = payload.get("heading", 0)
            return self.controller.roll(speed=speed, heading=heading)
        except Exception as e:
            self.logger.error(f"Move command error: {e}")
            return {"success": False, "error": str(e)}

    def _handle_stop_command(self, payload: Dict[str, Any]):
        try:
            if not self.controller:
                self.logger.error("Controller not available for stop command")
                return {"success": False, "error": "Controller not available"}
            logger.info("[MQTT] Handling stop command")
            return self.controller.stop()
        except Exception as e:
            self.logger.error(f"Stop command error: {e}")
            return {"success": False, "error": str(e)}

# Note: achieve rotation by using roll() with speed=0 and desired heading to simulate orientation change without forward motion

    def _handle_rotate_command(self, payload: Dict[str, Any]):
        try:
            if not self.controller:
                self.logger.error("Controller not available for rotate command")
                return {"success": False, "error": "Controller not available"}
            logger.info("[MQTT] Handling rotate command: %s", payload)
            angle = payload.get("angle", 90)
            return self.controller.roll(speed=0, heading=angle)
        except Exception as e:
            self.logger.error(f"Rotate command error: {e}")
            return {"success": False, "error": str(e)}

    def _handle_led_command(self, payload: Dict[str, Any]):
        try:
            if not self.controller:
                self.logger.error("Controller not available for led command")
                return {"success": False, "error": "Controller not available"}
            logger.info("[MQTT] Handling LED command: %s", payload)
            color = payload.get("color", "blue")
            # Accept both color name or RGB tuple
            if isinstance(color, str):
                # Simple color mapping (expand as needed)
                color_map = {"blue": (0, 0, 255), "red": (255, 0, 0), "green": (0, 255, 0)}
                r, g, b = color_map.get(color.lower(), (0, 0, 255))
            elif isinstance(color, (tuple, list)) and len(color) == 3:
                r, g, b = color
            else:
                r, g, b = (0, 0, 255)
            # Use set_led (controller API), not set_main_led
            return self.controller.set_led(r, g, b)
        except Exception as e:
            self.logger.error(f"LED command error: {e}")
            return {"success": False, "error": str(e)}

    def _handle_diagnostics_command(self, payload: Dict[str, Any]):
        try:
            if not self.controller:
                self.logger.error("Controller not available for diagnostics command")
                return {"success": False, "error": "Controller not available"}
            logger.info("[MQTT] Handling diagnostics command")
            if hasattr(self.controller, "get_diagnostics_for_mqtt"):
                diagnostics = self.controller.get_diagnostics_for_mqtt()
                self.publish_status(force=True)
                return {"success": True, "diagnostics": diagnostics}
            else:
                return {"success": False, "error": "Diagnostics not available"}
        except Exception as e:
            self.logger.error(f"Diagnostics command error: {e}")
            return {"success": False, "error": str(e)}

    def _handle_test_command(self, payload: Dict[str, Any]):
        try:
            if not self.controller:
                self.logger.error("Controller not available for test command")
                return {"success": False, "error": "Controller not available"}
            logger.info("[MQTT] Handling test command - rolling forward then stopping")
            self.controller.roll(speed=60, heading=0)
            time.sleep(1)
            self.controller.stop()
            return {"success": True, "message": "Test command executed"}
        except Exception as e:
            self.logger.error(f"Test command error: {e}")
            return {"success": False, "error": str(e)}

    def publish_heartbeat(self, connected: bool, last_ping_success: bool, consecutive_failures: int, error: Optional[str] = None):
        """Publish heartbeat/connection health status to MQTT."""
        payload = {
            "connected": connected,
            "last_ping_success": last_ping_success,
            "consecutive_failures": consecutive_failures,
            "timestamp": time.time()
        }
        if error:
            payload["error"] = error
        topic = f"{self.config.base_topic}/status/heartbeat"
        self._publish_message(topic, payload, retain=True)

__all__: list[str] = []

# Helper functions for MQTT integration
def create_default_config() -> MqttConfig:
    """Create default MQTT configuration"""
    return MqttConfig()

def create_mqtt_handler(mqtt_client, controller, config: MqttConfig) -> MqttHandler:
    return MqttHandler(mqtt_client=mqtt_client, controller=controller, config=config)

# Phase 2 preparation note
def prepare_phase2_integration() -> Dict[str, Any]:
    """Prepare Phase 2 HA integration checklist"""
    return {
        "phase2_requirements": {
            "mqtt_broker": "Home Assistant MQTT broker or external broker",
            "ha_discovery": "MQTT Discovery enabled in Home Assistant",
            "device_integration": "Custom integration or MQTT device setup",
            "entity_mapping": "Map BB-8 capabilities to HA entities"
        },
        "entities_planned": {
            "sensor.bb8_battery": "Battery percentage sensor",
            "binary_sensor.bb8_connection": "Connection status",
            "button.bb8_emergency_stop": "Emergency stop button",
            "light.bb8_led": "LED color control",
            "device_tracker.bb8": "Position tracking (if applicable)"
        },
        "services_planned": {
            "bb8.roll": "Roll command service",
            "bb8.set_led": "LED control service",
            "bb8.stop": "Stop command service"
        },
        "implementation_notes": [
            "MQTT handler provides Phase 2 foundation",
            "Discovery configuration ready for HA integration",
            "Command routing established and tested",
            "Status publishing aligned with HA expectations"
        ]
    }

if __name__ == "__main__":
    # Test MQTT handler in hardware mode only (simulation removed)
    logging.basicConfig(level=logging.INFO)

    print("Testing MQTT Handler (Hardware Mode)")

    # Create controller and MQTT handler
    controller = BB8Controller(mode=ControllerMode.HARDWARE)
    # No connect() call; hardware connection should be handled by main orchestration

    mqtt_handler = MqttHandler(
        mqtt_client=None,
        controller=controller,
        config=create_default_config()
    )

    # Test status publishing
    mqtt_handler.publish_status(force=True)
    mqtt_handler.publish_discovery_config()

    # Test command simulation
    test_command = {
        "command": "roll",
        "speed": 100,
        "heading": 90
    }

    mqtt_handler._handle_command_message(test_command)

    # Cleanup
    mqtt_handler.disconnect()
    controller.disconnect()

    print("MQTT handler test completed")
