import asyncio
from spherov2.scanner import find_BB8

# Workaround for nested event loop
try:
    import nest_asyncio
    nest_asyncio.apply()
except ImportError:
    pass

async def main():
    print("Scanning for BB-8...")
    bb8 = find_BB8(timeout=15)
    if not bb8:
        print("BB-8 not found. Ensure it is ON and close to your computer.")
        return

    print("BB-8 found:", bb8)
    try:
        bb8.set_main_led(0, 255, 0, 255)  # Green, full brightness
        print("LED command sent: Green")
    except Exception as e:
        print("FAILED to set LED via SDK method:", e)

if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    if loop.is_running():
        # For environments with an already running loop (Jupyter, some shells)
        task = loop.create_task(main())
        loop.run_until_complete(task)
    else:
        asyncio.run(main())
