import pytest
from ha_sphero_bb8.controller import BB8Controller

class DummyDevice:
    def __init__(self, support):
        self._support = support
        self._connected = True
    def is_connected(self):
        return self._connected
    def get_battery_voltage(self):
        if self._support.get('battery_voltage', False):
            return 7.2
        raise NotImplementedError()
    def get_battery_percentage(self):
        if self._support.get('battery_percentage', False):
            return 80
        raise NotImplementedError()
    def set_led(self, r, g, b):
        if self._support.get('set_led', False):
            return {"success": True}
        raise NotImplementedError()
    def roll(self, speed, heading, timeout=None, boost=False):
        if self._support.get('roll', False):
            return {"success": True}
        raise NotImplementedError()
    def stop(self):
        if self._support.get('stop', False):
            return True
        raise NotImplementedError()
    def ping(self):
        if self._support.get('ping', False):
            return True
        raise NotImplementedError()
    def set_main_led(self, r, g, b):
        if self._support.get('set_main_led', False):
            return True
        raise NotImplementedError()

@pytest.mark.parametrize("support", [
    {"battery_voltage": True, "set_led": True, "roll": True, "stop": True, "ping": True, "battery_percentage": True, "set_main_led": True},
    {"battery_voltage": False, "set_led": True, "roll": True, "stop": True, "ping": True, "battery_percentage": False, "set_main_led": False},
    {"battery_voltage": False, "set_led": False, "roll": False, "stop": False, "ping": False, "battery_percentage": False, "set_main_led": False},
])
def test_device_capabilities(support):
    device = DummyDevice(support)
    # Check that supported features work, unsupported raise NotImplementedError
    for cap, expected in support.items():
        if expected:
            # Should not raise
            if cap == 'battery_voltage':
                assert device.get_battery_voltage() == 7.2
            elif cap == 'battery_percentage':
                assert device.get_battery_percentage() == 80
            elif cap == 'set_led':
                assert device.set_led(0,0,0)["success"]
            elif cap == 'roll':
                assert device.roll(10,0)["success"]
            elif cap == 'stop':
                assert device.stop() is True
            elif cap == 'ping':
                assert device.ping() is True
            elif cap == 'set_main_led':
                assert device.set_main_led(0,0,0) is True
        else:
            # Should raise
            with pytest.raises(NotImplementedError):
                if cap == 'battery_voltage':
                    device.get_battery_voltage()
                elif cap == 'battery_percentage':
                    device.get_battery_percentage()
                elif cap == 'set_led':
                    device.set_led(0,0,0)
                elif cap == 'roll':
                    device.roll(10,0)
                elif cap == 'stop':
                    device.stop()
                elif cap == 'ping':
                    device.ping()
                elif cap == 'set_main_led':
                    device.set_main_led(0,0,0)
