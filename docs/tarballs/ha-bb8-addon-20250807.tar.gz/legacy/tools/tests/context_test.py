from spherov2.scanner import find_BB8

print("TEST: About to enter BB-8 context manager")
with find_BB8(timeout=30) as bb8:
    print("TEST: Inside context manager, BB-8 object:", bb8)
print("TEST: Exited context manager cleanly")
