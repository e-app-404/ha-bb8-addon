#!/usr/bin/env python3
"""
jtbd01_ble_connect.py
Purpose: Scan, connect, and activate LED on BB-8 for empirical audit (JTBD-01).
Logs all steps with ISO timestamp, MAC, UUID, and command bytes.
Artifacts: Log in artifacts/JTBD-01_log_<timestamp>_<MAC>.txt, video in artifacts/.

Usage:
  python jtbd01_ble_connect.py

Requirements:
  - bleak
  - BB-8 must be awake and not connected to another device
  - Update MAC and UUID if needed
"""
import asyncio
import logging
import sys
from datetime import datetime
from pathlib import Path

from bleak import BleakScanner, BleakClient

# --- CONFIG ---
BB8_MAC = "259ED00E-3026-2568-C410-4590C9A9297C"  # Update if needed
BB8_MAC_LOG = BB8_MAC.replace(":", "").replace("-", "")
LED_UUID = "00010002-574f-4f20-5370-6865726f2121"  # Confirm actual UUID used
LED_BYTES = bytes([0x00, 0xFF, 0x00, 0xFF])  # Test: green
ARTIFACTS_DIR = Path("artifacts")
ARTIFACTS_DIR.mkdir(exist_ok=True)
LOG_PATH = ARTIFACTS_DIR / f"JTBD-01_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{BB8_MAC_LOG}.txt"

# --- LOGGING SETUP ---
logger = logging.getLogger("jtbd01")
logger.setLevel(logging.INFO)
log_handler = logging.FileHandler(LOG_PATH, encoding="utf-8")
log_formatter = logging.Formatter("%(asctime)s | [JTBD-01][%(mac)s] %(message)s", "%Y-%m-%dT%H:%M:%S")
log_handler.setFormatter(log_formatter)
logger.addHandler(log_handler)

# Helper to log with MAC
class MACAdapter(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        return msg, {**kwargs, "extra": {"mac": BB8_MAC_LOG}}

log = MACAdapter(logger, {})

async def main():
    log.info("BLE scan started")
    device = None
    try:
        devices = await BleakScanner.discover(timeout=10.0)
        for d in devices:
            if d.address.replace(":", "").replace("-", "").upper() == BB8_MAC_LOG.upper():
                device = d
                break
        if not device:
            log.error(f"BB-8 NOT FOUND @ {BB8_MAC_LOG}")
            print(f"[ERROR] BB-8 not found: {BB8_MAC}")
            sys.exit(2)
        log.info(f"BB-8 FOUND @ {BB8_MAC_LOG}")
        async with BleakClient(device) as client:
            if not client.is_connected:
                log.error("Failed to connect to BB-8")
                print("[ERROR] Failed to connect to BB-8")
                sys.exit(3)
            log.info(f"Connected, activating LED (UUID={LED_UUID}, BYTES={LED_BYTES.hex()})")
            try:
                await client.write_gatt_char(LED_UUID, LED_BYTES, response=True)
                log.info(f"LED command sent, check BB-8 for light")
                print("[INFO] LED command sent, check BB-8 for light")
            except Exception as e:
                log.error(f"LED command failed: {e}")
                print(f"[ERROR] LED command failed: {e}")
                sys.exit(4)
    except Exception as e:
        log.error(f"Exception: {e}")
        print(f"[ERROR] Exception: {e}")
        sys.exit(1)
    log.info("SUCCESS. Prompt operator to capture video for audit.")
    print("[SUCCESS] Prompt operator to capture video for audit.")

if __name__ == "__main__":
    asyncio.run(main())
