#!/usr/bin/env python3
"""
jtbd01_protocol_led.py
JTBD-01: Protocol-layer, audit-grade LED activation for BB-8 (SpheroV2 stack, MAC=259ED00E30262568C4104590C9A9297C)
Logs all steps, escalates on failure, and prompts for video artifact.

Usage:
  python jtbd01_protocol_led.py

Artifacts:
  - Log: artifacts/JTBD-01_log_<timestamp>_259ED00E30262568C4104590C9A9297C.txt
  - Video: artifacts/JTBD-01_video_<timestamp>_259ED00E30262568C4104590C9A9297C.mp4
"""
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))  # Ensure _vendor is importable
import _vendor.spherov2 as spherov2  # type: ignore
from _vendor.spherov2.toy.bb8 import BB8  # type: ignore
from _vendor.spherov2.adapter.bleak_adapter import BleakAdapter  # type: ignore

BB8_MAC = "259ED00E30262568C4104590C9A9297C"
ARTIFACTS_DIR = Path("artifacts")
ARTIFACTS_DIR.mkdir(exist_ok=True)
LOG_PATH = ARTIFACTS_DIR / f"JTBD-01_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{BB8_MAC}.txt"


def log(msg):
    stamp = datetime.now().isoformat()
    with open(LOG_PATH, "a") as f:
        f.write(f"{stamp} | [JTBD-01][{BB8_MAC}] {msg}\n")
    print(f"{stamp} | [JTBD-01][{BB8_MAC}] {msg}")

def normalize_mac(mac):
    return mac.replace("-", "").replace(":", "").upper()

# --- Protocol Timeout Patch ---
# Try to patch the default protocol timeout to 30s for audit
try:
    import _vendor.spherov2.toy as toy_mod
    if hasattr(toy_mod.Toy, '_wait_packet'):
        orig_wait_packet = toy_mod.Toy._wait_packet
        def patched_wait_packet(self, key, timeout=30.0, check_error=False):
            log(f"[DEBUG] Using protocol timeout: {timeout}s for _wait_packet (patched)")
            return orig_wait_packet(self, key, timeout, check_error)
        toy_mod.Toy._wait_packet = patched_wait_packet
        log("Patched Toy._wait_packet to use 30s timeout for audit.")
except Exception as e:
    log(f"[WARN] Could not patch protocol timeout: {e}")

# --- Verbose BLE/Packet Logging ---
try:
    import _vendor.spherov2.adapter.bleak_adapter as ba_mod
    orig_write = ba_mod.BleakAdapter.write
    def verbose_write(self, uuid, data):
        log(f"[BLE WRITE] UUID: {uuid}, DATA: {data.hex()}")
        return orig_write(self, uuid, data)
    ba_mod.BleakAdapter.write = verbose_write
    log("Patched BleakAdapter.write for verbose BLE logging.")
except Exception as e:
    log(f"[WARN] Could not patch BLE write logging: {e}")

try:
    log(f"SpheroV2 @ {getattr(spherov2, '__file__', 'unknown')}")
    print("[INFO] Operator: Please ensure BB-8 is awake (move it, or use charger) before running.")
    log("Operator: Please ensure BB-8 is awake (move it, or use charger) before running.")
    log("Scanning for BB-8 toys via BleakAdapter.scan_toys()...")
    toys = BleakAdapter.scan_toys(timeout=10)
    log(f"Scan results: {[f'{t.name}@{t.address}' for t in toys]}")
    if len(toys) > 1:
        log(f"WARNING: Multiple BLE adapters/devices detected: {[t.address for t in toys]}")
        print("[WARN] Multiple BLE adapters/devices detected. Ensure only one BB-8 is powered on.")
    bb8_toy = next((t for t in toys if normalize_mac(t.address) == BB8_MAC), None)
    if not bb8_toy:
        log("BB-8 with specified MAC not found. Escalating blocker.")
        sys.exit(2)
    log(f"BB-8 FOUND: {bb8_toy.name} @ {bb8_toy.address}")
    bb8 = BB8(bb8_toy, BleakAdapter)
    log("Trying bb8.wake()...")
    try:
        bb8.wake()
        log("bb8.wake() sent.")
        time.sleep(1)
    except Exception as e:
        log(f"Wake failed or not supported: {e}\n{traceback.format_exc()}")
    log("Connecting to BB-8 and sending set_main_led(0, 255, 0) with up to 3 retries...")
    retry_count = 0
    max_retries = 3
    while retry_count < max_retries:
        try:
            with bb8:
                bb8.set_main_led(bb8, 0, 255, 0)
                log(f"set_main_led(0,255,0) command sent (attempt {retry_count+1}). Check BB-8 for green LED.")
                print("[SUCCESS] Main LED command sent; check BB-8 for visual confirmation.")
                log("Prompt operator to capture video artifact for audit.")
                print("[ACTION] Please capture a video of BB-8 lighting up and save to artifacts/ as instructed.")
                time.sleep(2)
                break
        except TimeoutError as e:
            log(f"LED command timed out (attempt {retry_count+1}): {e}\n{traceback.format_exc()}\nSuggest retry, verify BB-8 is awake, and check BLE interference.")
            print(f"[WARN] LED command timed out (attempt {retry_count+1}). Retrying...")
            retry_count += 1
            time.sleep(2)
        except Exception as e:
            log(f"FAILED: {e}\n{traceback.format_exc()}")
            print(f"[ERROR] {e}")
            sys.exit(1)
    else:
        log(f"FAILED: All {max_retries} attempts to set_main_led timed out or failed. Suggest rebooting BB-8 and retrying.")
        print(f"[ERROR] All {max_retries} attempts failed. Suggest rebooting BB-8 and retrying.")
        sys.exit(1)
except Exception as e:
    log(f"FAILED: {e}\n{traceback.format_exc()}")
    print(f"[ERROR] {e}")
    sys.exit(1)
