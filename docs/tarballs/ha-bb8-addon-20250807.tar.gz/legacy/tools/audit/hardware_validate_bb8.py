# hardware_validate_bb8.py
"""
Direct hardware validation for BB-8 using local spherov2 (_vendor).
Performs LED and movement commands for MVP signoff.

Operator: Please observe BB-8 and confirm physical feedback (lights/moves).
"""

import sys
import time
from spherov2.scanner import find_BB8
from spherov2.adapter.bleak_adapter import BleakAdapter
from spherov2.commands.sphero import RollModes, ReverseFlags

try:
  # toy = find_BB8(toy_name=None, timeout=10.0)
    toy = find_BB8(toy_name="BB-B54A", timeout=10.0)
  # toy = find_BB8(timeout=10.0)  # Increase scan timeout
    if toy is None:
        print("[ERROR] BB-8 not found. Make sure it is awake, not connected to another device, and nearby.")
        sys.exit(2)
    bb8 = toy.__class__(toy, BleakAdapter)
    print(f"[DEBUG] bb8 type: {type(bb8)}")
    print(f"[DEBUG] bb8.set_main_led: {bb8.set_main_led}")
    print(f"[DEBUG] bb8.roll: {bb8.roll}")
    with bb8:
        bb8.set_main_led(255, 0, 0, 0)  # Set to RED for visible validation (added missing 'b' parameter)
        print("[INFO] LED set to RED. Observe BB-8 lighting up.")
        time.sleep(1)
        bb8.roll(50, 0, 0, roll_mode=RollModes.GO, reverse_flag=ReverseFlags.OFF)  # Roll forward
        print("[INFO] BB-8 rolling forward. Observe movement.")
        time.sleep(2)
        bb8.roll(50, 0, 0, roll_mode=RollModes.STOP, reverse_flag=ReverseFlags.OFF)   # Stop
        print("[INFO] BB-8 stopped.")
        print("\nBB-8 test complete. Please confirm if BB-8 lit up or moved.")
except Exception as e:
    print(f"[ERROR] Exception during BB-8 hardware validation: {e}")
    sys.exit(1)

# Operator: Paste terminal output and describe/photo BB-8's response for governance signoff.
