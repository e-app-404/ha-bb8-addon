#!/usr/bin/env python3
"""
ble_services_enum_jtbd01.py
JTBD-01 Diagnostic Script: Enumerate all GATT services and characteristics for BB-8 (MAC: 259ED00E30262568C4104590C9A9297C).
Purpose: Temporary audit script to empirically log all BLE services/characteristics for artifact and handler mapping.

Artifact log: artifacts/JTBD-01_log_<timestamp>_<MAC>.txt

Cleanup: Remove or archive after audit/closure per governance protocol.
"""
import asyncio
from datetime import datetime
from bleak import BleakScanner, BleakClient

BB8_MAC = "259ED00E30262568C4104590C9A9297C"
ARTIFACT_LOG = f"artifacts/JTBD-01_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{BB8_MAC}.txt"

def log(msg):
    stamp = datetime.now().isoformat()
    with open(ARTIFACT_LOG, "a") as f:
        f.write(f"{stamp} | {msg}\n")
    print(f"{stamp} | {msg}")

def normalize_mac(mac):
    return mac.replace("-", "").replace(":", "").upper()

async def main():
    log(f"BLE scan started for BB-8 MAC: {BB8_MAC}")
    devices = await BleakScanner.discover(timeout=10.0)
    found = None
    for d in devices:
        if normalize_mac(d.address) == normalize_mac(BB8_MAC):
            found = d
            break
    if not found:
        log("BB-8 NOT FOUND. Scan result: " + ", ".join([dev.address for dev in devices]))
        return
    log(f"BB-8 FOUND: {found.name} @ {found.address}")

    try:
        async with BleakClient(found.address) as client:
            log("Connected. Enumerating all services and characteristics:")
            for service in client.services:
                log(f"SERVICE: {service.uuid} - {service.description}")
                for char in service.characteristics:
                    log(f"  CHARACTERISTIC: {char.uuid} - {char.properties}")
    except Exception as e:
        log(f"FAILED: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main())
