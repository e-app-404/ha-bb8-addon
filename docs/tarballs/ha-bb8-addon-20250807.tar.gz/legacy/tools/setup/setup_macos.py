# setup_macos.py
"""
macOS App Bundle Configuration with BLE Entitlements
Phase 1: Production-ready .app bundling for BB-8 control

Provides:
- py2app configuration with proper BLE entitlements
- macOS 15+ TCC compliance for Bluetooth access
- Standalone app distribution for end users
- Development vs production bundle configurations

HESTIA Compliance:
- Tier: α (deployment/distribution)
- Enables: Native macOS app deployment
- Requires: py2app, proper code signing (optional)
- Supports: Both development and distribution builds
"""

import os
import sys
import plistlib
from pathlib import Path
from typing import Dict, Any, List

# py2app configuration for ha-sphero-bb8
APP_NAME = "BB8 Control"
APP_VERSION = "0.2.1"
APP_BUNDLE_ID = "app.evert.ha-sphero-bb8"
MAIN_SCRIPT = "src/ha_sphero_bb8/launch_bb8.py"

# BLE entitlements for macOS 15+ TCC compliance
BLE_ENTITLEMENTS = {
    "com.apple.developer.bluetooth-central": True,
    "com.apple.developer.bluetooth-peripheral": True,
}

# App information for Info.plist
APP_INFO = {
    "CFBundleName": APP_NAME,
    "CFBundleDisplayName": APP_NAME,
    "CFBundleIdentifier": APP_BUNDLE_ID,
    "CFBundleVersion": APP_VERSION,
    "CFBundleShortVersionString": APP_VERSION,
    "NSHumanReadableCopyright": "© 2025 Evert Appels",
    "NSBluetoothAlwaysUsageDescription": "BB8 Control needs Bluetooth access to connect and control your Sphero BB-8 robot.",
    "NSBluetoothPeripheralUsageDescription": "BB8 Control uses Bluetooth to discover and communicate with Sphero BB-8 devices.",
    "LSMinimumSystemVersion": "10.15.0",  # macOS Catalina minimum
    "LSApplicationCategoryType": "public.app-category.utilities",
    "NSRequiresAquaSystemAppearance": False,  # Support dark mode
    "NSHighResolutionCapable": True,
    "LSUIElement": False,  # Show in Dock
}

# py2app build options
PY2APP_OPTIONS = {
    "argv_emulation": True,
    "iconfile": None,  # Add icon file path if available
    "plist": APP_INFO,
    "packages": [
        "ha_sphero_bb8",
        "spherov2",
        "bleak",
        "numpy",
        "transforms3d"
    ],
    "includes": [
        "ha_sphero_bb8.launch_bb8",
        "ha_sphero_bb8.ble_gateway",
        "ha_sphero_bb8.bb8_control",
        "ha_sphero_bb8.device_core",
        "ha_sphero_bb8.simulation_adapter",
        "spherov2.scanner",
        "spherov2.toy.bb8",
        "bleak"
    ],
    "excludes": [
        "tkinter",
        "PyQt5",
        "PyQt6",
        "PySide2", 
        "PySide6",
        "matplotlib",
        "scipy"
    ],
    "resources": [],
    "optimize": 2,
    "compressed": True,
    "semi_standalone": False,
    "strip": True,
    "prefer_ppc": False,
    "arch": "universal2",  # Universal binary for Intel and Apple Silicon
    "codesign_identity": None,  # Set if code signing required
    "entitlements": BLE_ENTITLEMENTS
}

def create_entitlements_plist() -> str:
    """Create entitlements.plist file for BLE access"""
    entitlements_path = "build/entitlements.plist"
    os.makedirs("build", exist_ok=True)
    
    entitlements = {
        "com.apple.developer.bluetooth-central": True,
        "com.apple.developer.bluetooth-peripheral": True,
        "com.apple.security.device.bluetooth": True,
        "com.apple.security.personal-information.bluetooth": True
    }
    
    with open(entitlements_path, "wb") as f:
        plistlib.dump(entitlements, f)
    
    print(f"Created entitlements.plist at {entitlements_path}")
    return entitlements_path

def create_info_plist_template() -> str:
    """Create Info.plist template with BLE usage descriptions"""
    info_plist_path = "build/Info.plist.template"
    os.makedirs("build", exist_ok=True)
    
    info_plist = APP_INFO.copy()
    
    # Add additional macOS-specific keys
    info_plist.update({
        "NSSupportsAutomaticGraphicsSwitching": True,
        "NSAppTransportSecurity": {
            "NSAllowsArbitraryLoads": False
        },
        "CFBundleDocumentTypes": [],
        "CFBundleURLTypes": []
    })
    
    with open(info_plist_path, "wb") as f:
        plistlib.dump(info_plist, f)
    
    print(f"Created Info.plist template at {info_plist_path}")
    return info_plist_path

def validate_macos_environment() -> Dict[str, Any]:
    """Validate macOS environment for app building"""
    import platform
    import subprocess
    
    validation = {
        "platform": platform.system(),
        "macos_version": platform.mac_ver()[0] if platform.system() == "Darwin" else None,
        "python_version": sys.version,
        "architecture": platform.machine()
    }
    
    if platform.system() != "Darwin":
        validation["error"] = "macOS app building only supported on macOS"
        return validation
    
    # Check for py2app
    try:
        import py2app
        validation["py2app_version"] = py2app.__version__
    except ImportError:
        validation["py2app_available"] = False
        validation["error"] = "py2app not installed - run: pip install py2app"
    
    # Check for Xcode command line tools
    try:
        result = subprocess.run(["xcode-select", "--print-path"], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            validation["xcode_tools"] = True
            validation["xcode_path"] = result.stdout.strip()
        else:
            validation["xcode_tools"] = False
    except FileNotFoundError:
        validation["xcode_tools"] = False
    
    return validation

def build_development_app():
    """Build development version of the app"""
    print("Building development macOS app...")
    
    # Validate environment
    env_check = validate_macos_environment()
    print(f"Environment validation: {env_check}")
    
    if "error" in env_check:
        print(f"Error: {env_check['error']}")
        return False
    
    # Create supporting files
    entitlements_path = create_entitlements_plist()
    info_plist_path = create_info_plist_template()
    
    # Development build options
    dev_options = PY2APP_OPTIONS.copy()
    dev_options.update({
        "alias": True,  # Development alias mode
        "debug_modulegraph": True,
        "debug_skip_macholib": False,
        "optimize": 0,  # No optimization for debugging
        "compressed": False
    })
    
    try:
        from setuptools import setup
        
        setup(
            name=APP_NAME,
            app=[MAIN_SCRIPT],
            options={"py2app": dev_options},
            setup_requires=["py2app"]
        )
        
        print("✅ Development app built successfully!")
        print(f"App location: dist/{APP_NAME}.app")
        print("\nTo run: open dist/'{APP_NAME}.app'")
        
        return True
        
    except Exception as e:
        print(f"❌ Build failed: {e}")
        return False

def build_distribution_app():
    """Build distribution version of the app"""
    print("Building distribution macOS app...")
    
    # Validate environment
    env_check = validate_macos_environment()
    if "error" in env_check:
        print(f"Error: {env_check['error']}")
        return False
    
    # Create supporting files
    entitlements_path = create_entitlements_plist()
    info_plist_path = create_info_plist_template()
    
    # Distribution build options (optimized)
    dist_options = PY2APP_OPTIONS.copy()
    dist_options.update({
        "alias": False,
        "optimize": 2,
        "compressed": True,
        "strip": True,
        "semi_standalone": False
    })
    
    try:
        from setuptools import setup
        
        setup(
            name=APP_NAME,
            app=[MAIN_SCRIPT],
            options={"py2app": dist_options},
            setup_requires=["py2app"]
        )
        
        print("✅ Distribution app built successfully!")
        print(f"App location: dist/{APP_NAME}.app")
        
        # Provide signing instructions
        print("\n📝 Next steps for distribution:")
        print("1. Test the app: open dist/'{APP_NAME}.app'")
        print("2. For distribution, consider code signing:")
        print(f"   codesign --deep --force --verify --verbose --sign 'Developer ID Application: Your Name' dist/'{APP_NAME}.app'")
        print("3. Create DMG for distribution:")
        print(f"   hdiutil create -volname '{APP_NAME}' -srcfolder dist -ov -format UDZO '{APP_NAME}-{APP_VERSION}.dmg'")
        
        return True
        
    except Exception as e:
        print(f"❌ Build failed: {e}")
        return False

def check_ble_permissions():
    """Check and guide BLE permission setup on macOS"""
    import platform
    
    if platform.system() != "Darwin":
        print("BLE permission check only applicable on macOS")
        return
    
    mac_version = tuple(map(int, platform.mac_ver()[0].split('.')))
    
    print(f"macOS Version: {'.'.join(map(str, mac_version))}")
    
    if mac_version >= (15, 0):
        print("\n🔒 macOS 15+ TCC Requirements:")
        print("- App must be signed and bundled with proper entitlements")
        print("- NSBluetoothAlwaysUsageDescription required in Info.plist")
        print("- User will be prompted for Bluetooth permission on first run")
        print("- For development: Grant Bluetooth access to Terminal/Python in System Preferences")
    elif mac_version >= (10, 15):
        print("\n⚠️  macOS 10.15+ Requirements:")
        print("- NSBluetoothAlwaysUsageDescription recommended in Info.plist")
        print("- May require user permission prompt")
    else:
        print("\n✅ Legacy macOS - No special BLE permissions required")
    
    print("\n🛠  Development Tips:")
    print("1. Run with sudo for temporary BLE access: sudo python -m ha_sphero_bb8.run_ble")
    print("2. Grant Terminal Bluetooth access in System Preferences > Privacy & Security")
    print("3. Use simulation mode for development without BLE hardware")

def test_app_bundle():
    """Test the built app bundle"""
    app_path = f"dist/{APP_NAME}.app"
    
    if not os.path.exists(app_path):
        print(f"❌ App bundle not found at {app_path}")
        print("Run build_development_app() or build_distribution_app() first")
        return False
    
    print(f"Testing app bundle at {app_path}")
    
    # Check bundle structure
    required_paths = [
        f"{app_path}/Contents/Info.plist",
        f"{app_path}/Contents/MacOS",
        f"{app_path}/Contents/Resources"
    ]
    
    for path in required_paths:
        if os.path.exists(path):
            print(f"✅ {path}")
        else:
            print(f"❌ Missing: {path}")
    
    # Check Info.plist for BLE permissions
    info_plist_path = f"{app_path}/Contents/Info.plist"
    try:
        with open(info_plist_path, "rb") as f:
            plist_data = plistlib.load(f)
        
        ble_desc = plist_data.get("NSBluetoothAlwaysUsageDescription")
        if ble_desc:
            print(f"✅ BLE usage description: {ble_desc}")
        else:
            print("❌ Missing NSBluetoothAlwaysUsageDescription in Info.plist")
        
    except Exception as e:
        print(f"❌ Could not read Info.plist: {e}")
    
    print(f"\n🧪 To test manually:")
    print(f"open '{app_path}'")
    
    return True

# Build command dispatching
def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Build macOS app for ha-sphero-bb8")
    parser.add_argument("--mode", choices=["dev", "dist", "test", "check"], 
                       default="dev", help="Build mode")
    
    args = parser.parse_args()
    
    if args.mode == "dev":
        build_development_app()
    elif args.mode == "dist":
        build_distribution_app()
    elif args.mode == "test":
        test_app_bundle()
    elif args.mode == "check":
        check_ble_permissions()

if __name__ == "__main__":
    main()
