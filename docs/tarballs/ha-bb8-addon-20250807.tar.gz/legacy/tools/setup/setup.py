try:
    from setuptools import setup, find_packages
except ImportError:
    # Fallback: try vendored setuptools or raise
    import sys
    sys.stderr.write('setuptools not found. Please install setuptools before running setup.py\n')
    raise

APP = ['test_sphero.py']
OPTIONS = {
    'argv_emulation': False,
    'packages': [
        'spherov2.toy', 'jaraco', 'jaraco.text', 'jaraco.context',
        'jaraco.functools', 'autocommand', 'more_itertools'
    ],
    'includes': [
        'spherov2.toy.bb8', 'spherov2.toy.r2d2', 'spherov2.toy.rvr',
        'jaraco.text', 'jaraco.context', 'jaraco.functools',
        'autocommand', 'more_itertools'
    ],
    'plist': {
        'NSBluetoothAlwaysUsageDescription': 'Required to control Sphero via Bluetooth.'
    },
}

setup(
    name="ha-sphero-bb8",
    version="0.2.0",
    description='Control a Sphero BB-8 with Python and BLE',
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=[
        'spherov2==0.12',
        'numpy',
        'transforms3d',
    ],
    entry_points={
        "console_scripts": [
            "bb8-control = ha_sphero_bb8.launch_bb8:main"
        ]
    },
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
    app=APP,
    author='Evert Appels',
    author_email='dev@evert.app',
    classifiers=[
        'Programming Language :: Python :: 3.13',
        'Operating System :: MacOS',
    ],
    python_requires='>=3.13'
)

