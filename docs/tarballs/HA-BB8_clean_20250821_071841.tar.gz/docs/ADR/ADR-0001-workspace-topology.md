# ADR-0001: Canonical Topology — Dual-Clone via Git Remote

## Context
Prior sessions alternated between a symlink model and a Git-based dual-clone. To eliminate drift, we adopt dual-clone: a normal Git clone in the workspace and a clean Git clone on the HA runtime volume, both tracking the same remote.

## Decision (2025‑08‑21)
- Workspace: normal Git clone at `HA-BB8/addon/` (no symlink, no submodule)
- Runtime: clean Git clone at `/Volumes/addons/local/beep_boop_bb8`
- Deploy: push (workspace) → `git fetch && git reset --hard origin/<branch>` (runtime), then restart add-on via HA UI
- Reports: unify via `REPORT_ROOT=/Users/evertappels/Projects/HA-BB8/reports` (wrappers export)

## Consequences
- Pros: deterministic deploys; easy rollback; CI/CD friendly; no dangling links
- Cons: requires an explicit deploy step; needs Git in the HA runtime environment

## Status
Approved. Supersedes any prior symlink proposals.

## Notes
Keep `scripts/deploy_to_ha.sh` and `scripts/verify_workspace.sh` in the workspace repo. Revisit if team size or CI needs change.
