# ======= CONFIG (edit paths only if different) =======
WS="/Users/evertappels/Projects/HA-BB8"
RUNTIME="/Volumes/addons/local/beep_boop_bb8"
REMOTE="git@github.com:e-app-404/ha-bb8-addon.git"

# ======= PHASE 0: Preflight (fast, non-interactive) =======
bash -lc '
set -Eeuo pipefail
trap '\''echo "[ERR] line:$LINENO cmd:$BASH_COMMAND" >&2'\'' ERR
export GIT_TERMINAL_PROMPT=0

echo "[preflight] WS=${WS}"
echo "[preflight] RUNTIME=${RUNTIME}"
echo "[preflight] REMOTE=${REMOTE}"

test -d "${WS}/.git" || { echo "[FATAL] ${WS} is not a git repo"; exit 2; }
test -d "${WS}" || { echo "[FATAL] missing WS path"; exit 3; }

# Dont traverse mounts or tar massive trees — keep backups lightweight
TS="$(date -u +%Y%m%d_%H%M%S)"
BK="${WS}/_backup_${TS}"
mkdir -p "${BK}"
echo "[preflight] backup dir: ${BK}"

# Capture a lightweight listing instead of tar (prevents pty host stalls)
( cd "${WS}" && ls -la > "${BK}/_ws_listing.txt" )
'

# ======= PHASE 1: Cleanly remove any stale addon tracking (idempotent) =======
bash -lc '
set -Eeuo pipefail
trap '\''echo "[ERR] line:$LINENO cmd:$BASH_COMMAND" >&2'\'' ERR
cd "${WS}"

# If addon is tracked in index, untrack it
if git ls-files --error-unmatch addon >/dev/null 2>&1; then
  echo "[phase1] git rm -rf addon (was tracked)"
  git rm -rf addon
  git commit -m "Cleanup: remove stale addon from index" || true
fi

# If addon exists on disk (dir or symlink), move it aside (no tar)
if [ -e addon ]; then
  echo "[phase1] moving working-copy addon/ aside"
  mv addon "${BK}/addon.ws_${TS}"
fi

# Remove stale submodule metadata if present (safe, idempotent)
if [ -d .git/modules/addon ]; then
  echo "[phase1] removing .git/modules/addon"
  rm -rf .git/modules/addon
fi
if [ -f .gitmodules ] && grep -q "path = addon" .gitmodules; then
  echo "[phase1] purging addon from .gitmodules"
  git config -f .gitmodules --remove-section submodule.addon || true
  # Clean empty file safely
  sed -i.bak "/^\s*$/d" .gitmodules || true
  git add .gitmodules || true
  git commit -m "Cleanup: purge addon from .gitmodules" || true
fi

echo "[phase1] done"
'

# ======= PHASE 2: Add addon/ as submodule to your remote =======
bash -lc '
set -Eeuo pipefail
trap '\''echo "[ERR] line:$LINENO cmd:$BASH_COMMAND" >&2'\'' ERR
cd "${WS}"

echo "[phase2] adding submodule addon -> ${REMOTE}"
git submodule add "${REMOTE}" addon
git commit -m "Track add-on as submodule (ha-bb8-addon)" || true

echo "[phase2] submodule status:"
git submodule status || true
'

# ======= PHASE 3: Align runtime clone to the same remote (no tar, no rsync) =======
bash -lc '
set -Eeuo pipefail
trap '\''echo "[ERR] line:$LINENO cmd:$BASH_COMMAND" >&2'\'' ERR

if [ -d "${RUNTIME}/.git" ]; then
  echo "[phase3] runtime exists; aligning remote+HEAD"
  git -C "${RUNTIME}" remote set-url origin "${REMOTE}"
  git -C "${RUNTIME}" fetch --all --prune
  git -C "${RUNTIME}" reset --hard origin/main
else
  echo "[phase3] creating runtime clone"
  mkdir -p "$(dirname "${RUNTIME}")"
  git clone "${REMOTE}" "${RUNTIME}"
fi
echo "[phase3] runtime HEAD: $(git -C "${RUNTIME}" rev-parse --short HEAD)"
'

# ======= PHASE 4: Consolidate evidence scripts (no placeholders) =======
bash -lc '
set -Eeuo pipefail
trap '\''echo "[ERR] line:$LINENO cmd:$BASH_COMMAND" >&2'\'' ERR
cd "${WS}"

# Canonical location for runtime tools
REQ=(ops/evidence/evidence_preflight.sh ops/evidence/mqtt_probe.py ops/evidence/capture_trace.py ops/evidence/collect_stp4.py ops/evidence/manifest.py)
for rel in "${REQ[@]}"; do
  test -f "addon/${rel}" || { echo "[FATAL] missing addon/${rel}. Restore it in ha-bb8-addon, then re-run." >&2; exit 22; }
done

# Archive duplicates from WS/scripts tools tests if they collide by filename
ARCH="${BK}/archived_dupes"; mkdir -p "${ARCH}"
DUPS=(evidence_preflight.sh mqtt_probe.py capture_trace.py collect_stp4.py manifest.py)
for name in "${DUPS[@]}"; do
  for d in scripts tools tests; do
    if [ -e "${WS}/${d}/${name}" ]; then
      echo "[phase4] archiving duplicate ${d}/${name}"
      mkdir -p "${ARCH}/${d}"
      git mv -f "${WS}/${d}/${name}" "${ARCH}/${d}/${name}" 2>/dev/null || mv "${WS}/${d}/${name}" "${ARCH}/${d}/${name}"
    fi
  done
done

git add -A
git commit -m "Consolidate evidence tooling to addon/ops; archive workspace duplicates" || true
'

# ======= PHASE 5: Unify reports to WS/reports via REPORT_ROOT (no patch churn) =======
bash -lc '
set -Eeuo pipefail
trap '\''echo "[ERR] line:$LINENO cmd:$BASH_COMMAND" >&2'\'' ERR

mkdir -p "${WS}/reports"

# Wrapper runner: ensure it exports REPORT_ROOT once (idempotent)
RUNNER="${WS}/scripts/run_strict_stp4.sh"
if [ -f "${RUNNER}" ]; then
  if ! grep -q "REPORT_ROOT=" "${RUNNER}"; then
    printf "\n# Unified reports root\nexport WORKSPACE_ROOT=\${WORKSPACE_ROOT:-\$(cd \"\$(dirname \"\${BASH_SOURCE[0]}\")/..\" && pwd)}\nexport REPORT_ROOT=\${REPORT_ROOT:-\${WORKSPACE_ROOT}/reports}\n" \
      >> "${RUNNER}"
    echo "[phase5] injected REPORT_ROOT into runner"
  else
    echo "[phase5] runner already defines REPORT_ROOT"
  fi
else
  echo "[phase5][WARN] missing ${RUNNER}; skip"
fi

# Do NOT mutate addon scripts here; they should *read* REPORT_ROOT if they support it.
# If they dont, the wrapper runner can export env so outputs still end in WS/reports.
'

# ======= PHASE 6: Final commit & verify =======
bash -lc '
set -Eeuo pipefail
trap '\''echo "[ERR] line:$LINENO cmd:$BASH_COMMAND" >&2'\'' ERR
cd "${WS}"

git add -A
git commit -m "Canonical layout: addon submodule to ha-bb8-addon; runtime clone aligned; reports unified; duplicates archived" || true

echo "[verify] submodule status:"
git submodule status || true
echo "[verify] workspace addon HEAD: $(git -C "${WS}/addon" rev-parse --short HEAD)"
echo "[verify] runtime   addon HEAD: $(git -C "${RUNTIME}"  rev-parse --short HEAD)"
echo "[verify] reports root:"
ls -la "${WS}/reports"
'
