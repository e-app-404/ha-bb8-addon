import logging
import os
import sys

# Set log path to new location
LOG_PATH = os.environ.get("BB8_LOG_PATH", "/config/hestia/diagnostics/reports/bb8_addon_logs.log")
LOG_LEVEL = os.environ.get("BB8_LOG_LEVEL", "DEBUG")

logger = logging.getLogger("bb8_addon")
logger.setLevel(LOG_LEVEL)
formatter = logging.Formatter('%(asctime)s %(levelname)s:%(name)s: %(message)s')

try:
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    fh = logging.FileHandler(LOG_PATH)
    fh.setLevel(LOG_LEVEL)
    fh.setFormatter(formatter)
    logger.addHandler(fh)
except Exception as e:
    print(f"Failed to open log file {LOG_PATH}: {e}", file=sys.stderr)

ch = logging.StreamHandler(sys.stdout)
ch.setLevel(LOG_LEVEL)
ch.setFormatter(formatter)
logger.addHandler(ch)
