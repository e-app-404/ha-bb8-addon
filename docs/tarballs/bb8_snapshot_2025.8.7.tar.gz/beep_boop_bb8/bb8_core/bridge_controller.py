# Bridge Controller: Unified orchestration for Home Assistant add-on
# Finalized for coordinated BLE/MQTT runtime (2025-08-04)

from typing import Optional
from bb8_core.ble_bridge import BLEBridge
from bb8_core import mqtt_dispatcher
from bb8_core import ble_gateway
from bb8_core.logging_setup import logger
import os

def get_mqtt_config():
    import yaml
    import os
    config_path = "/data/options.json"
    fallback_path = "/config/config.yaml"
    # Try Supervisor options.json first
    try:
        with open(config_path) as f:
            opts = yaml.safe_load(f)
        mqtt_broker = os.environ.get("MQTT_BROKER") or opts.get("mqtt_broker") or "core-mosquitto"
        mqtt_username = os.environ.get("MQTT_USERNAME") or opts.get("mqtt_username") or None
        mqtt_password = os.environ.get("MQTT_PASSWORD") or opts.get("mqtt_password") or None
        mqtt_topic_prefix = os.environ.get("MQTT_TOPIC_PREFIX") or opts.get("mqtt_topic_prefix") or "bb8"
        ble_adapter = os.environ.get("BLE_ADAPTER") or opts.get("ble_adapter") or "hci0"
    except Exception:
        # Fallback to config.yaml if options.json is missing or broken
        try:
            with open(fallback_path) as f:
                config = yaml.safe_load(f)
            opts = config.get("options", config)
            mqtt_broker = opts.get("mqtt_broker", "core-mosquitto")
            mqtt_username = opts.get("mqtt_username", None)
            mqtt_password = opts.get("mqtt_password", None)
            mqtt_topic_prefix = opts.get("mqtt_topic_prefix", "bb8")
            ble_adapter = opts.get("ble_adapter", "hci0")
        except Exception:
            mqtt_broker = "core-mosquitto"
            mqtt_username = None
            mqtt_password = None
            mqtt_topic_prefix = "bb8"
            ble_adapter = "hci0"
    return mqtt_broker, mqtt_username, mqtt_password, mqtt_topic_prefix, ble_adapter

def start_bridge_controller(
    mqtt_host: str,
    mqtt_port: int,
    mqtt_topic: str,
    mqtt_user: Optional[str] = None,
    mqtt_password: Optional[str] = None,
    status_topic: Optional[str] = None,
) -> None:
    """Starts BLE bridge and MQTT dispatcher in coordinated runtime"""
    if not ble_gateway.initialized():
        logger.info({"event": "bridge_controller_ble_init"})
        ble_gateway.init()
    try:
        logger.info({"event": "bridge_controller_blebridge_init"})
        bridge = BLEBridge()
        logger.debug({"event": "bridge_controller_blebridge_instance", "bridge": str(bridge)})
    except Exception as e:
        logger.error({"event": "bridge_controller_blebridge_init_error", "error": str(e)}, exc_info=True)
        raise
    try:
        logger.info({"event": "bridge_controller_mqtt_dispatcher_start"})
        logger.debug({"event": "bridge_controller_mqtt_dispatcher_args", "host": mqtt_host, "port": mqtt_port, "topic": mqtt_topic, "user": mqtt_user, "status_topic": status_topic})
        mqtt_dispatcher.start_mqtt_dispatcher(
            mqtt_host=mqtt_host,
            mqtt_port=mqtt_port,
            mqtt_topic=mqtt_topic,
            mqtt_user=mqtt_user,
            mqtt_password=mqtt_password,
            status_topic=status_topic,
        )
        logger.debug({"event": "bridge_controller_mqtt_dispatcher_started"})
    except Exception as e:
        logger.error({"event": "bridge_controller_mqtt_dispatcher_error", "error": str(e)}, exc_info=True)
        try:
            bridge.shutdown()
            logger.debug({"event": "bridge_controller_blebridge_shutdown"})
        except Exception as de:
            logger.error({"event": "bridge_controller_blebridge_shutdown_error", "error": str(de)}, exc_info=True)
        raise

if __name__ == "__main__":
    # Entrypoint for run.sh
    mqtt_host = os.getenv("MQTT_HOST", "localhost")
    mqtt_port = int(os.getenv("MQTT_PORT", "1883"))
    mqtt_topic = os.getenv("MQTT_TOPIC", "bb8/command")
    mqtt_user = os.getenv("MQTT_USER")
    mqtt_password = os.getenv("MQTT_PASSWORD")
    status_topic = os.getenv("STATUS_TOPIC", "bb8/status")
    start_bridge_controller(
        mqtt_host=mqtt_host,
        mqtt_port=mqtt_port,
        mqtt_topic=mqtt_topic,
        mqtt_user=mqtt_user,
        mqtt_password=mqtt_password,
        status_topic=status_topic,
    )
