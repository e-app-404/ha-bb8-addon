


#!/usr/bin/with-contenv bash
set -euo pipefail
export PYTHONUNBUFFERED=1
export PYTHONPATH=/app:${PYTHONPATH:-}
cd /app

log(){ echo "$(date -Is) [BB-8] $*"; }



pwd  # debug: print current working directory
log "Starting bridge controller…"
exec /opt/venv/bin/python3 -m bb8_core.bridge_controller

# Parse MQTT_BROKER (URL or host:port) to set MQTT_HOST and MQTT_PORT
parse_mqtt_url() {
  url="$1"
  url_no_proto="${url#mqtt://}"
  if echo "$url_no_proto" | grep -q ':'; then
    host="${url_no_proto%%:*}"
    port="${url_no_proto##*:}"
  else
    host="$url_no_proto"
    port="1883"
  fi
  export MQTT_HOST="$host"
  export MQTT_PORT="$port"
}

parse_mqtt_url "$MQTT_BROKER"

export MQTT_USER="$MQTT_USERNAME"
export MQTT_PASSWORD="$MQTT_PASSWORD"
export MQTT_TOPIC="${MQTT_TOPIC_PREFIX}/command"
export STATUS_TOPIC="${MQTT_TOPIC_PREFIX}/status"

def ver(mod, import_name=None):
payload = {

# Dev-only: pip-compile requirements if BB8_DEV_DEPS=1
if [[ "${BB8_DEV_DEPS:-0}" = "1" ]] && command -v pip-compile >/dev/null 2>&1; then
  echo "[BB-8] Dev mode: pip-compile requirements.in → requirements.txt ..."
  (cd /app && pip-compile requirements.in) || echo "[BB-8] pip-compile failed; continuing"
fi

# Start the Python service
exec /opt/venv/bin/python3 -m bb8_core.bridge_controller
