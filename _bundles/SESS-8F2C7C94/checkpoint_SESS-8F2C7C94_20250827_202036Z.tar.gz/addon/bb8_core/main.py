def main():
    print("bb8_core.main loaded")

if __name__ == "__main__":
    main()