# OPERATIONS_OVERVIEW — HA‑BB8 (Hardened)

> **Machine‑friendly handbook** for structure, flows, tokens, and contracts. Optimized for parsing by CI, GitHub Copilot, and LLM assistants.
>
> Baseline Tag: `v2025.8.21.1`
> Project: **BB‑8 Bridge (HA‑BB8)**
> Add‑on Slug: `beep_boop_bb8`
> Runtime Add‑on Path (HA OS): `/addons/local/beep_boop_bb8`
> Current runtime mode: **PUBLISH** @ **2025.8.21.4**
---

## 0. Contents (anchors)

* [Topology & Layout](#1-topology--layout)
* [Roles & Originators](#2-roles--originators)
* [Governance Tokens](#3-governance-tokens)
* [Output Contracts (JSON)](#4-output-contracts-json)
* [Process Flows (A→F)](#5-process-flows-a→f)
* [Versioning & Publish/Deploy](#6-versioning--publishdeploy)
* [Telemetry (STP5)](#7-telemetry-stp5)
* [Troubleshooting Playbook](#8-troubleshooting-playbook)
* [Operational Checklists](#9-operational-checklists)
* [POSIX‑only Helpers (HA‑OS compatible)](#10-posixonly-helpers-haos-compatible)
* [Assumptions & Environment Matrix](#11-assumptions--environment-matrix)

---

## 1. Topology & Layout

> **Dual‑clone (ADR‑0001)** — All Git operations happen in the **workspace**. The HA runtime holds a **plain build context** (explicitly excludes `.git` and workspace-only directories such as `.github`, `docs`, `ops`, `reports`; no nested git) used by Supervisor to build a local image.

```text
WORKSPACE (developer machine)
├─ addon/                 # shipped subtree (container context)
│  ├─ bb8_core/           # runtime code
│  ├─ config.yaml         # add-on manifest (has version + build + image)
│  ├─ Dockerfile          # container build recipe (Debian base only)
│  ├─ run.sh              # s6 entry wrapper (invoked by services.d)
│  └─ tests/              # test suite (pytest)
├─ ops/                   # scripts & runners (not shipped)
├─ reports/               # evidence sink (QA, telemetry, receipts)
├─ scripts/               # wrappers (verify/deploy)
└─ .github/               # CI workflows

HA RUNTIME (Home Assistant OS)
└─ /addons/local/beep_boop_bb8/   # plain folder (config.yaml + Dockerfile + code), no .git
```

**Key rules**

* `addon/` is **not** a git repo; publish to a separate add‑on repository via **`git subtree`**.
  * _(Enforced by CI guard — see [Flow E: Structure guard](#flow-e--ci-token-gate-pr-time))_
* **Canonical run chain:** `s6` → `/etc/services.d/ble_bridge/run` → `/usr/src/app/run.sh` → `python -m bb8_core.main`.
  - The Dockerfile copies the entire `services.d/` directory, which must contain the `ble_bridge` subdirectory and its `run` file (`services.d/ble_bridge/run`), ensuring `/etc/services.d/ble_bridge/run` exists in the container.
* **Canonical run chain:** `s6` → `/etc/services.d/ble_bridge/run` → `/usr/src/app/run.sh` → `python -m bb8_core.main`.

---

## 2. Roles & Originators

| Role           | Scope                           | Primary Outputs                               |
| -------------- | ------------------------------- | --------------------------------------------- |
| **Strategos**  | Governance & acceptance gates   | Delta contracts; binary acceptance; CI policy |
| **Pythagoras** | Code & QA execution             | Patch bundles; tests; QA/evidence contracts   |
| **Copilot**    | Implementation surface (assist) | Applied diffs; scripted runs                  |
| **Supervisor** | Runtime container lifecycle     | Build logs; start/stop; error diagnostics     |

**Machine tags**: `ORIGINATOR: Strategos` / `ORIGINATOR: Pythagoras` appear in receipts for attribution.

---

## 3. Governance Tokens

> Tokens are single‑line markers emitted in receipts/logs for **binary** step validation.

* `WS_READY` — workspace prepared (structure, tools, wrappers)
* `STRUCTURE_OK` — ADR‑0001 layout valid; add‑on subtree clean
* `SUBTREE_PUBLISH_OK` — add‑on subtree pushed to remote
* `CLEAN_RUNTIME_OK` — runtime folder synchronized (no stray files, no .git)
* `DEPLOY_OK` — Supervisor rebuilt image successfully
* `VERIFY_OK` — runtime health checks passed
* `RUNTIME_TOPOLOGY_OK` — runtime path & image/tag aligned

**Greppable form:**

```
TOKEN: WS_READY
TOKEN: STRUCTURE_OK
TOKEN: SUBTREE_PUBLISH_OK
TOKEN: CLEAN_RUNTIME_OK
TOKEN: DEPLOY_OK
TOKEN: VERIFY_OK
TOKEN: RUNTIME_TOPOLOGY_OK
```

---

## 4. Output Contracts (JSON)

> Contracts are machine‑readable summaries placed under `reports/`.

### 4.1 QA Report

```json
{
  "contract": "qa_report_contract_v1",
  "verdict": "PASS",
  "coverage": 82.0,
  "tests": {"total": 54, "failures": 0, "errors": 0, "skipped": 0},
  "tokens": ["WS_READY","STRUCTURE_OK","DEPLOY_OK","VERIFY_OK"],
  "echoes": {"strict_scalar_retain_false": true, "evidence_file": "ha_mqtt_trace_snapshot.json", "present": true},
  "discovery": {"led_enabled_by_default": true, "file": "ha_discovery_dump.json", "present": true},
  "telemetry": {"snapshot": "telemetry_snapshot.jsonl", "metrics": "metrics_summary.json"},
  "head_commit": "<gitsha>",
  "tag": "v2025.8.21.1",
  "criteria": {
    "coverage_ge_80": true,
    "no_test_failures": true,
    "mqtt_trace_present": true,
    "discovery_dump_present": true,
    "tokens_ok": true
  },
  "ts": 1692810834
}
```

### 4.2 Patch Bundle

```json
{
  "contract": "patch_bundle_contract_v1",
  "head_target": "<gitsha>",
  "tag": "v2025.8.21.1",
  "target_files": ["addon/bb8_core/ble_link.py","addon/bb8_core/mqtt_probe.py"], // Minimal example; additional files may be present
  "diffs_applied": ["BLE loop thread + exponential backoff","Probe instrumentation"],
  "tests_affected": ["addon/tests"],
  "coverage_delta": 0.3,
  "rollback_notes": "Revert files or reset to tag"
}
```

### 4.3 Evidence Manifest

```json
{
  "manifest": "evidence_manifest.json",
  "strict": true,
  "head_commit": "<gitsha>",
  "tag": "v2025.8.21.1",
  "generated_at": "2025-08-23T20:53:54+01:00",
  "artifacts": [
    {"path": "reports/deploy_receipt.txt", "sha256": "<…>"},
    {"path": "reports/verify_receipt.txt", "sha256": "<…>"},
    {"path": "reports/tokens.json", "sha256": "<…>"},
    {"path": "reports/coverage.json", "sha256": "<…>"},
    {"path": "reports/pytest-report.xml", "sha256": "<…>"},
    {"path": "reports/ha_mqtt_trace_snapshot.json", "sha256": "<…>"},
    {"path": "reports/ha_discovery_dump.json", "sha256": "<…>"},
    {"path": "reports/telemetry_snapshot.jsonl", "sha256": "<…>"},
    {"path": "reports/metrics_summary.json", "sha256": "<…>"},
    {"path": "reports/qa_report_contract_v1.json", "sha256": "<…>"},
    {"path": "reports/patch_bundle_contract_v1.json", "sha256": "<…>"}
  ]
}
> **Note:** The `"sha256"` values in the `"artifacts"` array above are placeholders (`"<…>"`). In actual evidence manifests, these should be replaced with the real SHA-256 hashes of each artifact file.
```

---

## 5. Process Flows (A→F)

### Flow A — Local Development & Testing (Originator: Pythagoras)

```bash
# Create/activate venv, then:
pip install -e addon
pip install -r addon/requirements-dev.txt

# Run tests with warnings-as-errors (except paho v1 deprecation in pytest.ini)
pytest -q -W error --maxfail=1 \
  --cov=bb8_core --cov-report=term:skip-covered
```

**Emit:** coverage + JUnit under `reports/` (when using runners).
**Gate:** No warnings except explicitly suppressed policy lines.
**Token:** `WS_READY` when dev toolchain validated.

---

### Flow B — Publish the Add‑on Subtree (Originator: Strategos)

```bash
# From workspace root
# The following command creates a temporary branch containing only the history of the addon/ subtree,
# Replace <org> with your actual GitHub organization or username
git push -f git@github.com:<org>/ha-bb8-addon.git __addon_pub_tmp:refs/heads/main
git subtree split -P addon -b __addon_pub_tmp
git branch -D __addon_pub_tmp

echo 'TOKEN: SUBTREE_PUBLISH_OK' >> reports/publish_receipt.txt
echo 'TOKEN: SUBTREE_PUBLISH_OK' | tee -a reports/publish_receipt.txt
```

**Emit:** `reports/publish_receipt.txt` with `SUBTREE_PUBLISH_OK`.

---

### Flow C — Deploy to HA Runtime (Originator: Strategos → Exec: Pythagoras)

**Option 1: rsync to local add‑ons**

```bash
# On workstation (adjust path or use Samba). Ensure write perms.
rsync -av --delete --exclude '.DS_Store' addon/ /Volumes/addons/local/beep_boop_bb8/

# On HA box
ha addons reload
ha addons rebuild local_beep_boop_bb8
# See [Versioning & Publish/Deploy](#6-versioning--publishdeploy) for details on correct usage of `image:` and `build:` in `config.yaml`.
ha addons start  local_beep_boop_bb8

mkdir -p /config/reports
echo 'TOKEN: CLEAN_RUNTIME_OK' >> /config/reports/deploy_receipt.txt
echo 'TOKEN: DEPLOY_OK'         >> /config/reports/deploy_receipt.txt
echo 'TOKEN: VERIFY_OK'         >> /config/reports/deploy_receipt.txt
```

**Option 2: runtime clone reset** (if your deploy path uses a clone)

> **Warning:** This will overwrite any local changes in the runtime repo. Ensure you have committed or backed up any important modifications before running these commands.

```bash
# In runtime repo
git fetch --all --prune
git checkout -B main origin/main
git reset --hard origin/main
ha addons rebuild local_beep_boop_bb8
```

**Gate (mode‑aware):** `config.yaml` has `build:`; `image:` is either `local/{arch}-addon-beep_boop_bb8` (LOCAL_DEV) **or** a registry URL with a published tag (PUBLISH).
**Emit:** `deploy_receipt.txt` with `CLEAN_RUNTIME_OK`, `DEPLOY_OK`, `VERIFY_OK`.

---

### Flow D — Strict Attestation (STP4) & Binary Acceptance (Originator: Strategos)

```bash
# One-shot runner (example path)
bash ops/run_strict_attestation.sh
```

**Produces**

* `qa_report_contract_v1.json` (**PASS/FAIL**)
* `patch_bundle_contract_v1.json`
* `evidence_manifest.json`
* Echo & discovery artifacts: `ha_mqtt_trace_snapshot.json`, `ha_discovery_dump.json`

**PASS criteria**

* coverage ≥ **80%**
* **No asyncio event‑loop warnings**
* Device‑originated echoes (retain=false)
* LED discovery present; **no dupes**; unique_id stable
* Tokens present: `STRUCTURE_OK`, `DEPLOY_OK`, `VERIFY_OK`, `WS_READY`

---


### Flow E — CI Token Gate (PR time)

```yaml
# .github/workflows/repo-guards.yml (excerpt, CRTP-hardened)
- name: Structure guard (ADR-0001 + CRTP)
  run: |
    set -euo pipefail
    test -d addon || (echo "addon/ missing" && exit 2)
    if [ -d addon/.git ]; then echo "addon is a repo (forbidden)"; exit 3; fi

    # Forbidden workspace-only dirs (always)
    for d in .github docs ops reports; do
      if [ -e "addon/$d" ]; then echo "DRIFT:forbidden_in_addon:$d"; exit 4; fi
    done

    # CRTP: tools/ allowed only if referenced in Dockerfile or marker present
    if [ -d addon/tools ]; then
      if ! grep -Ei '(COPY|ADD|RUN|ENTRYPOINT|CMD).*tools/' addon/Dockerfile >/dev/null 2>&1 
         && [ ! -f addon/.allow_runtime_tools ]; then
        echo "DRIFT:tools_unreferenced_in_dockerfile"; exit 5
      else
        echo "TOKEN: TOOLS_ALLOWED"
      fi
    fi

    # CRTP: scripts/ allowed only if referenced in Dockerfile or marker present
    if [ -d addon/scripts ]; then
      if ! grep -Ei '(COPY|ADD|RUN|ENTRYPOINT|CMD).*scripts/' addon/Dockerfile >/dev/null 2>&1 
         && [ ! -f addon/.allow_runtime_scripts ]; then
        echo "DRIFT:scripts_unreferenced_in_dockerfile"; exit 6
      else
        echo "TOKEN: SCRIPTS_ALLOWED"
      fi
    fi

    # Required build context
    test -f addon/config.yaml || (echo "DRIFT:missing_config_yaml" && exit 7)
    test -f addon/Dockerfile  || (echo "DRIFT:missing_Dockerfile" && exit 8)
    # Mode-aware guard:
    if grep -Eq '^[[:space:]]*image:[[:space:]]*' addon/config.yaml; then
      echo "MODE: PUBLISH"
      grep -Eq '^[[:space:]]*version:[[:space:]]*' addon/config.yaml || (echo "DRIFT:version_missing_in_publish_mode" && exit 9)
    else
      echo "MODE: LOCAL_DEV"
      test -f addon/Dockerfile || (echo "DRIFT:dockerfile_missing_in_local_dev" && exit 10)
      echo "TOKEN: DEV_LOCAL_BUILD_FORCED"
    fi

    echo "TOKEN: STRUCTURE_OK"
- name: Pytest (warnings as errors)
  run: pytest -q -W error --maxfail=1 --cov=bb8_core --cov-report=term-missing
- name: Emit CI tokens
  run: echo '{"tokens":["STRUCTURE_OK","VERIFY_OK","TOOLS_ALLOWED","SCRIPTS_ALLOWED"]}' > tokens.ci.json
```

**Note:** CI intentionally **does not** emit `DEPLOY_OK`.

---

### Flow F — Local Add‑on Version Bump & Rebuild

```bash
# Edit runtime file on HA box
sed -i 's/^version:.*/version: "2025.8.21.4"/' /addons/local/beep_boop_bb8/config.yaml
ha addons reload
ha addons rebuild local_beep_boop_bb8
ha addons info local_beep_boop_bb8 | grep -E 'version:|version_latest:'
```

**Gotcha:** Without `build:` in `config.yaml`, Supervisor tries to **pull** a `local/` image → 404. Always include `build:`.

---

## 6. Versioning & Publish/Deploy

**In `addon/config.yaml` (mode‑aware)**

```yaml
# LOCAL_DEV (build locally; Supervisor DOES NOT pull):
version: "2025.8.21.4"
build:
  dockerfile: Dockerfile
  args:
    BUILD_FROM: "ghcr.io/home-assistant/{arch}-base-debian:bookworm"
# image: (omit in LOCAL_DEV)

# PUBLISH (Supervisor pulls from registry):
version: "2025.8.21.4"  # Ensure 'version:' is present and uncommented in actual publish mode
image: "ghcr.io/your-org/ha-bb8-{arch}"
# (build: ignored when image: is set for PUBLISH mode; Supervisor pulls image from registry)
```

**Canonical Dockerfile (Debian base + s6 + venv + jq/bash)**

```dockerfile
ARG BUILD_FROM=ghcr.io/home-assistant/aarch64-base-debian:bookworm
FROM ${BUILD_FROM}

ENV PYTHONUNBUFFERED=1 \
  PIP_DISABLE_PIP_VERSION_CHECK=1 \
  PIP_NO_CACHE_DIR=1 \
  VIRTUAL_ENV=/opt/venv \
  PATH="/opt/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

WORKDIR /usr/src/app
# Narrow copies (no COPY .)
COPY bb8_core/     /usr/src/app/bb8_core/
COPY app/          /usr/src/app/app/
COPY services.d/   /etc/services.d/
COPY run.sh        /usr/src/app/run.sh
COPY requirements.txt* /usr/src/app/

# Debian base deps; ensure bash + jq exist for run.sh
RUN apt-get update && \
    apt-get install -y --no-install-recommends \
      bash jq python3 python3-venv python3-pip ca-certificates && \
    rm -rf /var/lib/apt/lists/*

# Create venv and install into venv
RUN python3 -m venv "/opt/venv" && \
    /opt/venv/bin/pip install --no-cache-dir -U pip setuptools wheel && \
    if [ -f /usr/src/app/requirements.txt ]; then \
      /opt/venv/bin/pip install --no-cache-dir -r /usr/src/app/requirements.txt ; \
    fi && \
    chmod +x /usr/src/app/run.sh


Mode Matrix (LOCAL_DEV vs PUBLISH)

| Mode | image: value | Dockerfile | Build Context | Supervisor Action |
|-----------|----------------------------|--------------|---------------------|--------------------|
| LOCAL_DEV | Absent | Present | Local plain folder | Builds locally |
| PUBLISH | Registry URL (ghcr.io/…) | Optional | Registry image/tag | Pulls from registry|

_Refer to the earlier example for the correct `addon/config.yaml` configuration in LOCAL_DEV and PUBLISH modes._

```yaml
version: "2025.8.21.4"
build:
  dockerfile: Dockerfile
  args:
    BUILD_FROM: "ghcr.io/home-assistant/{arch}-base-debian:bookworm"
# image: (omit for LOCAL_DEV; set to ghcr for PUBLISH)
```

run.sh (entrypoint wrapper for Python app in container)

```bash
#!/usr/bin/with-contenv bash
set -euo pipefail
export PYTHONUNBUFFERED=1
cd /usr/src/app
OPTIONS=/data/options.json
JQ=${JQ:-/usr/bin/jq}
VENV=${VIRTUAL_ENV:-/opt/venv}
PY="$VENV/bin/python"; command -v "$PY" >/dev/null 2>&1 || PY="$(command -v python3 || command -v python)"
if command -v "$JQ" >/dev/null 2>&1 && [ -f "$OPTIONS" ]; then
  export ENABLE_BRIDGE_TELEMETRY="$($JQ -r '.enable_bridge_telemetry // 0' "$OPTIONS" 2>/dev/null || echo 0)"
fi
exec "$PY" -m bb8_core.main
```

**s6 run file — `addon/services.d/ble_bridge/run`**

```bash
#!/usr/bin/with-contenv bash
set -euo pipefail
exec /usr/bin/env bash /usr/src/app/run.sh
```

---

## 7. Telemetry (STP5)

**Module:** `addon/bb8_core/telemetry.py`

```python
import json, time, os
TELEMETRY_BASE = os.environ.get("MQTT_BASE", "bb8") + "/telemetry"
ret=False
def now():
    return int(time.time())
def publish(mqtt, name, data):
    """
    Publish telemetry data to MQTT.
    mqtt.publish(f"{TELEMETRY_BASE}/{name}", json.dumps({**data, "ts": now()}), qos=0, retain=ret)
    Args:
def echo_roundtrip(mqtt, ms, outcome):
    """
    Send echo roundtrip latency and outcome telemetry.
    """
    publish(mqtt, "echo_roundtrip", {"ms": ms, "outcome": outcome})

def ble_connect_attempt(mqtt, try_no, backoff_s):
    """
    Report BLE connection attempt number and backoff seconds.
    """
    publish(mqtt, "ble_connect_attempt", {"try": try_no, "backoff_s": backoff_s})

def led_discovery(mqtt, unique_id, duplicates):
    """
    Emit LED discovery telemetry including unique_id and duplicate count.
    """
    publish(mqtt, "led_discovery", {"unique_id": unique_id, "duplicates": duplicates})
    """Send echo roundtrip latency and outcome telemetry."""
    publish(mqtt, "echo_roundtrip", {"ms": ms, "outcome": outcome})

def ble_connect_attempt(mqtt, try_no, backoff_s):
    """Report BLE connection attempt number and backoff seconds."""
    publish(mqtt, "ble_connect_attempt", {"try": try_no, "backoff_s": backoff_s})

def led_discovery(mqtt, unique_id, duplicates):
    """Emit LED discovery telemetry including unique_id and duplicate count."""
    publish(mqtt, "led_discovery", {"unique_id": unique_id, "duplicates": duplicates})
```

**Runner adds telemetry capture**

* `telemetry_snapshot.jsonl` (from `mosquitto_sub -v`)
* `metrics_summary.json` (p50/p95 echo latency; BLE attempts/hour; max dupe count)

**SLOs (recommendation)**

* `echo_roundtrip_ms_p50 ≤ 150`
* `echo_roundtrip_ms_p95 ≤ 500`
* `ble_connect_attempts_per_hour ≤ 6`
* `discovery_dupe_count == 0`

---

## 8. Troubleshooting Playbook

**Gotcha:** If `image:` is present in LOCAL_DEV, Supervisor will try to **pull** → 404. For LOCAL_DEV, **comment out `image:`**; let Supervisor build locally.


### Issue: Add‑on restarts every ~1–2s

**Detect:** repeated `Starting bridge controller…` lines.
**Fix:** keep controller in foreground with SIGTERM handler; on exit, `ble_link.stop(); ble_link.join()`.

### Issue: Supervisor tries to **pull** `local/…` image (404)

**Detect:** `pull access denied for local/aarch64-addon-beep_boop_bb8`
**Fix:** ensure `config.yaml` has `build:` and a present `Dockerfile`; then `ha addons reload && rebuild`.

### Issue: `git pull` fails under `/addons/local/...`

**Detect:** `fatal: not a git repository`
**Fix:** correct — runtime folder is a **plain directory**. Sync from workspace via rsync or use runtime clone path.

### Issue: BLE event loop warnings / unawaited coroutines

**Fix:** dedicated BLE loop thread; `_cancel_and_drain()`; graceful `stop()+join()`.

### Issue: MQTT callback deprecation

**Fix:** pin `paho-mqtt` policy; pass `CallbackAPIVersion.VERSION1`; suppress only that warning in pytest.

### Issue: LED discovery dupes/missing

**Fix:** discovery ON by default; unique_id stable; validate via discovery dump.

---

## 9. Operational Checklists

### 9.1 Pre‑Publish

* [ ] `addon/` contains only shippable files (no `.git`, no workspace dirs)
* [ ] Tests pass locally (`pytest -W error`), coverage ≥ 80%
* [ ] `config.yaml` `version` bumped if releasing

### 9.2 Publish (subtree)

* [ ] `git subtree split -P addon` → push to add‑on repo `main`
* [ ] Receipt contains `TOKEN: SUBTREE_PUBLISH_OK`

### 9.3 Deploy (runtime)

* [ ] `/addons/local/beep_boop_bb8/` contains `config.yaml` + `Dockerfile`
* [ ] `config.yaml` contains `build:` and no `image:` (LOCAL_DEV)
* [ ] `ha addons reload && ha addons rebuild` succeed
* [ ] Receipt contains `TOKEN: CLEAN_RUNTIME_OK`, `TOKEN: DEPLOY_OK`, `TOKEN: VERIFY_OK`

### 9.4 Attestation (STP4)

* [ ] `qa_report_contract_v1.json` = PASS
* [ ] `ha_mqtt_trace_snapshot.json` present (retain=false scalar echo)
* [ ] `ha_discovery_dump.json` present (LED unique_id stable; no dupes)
* [ ] `evidence_manifest.json` lists all artifacts with SHA-256

### 9.5 CI Gate (PR)

* [ ] `STRUCTURE_OK` emitted (ADR‑0001 checks)
* [ ] `VERIFY_OK` emitted (pytest OK; warnings as errors)

---

## 10. POSIX‑only Helpers (HA‑OS compatible)

# Regex helpers for workspace (developer use only)
rg -n '^TOKEN:[[:space:]]*(WS_READY|STRUCTURE_OK|SUBTREE_PUBLISH_OK|CLEAN_RUNTIME_OK|DEPLOY_OK|VERIFY_OK|RUNTIME_TOPOLOGY_OK|TOOLS_ALLOWED|SCRIPTS_ALLOWED)' reports/

# Version desync check (workspace)
# Note: 'rg' (ripgrep) required; fallback to 'grep' if unavailable
if command -v rg >/dev/null 2>&1; then
  sed -n '1,40p' addon/config.yaml | rg '^version:'
  ha addons info local_beep_boop_bb8 | rg 'version'
else
  sed -n '1,40p' addon/config.yaml | grep -E '^version:'
  ha addons info local_beep_boop_bb8 | grep -E 'version'
fi

```bash
# Tokens from receipts (POSIX, no ripgrep)
grep -nE '^TOKEN:[[:space:]]*(WS_READY|STRUCTURE_OK|SUBTREE_PUBLISH_OK|CLEAN_RUNTIME_OK|DEPLOY_OK|VERIFY_OK|RUNTIME_TOPOLOGY_OK|TOOLS_ALLOWED|SCRIPTS_ALLOWED)' reports/* 2>/dev/null || true

# Version desync check (runtime vs info)
sed -n '1,40p' /addons/local/beep_boop_bb8/config.yaml | grep -E '^version:'
ha addons info local_beep_boop_bb8 | grep -E 'version'

# Supervisor build-context sanity
ls -lah /addons/local/beep_boop_bb8
(test -f /addons/local/beep_boop_bb8/config.yaml && echo OK) || echo MISSING-config
(test -f /addons/local/beep_boop_bb8/Dockerfile && echo OK) || echo MISSING-dockerfile

# Telemetry capture (best‑effort)
mosquitto_sub -h "$MQTT_HOST" -p "$MQTT_PORT" -v -t 'bb8/telemetry/#' -C 100 -W 10 
  | awk '{topic=$1; $1=""; sub(/^ /,""); gsub(/"/, "\\\"", $0); payload=$0; print "{\"topic\":\""topic"\",\"payload\":\"" payload "\"}"}' 
  > reports/telemetry_snapshot.jsonl
```

---

## 11. Assumptions & Environment Matrix

```json
{
  "assumptions": {
    "arch": "aarch64",
    "build_from": "ghcr.io/home-assistant/{arch}-base-debian:bookworm",
    "supervisor_s6_entrypoint": true,
    "posix_only_on_ha_host": true,
    "jq_required_in_container": true,
    "bash_required_in_container": true
  },
  "verify": {
    "s6_runfile": "test -f /etc/services.d/ble_bridge/run",
    "wrapper": "test -f /usr/src/app/run.sh",
    "jq_bash": "command -v jq && command -v bash",
    "venv": "test -x /opt/venv/bin/python",
    "local_dev_build": "grep -q '^build:' addon/config.yaml"
  }
}
```

---

**End of OPERATIONS_OVERVIEW** — Keep this file in `docs/OPERATIONS_OVERVIEW.md`. Adhere to ADR‑0001 layout, emit tokens & contracts, and every step becomes provable and automatable.
