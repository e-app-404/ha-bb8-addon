# Resolve addon root and set PYTHONPATH so imports work
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ADDON_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
export PYTHONPATH="${ADDON_ROOT}${PYTHONPATH:+:${PYTHONPATH}}"
MQTT_HOST="${MQTT_HOST:-}"
MQTT_PORT="${MQTT_PORT:-}"
# username compatibility (support both MQTT_USERNAME and MQTT_USER)
export MQTT_USERNAME="${MQTT_USERNAME:-${MQTT_USER:-}}"
export MQTT_USER="${MQTT_USER:-${MQTT_USERNAME:-}}"
export MQTT_PASSWORD="${MQTT_PASSWORD:-}"
if [[ -z "${MQTT_HOST}" ]]; then
  echo "[preflight][ERROR] MQTT_HOST not set"; exit 11
fi
if [[ -z "${MQTT_PORT}" ]]; then
  MQTT_PORT="1883"
fi
if ! [[ "${MQTT_PORT}" =~ ^[0-9]+$ ]]; then
  echo "[preflight][ERROR] MQTT_PORT must be an integer; got '${MQTT_PORT}'"; exit 12
fi
export MQTT_HOST MQTT_PORT
#!/usr/bin/env bash

set -euo pipefail

# --- Python resolver (portable) ---
PY_BIN="${PY_BIN:-}"
if [[ -z "${PY_BIN}" ]]; then
  if [[ -x "$(dirname "$0")/../../.venv_evidence/bin/python" ]]; then
    PY_BIN="$(cd "$(dirname "$0")/../.." && pwd)/.venv_evidence/bin/python"
  elif command -v python3 >/dev/null 2>&1; then
    PY_BIN="$(command -v python3)"
  elif command -v python >/dev/null 2>&1; then
    PY_BIN="$(command -v python)"
  else
    echo "[preflight][ERROR] No python interpreter found." >&2
    exit 127
  fi
fi

OUT="${1:?usage: evidence_preflight.sh <out_dir>}"
mkdir -p "$OUT"

# --- Run directory & reports path (self-contained) ---
# If Makefile didn't export RUN_DIR, define it here.
# Format: stp4_YYYYmmdd_HHMMSS  (UTC)
RUN_DIR="${RUN_DIR:-stp4_$(date -u +%Y%m%d_%H%M%S)}"
REPORT_DIR="../reports/${RUN_DIR}"
mkdir -p "${REPORT_DIR}"
: "${EVIDENCE_TIMEOUT_SEC:=3.0}"
TIMEOUT="${EVIDENCE_TIMEOUT_SEC}"

: "${MQTT_BASE:=bb8}"
: "${REQUIRE_DEVICE_ECHO:=1}"
: "${ENABLE_BRIDGE_TELEMETRY:=1}"

TS="$(date -u +%Y%m%d_%H%M%SZ)"
RUNLOG="$OUT/run.log"
TRACE_JSONL="$OUT/ha_mqtt_trace_snapshot.jsonl"
MANIFEST="$OUT/evidence_manifest.json"

echo "[evidence] ts=$TS base=$MQTT_BASE require_echo=$REQUIRE_DEVICE_ECHO" | tee -a "$RUNLOG"
echo "[evidence] broker=${MQTT_HOST:-}:${MQTT_PORT:-} user=${MQTT_USERNAME:-}" | tee -a "$RUNLOG"

echo "[evidence] step=probe" | tee -a "$RUNLOG"
"${PY_BIN}" ops/evidence/mqtt_probe.py --timeout 8 --require-echo "$REQUIRE_DEVICE_ECHO" 2>&1 | tee -a "$RUNLOG" || true

# Capture duration (seconds)

# If not explicitly set, align capture to exceed timeout
if [[ -z "${EVIDENCE_CAPTURE_SEC:-}" ]]; then
  # timeout + 1s buffer
  CAP_SEC="$(${PY_BIN} -c 'import os; t=float(os.environ.get("EVIDENCE_TIMEOUT_SEC", "3.0")); print(int(t+1))')"
else
  CAP_SEC="${EVIDENCE_CAPTURE_SEC}"
fi
TRACE_OUT="${REPORT_DIR}/ha_mqtt_trace_snapshot.jsonl"

echo "[evidence] step=capture" | tee -a "$RUNLOG"
"${PY_BIN}" ops/evidence/capture_trace.py --out "${TRACE_OUT}" --duration "${CAP_SEC}" &
CAP_PID=$!
sleep 0.3

echo "[evidence] step=collector" | tee -a "$RUNLOG"
COLLECT_RC=0
"${PY_BIN}" ops/evidence/collect_stp4.py --timeout "${TIMEOUT}" --out "${REPORT_DIR}" | tee "${REPORT_DIR}/collector_summary.json" || COLLECT_RC=$?

# ensure capture finished
wait "${CAP_PID}" || true

ROUNDTRIP="FAIL"
grep -q "probe: roundtrip=PASS" "$RUNLOG" && ROUNDTRIP="PASS"

SCHEMA="UNKNOWN"
grep -q "schema=PASS" "$RUNLOG" && SCHEMA="PASS"
grep -q "schema=FAIL" "$RUNLOG" && SCHEMA="FAIL"

echo "[evidence] step=manifest" | tee -a "$RUNLOG"
"${PY_BIN}" ops/evidence/manifest.py --in "${REPORT_DIR}" --timeout "${TIMEOUT}" || true

# propagate collector rc (non-fatal; manifest records verdicts)
exit "${COLLECT_RC}"

echo "[evidence] complete: roundtrip=$ROUNDTRIP schema=$SCHEMA" | tee -a "$RUNLOG"
