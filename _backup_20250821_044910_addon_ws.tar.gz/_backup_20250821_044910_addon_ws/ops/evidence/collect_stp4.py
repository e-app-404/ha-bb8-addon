import argparse
import json
import os
import sys
import threading
import time
import warnings
from datetime import UTC, datetime
from typing import Any

# !/usr/bin/env python3
"""
Collect STP4 MQTT/HA roundtrip evidence.

Outputs:
  - ha_discovery_dump.json      # retained discovery configs observed
  - ha_mqtt_trace_snapshot.json # per-entity command→state traces w/ timestamps
                                  & latency
  - evidence_manifest.json      # summary, pass/fail attestation
Exit code:
  0 on PASS (all checks ok), 1 on FAIL (any roundtrip or schema check failed)
"""


def read_mqtt_env():
    import os

    host = os.environ.get("MQTT_HOST")
    port_s = os.environ.get("MQTT_PORT") or "1883"
    user = os.environ.get("MQTT_USERNAME") or os.environ.get("MQTT_USER") or ""
    pwd = os.environ.get("MQTT_PASSWORD") or ""
    try:
        port = int(port_s)
    except Exception as e:
        raise ValueError(f"Invalid MQTT_PORT: {port_s!r}") from e
    if not host:
        raise RuntimeError("MQTT_HOST is required")
    return host, port, user, pwd


warnings.filterwarnings(
    "ignore", category=DeprecationWarning, module="paho.mqtt.client"
)

# Use shared config
try:
    from bb8_core.addon_config import load_config
except ImportError:
    # Fallback assignment: If the import fails, set load_config to None.
    # This allows the script to run outside the package context where
    # bb8_core may not be available.
    load_config = None

try:
    import paho.mqtt.client as mqtt
except Exception as e:
    import logging

    logging.basicConfig(level=logging.WARNING)
    logging.warning(
        f"[DEPENDENCY] paho-mqtt not installed or import failed: {e}. "
        f"Usually means inactive virtual environment or missing dependencies."
    )
    print(
        "ERR: paho-mqtt not installed. pip install paho-mqtt", file=sys.stderr
    )
    raise

# ----- config / args -----


def get_shared_config():
    import logging

    if load_config:
        try:
            cfg, src = load_config()
            return cfg
        except Exception as e:
            logging.basicConfig(level=logging.WARNING)
            logging.warning(
                f"[CONFIG] Config loader failed: {e}. This could mean any of:"
                f"config missing, broken loader, or missing dependencies."
            )
            print(f"[ERROR] Failed to load config: {e}", file=sys.stderr)
            return {}
    logging.warning(
        "[CONFIG] load_config is unavailable, usually means the module import "
        "failed or PYTHONPATH is not set."
    )
    return {}


def parse_args():
    cfg = get_shared_config()
    # Debug output for config loading
    print(
        "[DEBUG] Loaded config for MQTT:",
        {
            "MQTT_USERNAME": cfg.get("MQTT_USERNAME"),
            "MQTT_PASSWORD": cfg.get("MQTT_PASSWORD"),
            "MQTT_HOST": cfg.get("MQTT_HOST"),
            "MQTT_PORT": cfg.get("MQTT_PORT"),
            "MQTT_BASE": cfg.get("MQTT_BASE"),
        },
    )

    host, port, user, pwd = read_mqtt_env()

    p = argparse.ArgumentParser()
    p.add_argument(
        "--host", default=cfg.get("MQTT_HOST", os.environ.get("MQTT_HOST"))
    )
    p.add_argument(
        "--port",
        type=int,
        default=int(cfg.get("MQTT_PORT", os.environ.get("MQTT_PORT"))),
    )
    p.add_argument(
        "--user", default=cfg.get("MQTT_USERNAME", os.environ.get("MQTT_USER"))
    )
    p.add_argument(
        "--password",
        default=cfg.get("MQTT_PASSWORD", os.environ.get("MQTT_PASSWORD")),
    )
    p.add_argument(
        "--base",
        default=cfg.get("MQTT_BASE", os.environ.get("MQTT_BASE", "bb8")),
    )
    p.add_argument(
        "--out",
        default="reports/stp4_" + datetime.now().strftime("%Y%m%d_%H%M%S"),
    )
    p.add_argument(
        "--timeout", type=float, default=2.0, help="State echo timeout seconds"
    )
    return p.parse_args()


# ----- helpers -----
def utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def dump_json(path: str, obj: Any):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)


# Minimal HA discovery key presence check
def validate_discovery_obj(obj: dict[str, Any]) -> tuple[bool, str]:
    required = ["name", "unique_id", "availability_topic"]
    for k in required:
        if k not in obj:
            return False, f"missing_key:{k}"
    return True, "ok"


# Aggregator: filter + validate only relevant discovery configs for this device
def validate_discovery(configs, device_identifiers, base_topic=None):
    """
    Validate only discovery payloads that belong to this device.
    Minimal HA-required keys per entity:
      - unique_id, name, state_topic
      - command_topic for commandables
      - device.identifiers includes one of device_identifiers
    """
    relevant = []
    for item in configs:
        if isinstance(item, list | tuple) and len(item) >= 2:
            topic, payload = item[0], item[1]
        elif isinstance(item, dict):
            topic, payload = item.get("topic"), item.get("payload")
        else:
            continue
        if payload is None:
            continue
        try:
            o = json.loads(payload)
        except Exception:
            continue
        dev = o.get("device") or {}
        ids = set(dev.get("identifiers") or [])
        if not ids.intersection(set(device_identifiers)):
            continue
        relevant.append((topic, o))

    results = []
    ok = True
    for topic, o in relevant:
        req = ["unique_id", "name", "state_topic", "device"]
        missing = [k for k in req if k not in o]
        if missing:
            results.append({
                "topic": topic,
                "valid": False,
                "reason": f"missing:{missing}",
            })
            ok = False
            continue
        if o["device"].get("identifiers") in (
            None,
            [],
        ):
            results.append({
                "topic": topic,
                "valid": False,
                "reason": "device.identifiers missing",
            })
            ok = False
            continue
        # commandables need command_topic
        if (
            any(
                x in topic
                for x in ("/light/", "/switch/", "/button/", "/number/")
            )
            and "command_topic" not in o
        ):
            results.append({
                "topic": topic,
                "valid": False,
                "reason": "command_topic missing",
            })
            ok = False
            continue
        results.append({"topic": topic, "valid": True})
    return {"valid": ok, "count": len(relevant), "details": results}


# ----- collector -----
class Collector:
    def __init__(
        self,
        host: str,
        port: int,
        user: str | None,
        password: str | None,
        base: str,
        outdir: str,
        timeout: float,
    ):
        self.host, self.port, self.user, self.password = (
            host,
            port,
            user,
            password,
        )
        self.base, self.outdir, self.timeout = base, outdir, timeout
        self.client = mqtt.Client(
            client_id=f"stp4-evidence-{int(time.time())}",
            protocol=mqtt.MQTTv5,
        )
        if user is not None:
            self.client.username_pw_set(user, password or None)
        self.msg_log: list[dict[str, Any]] = []
        self.msg_cv = threading.Condition()
        self.connected = threading.Event()
        self.discovery_dump: dict[str, Any] = {}
        # subscribe topic list
        self.state_topics = [
            f"{base}/power/state",
            f"{base}/stop/state",
            f"{base}/led/state",
            f"{base}/presence/state",
            f"{base}/rssi/state",
            f"{base}/sleep/state",
            f"{base}/drive/state",
            f"{base}/heading/state",
            f"{base}/speed/state",
        ]

    # MQTT callbacks
    def on_connect(self, client, userdata, flags, reason_code, properties):
        self.connected.set()
        # Discovery retained topics
        disc_prefix = "homeassistant/"
        client.subscribe(f"{disc_prefix}#")
        # State topics
        for t in self.state_topics:
            client.subscribe(t, qos=1)

    def on_message(self, client, userdata, msg):
        ts = utc_now_iso()
        entry = {
            "ts": ts,
            "topic": msg.topic,
            "payload_raw": msg.payload.decode("utf-8", "replace"),
            "qos": msg.qos,
            "retain": getattr(msg, "retain", False),
        }
        # collect discovery JSONs
        if msg.topic.startswith("homeassistant/") and msg.payload:
            try:
                obj = json.loads(entry["payload_raw"])
                ok, reason = validate_discovery_obj(obj)
                self.discovery_dump[msg.topic] = {
                    "valid": ok,
                    "reason": reason,
                    "obj": obj,
                }
            except Exception as e:
                self.discovery_dump[msg.topic] = {
                    "valid": False,
                    "reason": f"json_error:{e}",
                }
        # log and notify
        with self.msg_cv:
            self.msg_log.append(entry)
            self.msg_cv.notify_all()

    def wait_for_topic(
        self, topic: str, predicate, timeout: float
    ) -> dict[str, Any] | None:
        deadline = time.time() + timeout
        with self.msg_cv:
            # search backlog first
            for m in reversed(self.msg_log):
                if m.get("retain") is True:
                    continue  # ignore retained/prestate
                if m["topic"] == topic and predicate(m):
                    # Only accept state with ts >= command_ts
                    # (reject stale/prestate)
                    return self._extract_state(m)
            # wait for new ones
            while time.time() < deadline:
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                self.msg_cv.wait(timeout=remaining)
                for m in reversed(self.msg_log):
                    if m.get("retain") is True:
                        continue  # ignore retained/prestate
                    if m["topic"] == topic and predicate(m):
                        # Only accept state w/ ts >= command_ts
                        # (reject stale/prestate)
                        return self._extract_state(m)
        return None

    def _extract_state(self, evt: dict[str, Any]) -> dict[str, Any]:
        src = "device"
        try:
            data = json.loads(evt["payload_raw"])
            src = data.get("source", src)
        except Exception:
            pass
        return {
            "state_ts": evt["ts"],
            "state_topic": evt["topic"],
            "state_payload": evt["payload_raw"],
            "source": src,
        }

    def connect(self):
        self.client.enable_logger()  # opt.: route to std logging if configured
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.will_set(
            f"{self.base}/status", payload="offline", qos=1, retain=True
        )
        self.client.connect(self.host, self.port, keepalive=60)
        self.client.loop_start()
        self.connected.wait(timeout=5)

    def disconnect(self):
        try:
            self.client.disconnect()
        finally:
            import contextlib

            with contextlib.suppress(Exception):
                self.client.loop_stop()

    def publish(self, topic: str, payload: str | None, qos=1, retain=False):
        """
        Publish and return a UTC ISO timestamp captured *before* publish.
        This timestamp is the authoritative command_ts for roundtrip ordering.
        """
        if payload is None:
            payload = ""
        ts = utc_now_iso()
        self.client.publish(topic, payload=payload, qos=qos, retain=retain)
        return ts

    # Roundtrip test helpers
    def run(self) -> dict[str, Any]:
        ensure_dir(self.outdir)
        self.connect()

        traces: list[dict[str, Any]] = []
        failures: list[str] = []

        import json

        def val_pred(expected):
            def _p(x):
                if x["payload_raw"] == expected:
                    return True
                try:
                    j = json.loads(x["payload_raw"])
                    return str(j.get("value")).strip() == expected
                except Exception:
                    return False

            return _p

        def record(
            entity: str,
            cmd_t: str,
            cmd_p: str,
            state_t: str,
            expect,
            m: dict[str, Any] | None,
            note: str = "",
            cmd_ts: str | None = None,
        ):
            now = cmd_ts or utc_now_iso()
            cmd = {
                "entity": entity,
                "command_topic": cmd_t,
                "command_payload": cmd_p,
                "command_ts": now,
                "source": "facade",
            }
            echo = m
            passed, note_val = False, "timeout"
            # Enforce ordering: state after command or within grace window
            if echo:

                def parse_time(ts):
                    from datetime import datetime

                    try:
                        return datetime.fromisoformat(ts)
                    except Exception:
                        return datetime.strptime(
                            ts[:26], "%Y-%m-%dT%H:%M:%S.%f"
                        )

                if echo.get("state_ts"):
                    state_dt = parse_time(echo["state_ts"])
                    cmd_dt = parse_time(cmd["command_ts"])
                    skew = abs((state_dt - cmd_dt).total_seconds())
                    if echo["state_ts"] >= cmd["command_ts"] or (
                        echo["state_ts"] < cmd["command_ts"] and skew <= 0.050
                    ):
                        try:
                            # 1) exact raw match first
                            if echo["state_payload"] == expect:
                                passed, note_val = True, ""
                            else:
                                j_echo = None
                                j_expect = None
                                import contextlib

                                with contextlib.suppress(Exception):
                                    j_echo = json.loads(echo["state_payload"])
                                with contextlib.suppress(Exception):
                                    j_expect = json.loads(expect)
                                # 2) JSON==JSON structural equality (eg LED RGB)
                                if (
                                    (
                                        j_echo is not None
                                        and j_expect is not None
                                        and j_echo == j_expect
                                    )
                                    or (
                                        isinstance(j_echo, dict)
                                        and "value" in j_echo
                                        and str(j_echo["value"]).strip()
                                        == str(expect).strip()
                                    )
                                    or (
                                        str(echo["state_payload"]).strip()
                                        == str(expect).strip()
                                    )
                                ):
                                    passed, note_val = True, ""
                                else:
                                    note_val = "mismatch"
                        except Exception:
                            if (
                                str(echo["state_payload"]).strip()
                                == str(expect).strip()
                            ):
                                passed, note_val = True, ""
                            else:
                                note_val = "mismatch"
                    else:
                        passed, note_val = False, "prestate"
                echo.setdefault("source", "device")
                require_device = os.getenv("REQUIRE_DEVICE_ECHO", "1") != "0"
                is_commandable = ("/cmd/" in cmd_t) or cmd_t.endswith("/set")
                print(
                    print(
                        f"[DEBUG] REQUIRE_DEVICE_ECHO={os.getenv('REQUIRE_DEVICE_ECHO')}, "
                        f"require_device={require_device}, "
                        f"is_commandable={is_commandable}, "
                        f"echo_source={echo.get('source')}"
                    )
                )
                if (
                    require_device
                    and is_commandable
                    and echo.get("source") != "device"
                ):
                    passed, note_val = False, "facade_only"

            res = {
                **cmd,
                "state_topic": state_t,
                "state_payload": echo["state_payload"] if echo else None,
                "state_ts": echo["state_ts"] if echo else None,
                "expect": expect,
                "pass": passed,
                "note": note or note_val,
            }
            traces.append(res)
            if not res["pass"]:
                failures.append(f"{entity}:{res['note'] or 'timeout'}")

        base = self.base
        to = self.timeout

        # ---- Core five ----
        # power = ON
        _ts = self.publish(f"{base}/power/set", "ON")

        def power_pred(x):
            if x.get("retain", False):
                return False
            try:
                if x["payload_raw"] == "ON":
                    return True
                j = json.loads(x["payload_raw"])
                return j.get("value") == "ON" and j.get("source") == "device"
            except Exception:
                return False

        m = self.wait_for_topic(f"{base}/power/state", power_pred, to)
        record(
            "power_on",
            f"{base}/power/set",
            "ON",
            f"{base}/power/state",
            "ON",
            m,
            cmd_ts=_ts,
        )

        # stop press -> 'pressed' then 'idle'
        _ts = self.publish(f"{base}/stop/press", None)

        def stop_pred(x):
            if x.get("retain", False):
                return False
            return x["payload_raw"] == "pressed"

        m1 = self.wait_for_topic(f"{base}/stop/state", stop_pred, to)
        record(
            "stop_pressed",
            f"{base}/stop/press",
            "",
            f"{base}/stop/state",
            "pressed",
            m1,
            cmd_ts=_ts,
        )
        m2 = self.wait_for_topic(
            f"{base}/stop/state", val_pred("idle"), to + 1.0
        )
        record(
            "stop_idle",
            f"{base}/stop/press",
            "",
            f"{base}/stop/state",
            "idle",
            m2,
            cmd_ts=_ts,
        )

        # led set -> hex color
        hex_payload = json.dumps({"hex": "#FF6600"})
        _ts = self.publish(f"{base}/led/set", hex_payload)

        def led_pred(x):
            if x.get("retain", False):
                return False
            try:
                j = json.loads(x["payload_raw"])
                return (
                    all(k in j for k in ("r", "g", "b"))
                    and all(isinstance(j[k], int) for k in ("r", "g", "b"))
                    and "source" not in j
                )
            except Exception:
                return False

        m = self.wait_for_topic(f"{base}/led/state", led_pred, to)
        record(
            "led_rgb",
            f"{base}/led/set",
            hex_payload,
            f"{base}/led/state",
            '{"r":255,"g":102,"b":0}',
            m,
            note="shape_json",
            cmd_ts=_ts,
        )

        # heading number
        _ts = self.publish(f"{base}/heading/set", "270")

        def heading_pred(x):
            if x.get("retain", False):
                return False
            try:
                if x["payload_raw"] == "270":
                    return True
                j = json.loads(x["payload_raw"])
                return j.get("value") == "270" and j.get("source") == "device"
            except Exception:
                return False

        m = self.wait_for_topic(f"{base}/heading/state", heading_pred, to)
        record(
            "heading_set_270",
            f"{base}/heading/set",
            "270",
            f"{base}/heading/state",
            "270",
            m,
            cmd_ts=_ts,
        )

        # speed number
        _ts = self.publish(f"{base}/speed/set", "128")

        def speed_pred(x):
            if x.get("retain", False):
                return False
            try:
                if x["payload_raw"] == "128":
                    return True
                j = json.loads(x["payload_raw"])
                return j.get("value") == "128" and j.get("source") == "device"
            except Exception:
                return False

        m = self.wait_for_topic(f"{base}/speed/state", speed_pred, to)
        record(
            "speed_set_128",
            f"{base}/speed/set",
            "128",
            f"{base}/speed/state",
            "128",
            m,
            cmd_ts=_ts,
        )

        # drive button
        _ts = self.publish(f"{base}/drive/press", None)

        def drive_pred(x):
            if x.get("retain", False):
                return False
            try:
                if x["payload_raw"] == "pressed":
                    return True
                j = json.loads(x["payload_raw"])
                return (
                    j.get("value") == "pressed" and j.get("source") == "device"
                )
            except Exception:
                return False

        m1 = self.wait_for_topic(f"{base}/drive/state", drive_pred, to)
        record(
            "drive_pressed",
            f"{base}/drive/press",
            "",
            f"{base}/drive/state",
            "pressed",
            m1,
            cmd_ts=_ts,
        )
        m2 = self.wait_for_topic(
            f"{base}/drive/state", val_pred("idle"), to + 1.0
        )
        record(
            "drive_idle",
            f"{base}/drive/press",
            "",
            f"{base}/drive/state",
            "idle",
            m2,
            cmd_ts=_ts,
        )

        # ----- dump artifacts -----
        ensure_dir(self.outdir)
        dump_json(
            os.path.join(self.outdir, "ha_discovery_dump.json"),
            self.discovery_dump,
        )
        dump_json(
            os.path.join(self.outdir, "ha_mqtt_trace_snapshot.json"), traces
        )

        # schema verdict (scoped)
        # Build identifiers for THIS device only
        bb8_mac = (os.getenv("BB8_MAC") or "").upper()
        dev_ids = []
        if bb8_mac:
            dev_ids.append(f"ble:{bb8_mac}")
        dev_ids.append(f"mqtt:{os.getenv('MQTT_BASE', 'bb8')}")

        # Prepare configs as (topic, payload) tuples from discovery_dump
        configs = [
            (
                topic,
                entry["obj"]
                if isinstance(entry, dict) and "obj" in entry
                else "{}",
            )
            for topic, entry in self.discovery_dump.items()
        ]
        # Convert obj back to JSON string for validation
        configs = [
            (topic, json.dumps(obj) if isinstance(obj, dict) else obj)
            for topic, obj in configs
        ]

        schema_result = validate_discovery(
            configs,
            device_identifiers=dev_ids,
            base_topic=os.getenv("MQTT_BASE", "bb8"),
        )
        disc_ok = schema_result["valid"]
        roundtrip_ok = all(t.get("pass") for t in traces if isinstance(t, dict))

        attn = {
            "generated_at": utc_now_iso(),
            "broker": {
                "host": self.host,
                "port": self.port,
                "user_present": bool(self.user),
            },
            "base_topic": self.base,
            "schema": "PASS" if disc_ok else "FAIL",
            "schema_details": schema_result,
            "roundtrip": "PASS" if roundtrip_ok else "FAIL",
            "STP4/roundtrip": ("PASS" if (disc_ok and roundtrip_ok) else "FAIL")
            + (" (explain if FAIL)" if not (disc_ok and roundtrip_ok) else ""),
            "timeouts_sec": self.timeout,
            "files": ["ha_discovery_dump.json", "ha_mqtt_trace_snapshot.json"],
        }
        dump_json(os.path.join(self.outdir, "evidence_manifest.json"), attn)

        self.disconnect()
        return {"ok": disc_ok and roundtrip_ok, "attestation": attn}


def main():
    args = parse_args()
    ensure_dir(args.out)
    col = Collector(
        args.host,
        args.port,
        args.user,
        args.password,
        args.base,
        args.out,
        args.timeout,
    )
    res = col.run()
    print(json.dumps(res["attestation"], indent=2))
    sys.exit(0 if res["ok"] else 1)


if __name__ == "__main__":
    main()

    # TOPIC MAP for strict STP4 (flat topics)
    # power/set        -> expect state on  "bb8/power/state"        value "ON"
    # stop/press       -> expect state on  "bb8/stop/state"         value "pressed"
    # sleep/press      -> expect state on  "bb8/sleep/state"        value "pressed"
    # led/set ({"r","g","b"}) -> expect "bb8/led/state" dict with r,g,b (no 'source')
    # heading/set (e.g., "270") -> expect "bb8/heading/state" numeric string or {"value": "270", "source":"device"}
    # speed/set (e.g., "128")   -> expect "bb8/speed/state" numeric string or {"value": "128", "source":"device"}
    # drive/press      -> expect "bb8/drive/state" "pressed" (or {"value":"pressed","source":"device"})

    # In the matcher:
    # * Ignore rows with retain==true.
    # * Accept either raw equals or JSON {"value": <raw>, "source":"device"} for scalars.
    # * For LED accept dict with keys r,g,b (ints).
    # * Enforce state_ts > command_ts (allow <= by 50ms grace).
    # * When REQUIRE_DEVICE_ECHO=1, reject echoes with source != "device" (scalars), and reject LED with any "source" key.
