import json
import os
import time
import warnings

import paho.mqtt.client as mqtt

warnings.filterwarnings(
    "ignore", category=DeprecationWarning, module="paho.mqtt.client"
)


def read_env():
    host = os.environ.get("MQTT_HOST")
    port = int(os.environ.get("MQTT_PORT") or "1883")
    base = os.environ.get("MQTT_BASE") or "bb8"
    user = os.environ.get("MQTT_USERNAME") or os.environ.get("MQTT_USER") or ""
    pwd = os.environ.get("MQTT_PASSWORD") or ""
    if not host:
        raise RuntimeError("MQTT_HOST is required")
    return host, port, base, user, pwd


def main():
    import argparse
    import datetime as dt

    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--duration", type=float, default=6.0)
    args = ap.parse_args()

    host, port, base, user, pwd = read_env()
    topic = f"{base}/#"
    buf = []
    start = time.time()

    def on_connect(c, u, f, rc, props):
        c.subscribe(topic, qos=0)

    def on_message(c, u, m):
        try:
            payload = (m.payload or b"").decode("utf-8", "ignore")
        except Exception:
            payload = ""
        buf.append({
            "ts": dt.datetime.utcnow().isoformat() + "Z",
            "topic": m.topic,
            "payload": payload,
            "retain": bool(getattr(m, "retain", False)),
        })

    client = mqtt.Client(client_id=f"trace-{int(start)}", protocol=mqtt.MQTTv5)
    if user:
        client.username_pw_set(user, pwd)
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(host, port, keepalive=30)
    client.loop_start()
    try:
        deadline = start + float(args.duration)
        while time.time() < deadline:
            time.sleep(0.05)
    finally:
        client.loop_stop()
        client.disconnect()
    with open(args.out, "w", encoding="utf-8") as f:
        for row in buf:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"[trace] wrote {args.out} count={len(buf)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
