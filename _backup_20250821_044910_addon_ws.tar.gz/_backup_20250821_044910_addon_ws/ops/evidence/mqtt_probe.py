import json
import os
import threading
import time
import warnings

import paho.mqtt.client as mqtt

# Suppress paho deprecation warnings in evidence tooling context
warnings.filterwarnings(
    "ignore", category=DeprecationWarning, module="paho.mqtt.client"
)


def read_mqtt_env():
    host = os.environ.get("MQTT_HOST")
    port_s = os.environ.get("MQTT_PORT") or "1883"
    user = os.environ.get("MQTT_USERNAME") or os.environ.get("MQTT_USER") or ""
    pwd = os.environ.get("MQTT_PASSWORD") or ""
    try:
        port = int(port_s)
    except Exception as e:
        raise ValueError(f"Invalid MQTT_PORT: {port_s!r}") from e
    if not host:
        raise RuntimeError("MQTT_HOST is required")
    return host, port, user, pwd


def main():
    host, port, user, pwd = read_mqtt_env()
    connected = threading.Event()

    # v5 callback signatures
    def on_connect(client, userdata, flags, reason_code, properties):
        connected.set()

    def on_disconnect(client, userdata, reason_code, properties):
        pass

    client = mqtt.Client(
        client_id=f"probe-{int(time.time())}", protocol=mqtt.MQTTv5
    )
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    if user:
        client.username_pw_set(user, pwd)

    try:
        client.connect(host, port, keepalive=30)
        client.loop_start()
        connected.wait(timeout=2.0)
        ok = connected.is_set()
    finally:
        try:
            client.loop_stop()
        except Exception:
            pass
        try:
            client.disconnect()
        except Exception:
            pass

    out = {"connected": ok, "host": host, "port": port}
    print(
        f"probe: connected={ok} "
        f"roundtrip={'PASS' if ok else 'FAIL'} "
        f"schema=UNKNOWN"
    )
    print(json.dumps(out))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
