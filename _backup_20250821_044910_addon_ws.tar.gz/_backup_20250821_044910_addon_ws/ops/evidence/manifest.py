#!/usr/bin/env python3
import argparse
import datetime as dt
import json
import os
import re
import sys


def load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            s = f.read().strip()
        # try direct parse
        try:
            return json.loads(s)
        except Exception:
            # salvage last JSON object in mixed stdout
            m = re.search(r"(\{.*\})", s, re.S)
            return json.loads(m.group(1)) if m else None
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="indir", required=True)
    ap.add_argument("--timeout", type=float, default=None)
    args = ap.parse_args()

    indir = args.indir
    summary = load_json(os.path.join(indir, "collector_summary.json")) or {}

    broker = {
        "host": os.environ.get("MQTT_HOST", ""),
        "port": int(os.environ.get("MQTT_PORT") or "1883"),
        "user_present": bool(
            os.environ.get("MQTT_USERNAME") or os.environ.get("MQTT_USER")
        ),
    }
    base = os.environ.get("MQTT_BASE", "bb8")

    files = []
    for name in (
        "ha_discovery_dump.json",
        "ha_mqtt_trace_snapshot.json",
        "ha_mqtt_trace_snapshot.jsonl",
    ):
        if os.path.exists(os.path.join(indir, name)):
            files.append(name)

    manifest = {
        "generated_at": dt.datetime.utcnow().isoformat() + "+00:00",
        "broker": broker,
        "base_topic": base,
        "schema": summary.get("schema", "UNKNOWN"),
        "schema_details": summary.get(
            "schema_details", {"valid": None, "count": 0, "details": []}
        ),
        "roundtrip": summary.get("roundtrip", "FAIL"),
        "STP4/roundtrip": summary.get(
            "STP4/roundtrip", "FAIL (explain if FAIL)"
        ),
        "timeouts_sec": args.timeout
        if args.timeout is not None
        else summary.get("timeouts_sec"),
        "files": files,
    }

    out_path = os.path.join(indir, "evidence_manifest.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    print(f"[manifest] wrote {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
