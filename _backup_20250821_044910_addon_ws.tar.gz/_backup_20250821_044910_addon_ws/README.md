# Sphero BB-8 BLE/MQTT Bridge Home Assistant Add-on

This add-on enables Home Assistant to control a Sphero BB-8 robot via Bluetooth Low Energy (BLE) and MQTT.

## Features

- BLE connection to Sphero BB-8
- MQTT command/response bridge
- Heartbeat/status publishing
- Robust error handling and diagnostics

## Configuration

All options are set via the Home Assistant add-on UI:

- `bb8_mac`: The MAC address of your BB-8
- `mqtt_broker`: MQTT broker URL (default: core-mosquitto)
- `mqtt_username`/`mqtt_password`: MQTT credentials (optional)
- `mqtt_topic_prefix`: MQTT topic prefix (default: bb8)
- `ble_adapter`: BLE adapter (default: hci0)

## Usage

1. Install the add-on.
2. Set configuration options in the add-on UI.
3. Start the add-on. The service will connect to BB-8 and bridge MQTT commands.

## Development

- Entrypoint: `run.sh` reads config and launches the Python service.
- Main code: `/app/src/ha_sphero_bb8/`
- Logs: Viewable in the Home Assistant add-on log panel.

## Notes

- BLE access may require `privileged: true` and `host_dbus: true`.
- Test BLE on your HA hardware early.
- For MQTT discovery, extend the Python code to publish discovery topics.

## MQTT Discovery Entities

The add-on automatically publishes Home Assistant MQTT Discovery topics for the following entities:

- **binary_sensor.bb8_presence**: BB-8 Presence (connectivity)
- **sensor.bb8_rssi**: BB-8 RSSI (signal strength in dBm)
- **sensor.bb8_error_state**: BB-8 Error State (last error message)
- **sensor.bb8_heartbeat**: BB-8 Heartbeat (status/keepalive)
- **switch.bb8_power**: BB-8 Power (on/off)
- **light.bb8_led**: BB-8 LED (RGB control)
- **button.bb8_roll**: BB-8 Roll (trigger roll action)
- **button.bb8_stop**: BB-8 Stop (trigger stop action)

All entities are auto-registered in Home Assistant via MQTT Discovery. No manual YAML configuration is required. Entities will appear after the add-on starts and the robot is detected.


## BB-8 Add-on End-to-End Startup Flow

1. **Container Startup**
   - S6 supervisor starts the add-on container.
   - `run.sh` is executed as the entrypoint.

2. **Shell Entrypoint (`run.sh`)**
   - Loads config from `/data/options.json`.
   - Exports environment variables for all options (including `BB8_MAC_OVERRIDE`).
   - Prints startup diagnostics and environment.
   - Runs BLE adapter check.
   - Starts the main Python service:
     - `python -m bb8_core.bridge_controller --bb8-mac "$BB8_MAC_OVERRIDE" --scan-seconds "$BB8_SCAN_SECONDS" --rescan-on-fail "$BB8_RESCAN_ON_FAIL" --cache-ttl-hours "$BB8_CACHE_TTL_HOURS"`

3. **Python Entrypoint (`bb8_core/bridge_controller.py`)**
   - Parses CLI/environment for all options.
   - Calls `start_bridge_controller(...)`:
     - Initializes BLE gateway.
     - Instantiates `BLEBridge`.
     - Starts MQTT dispatcher.

4. **MAC Address Handling & Auto-Detect**
   - If a MAC is provided (`--bb8-mac`), it is used directly.
   - If empty/missing, the controller **calls `auto_detect.resolve_bb8_mac()`** to scan/cache/resolve the MAC.
   - Auto-detect logs: scan start, cache hits, discovery result, cache writes.

5. **MQTT Dispatcher**
   - Connects to broker, subscribes to command topics.
   - Publishes availability (`bb8/status`), presence and RSSI (if available).

6. **Runtime**
   - BLE and MQTT events handled by dispatcher and bridge.
   - All actions and errors are logged with structured JSON lines.
